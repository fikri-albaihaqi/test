import type { Metadata } from 'next'
import { Figtree } from 'next/font/google'
import './globals.css'
import ScrollToTop from './components/animation/ScrollToTop'

const figtreeSans = Figtree({
  subsets: ['latin'],
  weight: ['300', '400', '600', '700'],
})

export const metadata: Metadata = {
  title: 'Stellar Brand Design',
  description:
    'At Stellar Brand Design we help brands find their voice, and amplify it.',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="scroll-smooth">
      <head>
        <meta
          name="apple-mobile-web-app-title"
          content="Stellar Brand Design"
        />

        <script
          type="text/javascript"
          async
          dangerouslySetInnerHTML={{
            __html: `var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
              (function(){
              var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
              s1.async=true;
              s1.src='https://embed.tawk.to/6821388454769c190cbd49ab/1ir0s9hth';
              s1.charset='UTF-8';
              s1.setAttribute('crossorigin','*');
              s0.parentNode.insertBefore(s1,s0);
              })();
              `,
          }}
        />

        <script
          id="mcjs"
          async
          dangerouslySetInnerHTML={{
            __html: `!function(c,h,i,m,p){
              m=c.createElement(h),p=c.getElementsByTagName(h)[0];
              m.async=1;m.src=i;p.parentNode.insertBefore(m,p)
            }(document,"script","https://chimpstatic.com/mcjs-connected/js/users/a920c342662474c51fe4f1541/4edd4ac4c04b39fcb371c4f31.js");`,
          }}
        />
      </head>
      <body className={`${figtreeSans.className} overflow-x-hidden`}>
        <ScrollToTop />
        {children}
      </body>
    </html>
  )
}
