'use client'

import { ConfigProvider, theme as antdTheme, ThemeConfig } from 'antd'
import { useTheme } from 'next-themes'
import { useEffect, useState } from 'react'

export default function AntdProvider({
  children,
}: {
  children: React.ReactNode
}) {
  const { resolvedTheme } = useTheme()

  const [algorithm, setAlgorithm] = useState<
    NonNullable<ThemeConfig['algorithm']>
  >([antdTheme.defaultAlgorithm])

  useEffect(() => {
    setAlgorithm(
      resolvedTheme === 'dark'
        ? [antdTheme.darkAlgorithm]
        : [antdTheme.defaultAlgorithm]
    )
  }, [resolvedTheme])

  return (
    <ConfigProvider
      theme={{
        token: {
          fontFamily: 'Figtree',
        },
        algorithm,
      }}
    >
      {children}
    </ConfigProvider>
  )
}
