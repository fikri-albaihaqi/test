'use client'

import { useRef, ReactNode } from 'react'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'

interface ScrollingTextProps {
  children: ReactNode
  className?: string
}

const ScrollingText = ({ children, className = '' }: ScrollingTextProps) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  const animationRef = useRef<gsap.core.Tween | null>(null)

  useGSAP(() => {
    const setupAnimation = () => {
      if (animationRef.current) {
        animationRef.current.kill()
        animationRef.current = null
      }

      const container = containerRef.current
      const text = textRef.current

      if (!container || !text) return

      gsap.set(text, { x: 0 })

      const containerWidth = container.offsetWidth
      const textWidth = text.scrollWidth

      if (textWidth > containerWidth) {
        const duration = textWidth / 150 // Adjust speed as needed

        animationRef.current = gsap.to(text, {
          x: -(textWidth - containerWidth),
          duration: duration,
          ease: 'power1.inOut',
          yoyo: true,
          repeat: -1,
          repeatDelay: 1,
        })
      }
    }

    setupAnimation()

    const handleResize = () => {
      setupAnimation()
    }

    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
      if (animationRef.current) {
        animationRef.current.kill()
      }
    }
  }, [children])

  return (
    <div ref={containerRef} className={`overflow-hidden ${className}`}>
      <div ref={textRef} className="whitespace-nowrap inline-block">
        {children}
      </div>
    </div>
  )
}

export default ScrollingText
