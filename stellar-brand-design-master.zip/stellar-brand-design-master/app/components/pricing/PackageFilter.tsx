import { ServiceCategoriesType } from '@/app/lib/types/types'

const PackageFilter = ({
  categories,
  currentCategory,
  selectFilter,
}: {
  categories: ServiceCategoriesType
  currentCategory: string | null
  selectFilter: (category: string | null) => void
}) => {
  console.log(currentCategory)
  return (
    <div className="w-full flex flex-wrap gap-x-4 gap-y-4">
      <button
        onClick={() => selectFilter('package')}
        className={`${currentCategory === 'package' ? 'bg-brand-primary text-font-primary-inverted' : 'bg-font-secondary-3 text-font-primary'} 
          px-4 py-2 text-xl hover:bg-brand-secondary hover:text-font-primary-inverted transition-all rounded-full cursor-pointer`}
      >
        Package
      </button>

      {categories.map((category, index) => (
        <button
          onClick={() => selectFilter(category.name)}
          key={index}
          className={`${category.name === currentCategory ? 'bg-brand-primary text-font-primary-inverted' : 'bg-font-secondary-3'} 
            px-4 py-2 text-xl hover:bg-brand-secondary text-font-primary hover:text-font-primary-inverted transition-all rounded-full cursor-pointer`}
        >
          {category.name}
        </button>
      ))}
    </div>
  )
}

export default PackageFilter
