'use client'

import { usePackageContext } from '@/app/context/PackageContext'
import { PackageType } from '@/app/lib/types/types'
import { useRouter } from 'next/navigation'
import { useEffect, useRef } from 'react'

const CheckIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="currentColor"
    className={className}
  >
    <path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z" />
  </svg>
)

const CrossIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="currentColor"
    className={className}
  >
    <path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z" />
  </svg>
)

const PackageCard = ({ packageData }: { packageData: PackageType }) => {
  const router = useRouter()
  const featuresRef = useRef<HTMLDivElement>(null)
  const { setSelectedPackages } = usePackageContext()

  useEffect(() => {
    const container = featuresRef.current

    if (container) {
      const handleWheel = (event: Event) => {
        event.stopPropagation()
      }

      container.addEventListener('wheel', handleWheel)

      return () => {
        container.removeEventListener('wheel', handleWheel)
      }
    }
  }, [])

  const handleSelectPackage = () => {
    setSelectedPackages([packageData])
    router.replace('/finish-order')
  }

  return (
    <div
      className={`
        ${
          packageData.recommended
            ? 'bg-brand-secondary-2 dark:bg-brand-secondary-3 border-gradient-animate'
            : 'border-[1px] border-brand-secondary'
        } 
        relative flex w-max-[485px] h-auto flex-col px-8 pt-16 pb-8 gap-x-8 gap-y-4 hover:-translate-y-4 rounded-3xl 
        transition-all duration-300
      `}
    >
      <div
        className={`${packageData.recommended ? 'block' : 'hidden'} 
        absolute top-[2px] left-[2px] p-4 bg-canvas dark:bg-canvas-inverted rounded-tl-3xl rounded-br-3xl`}
      >
        <svg
          id="Layer_1"
          className="absolute w-9 h-9 left-0 -bottom-9 rotate-0 text-canvas dark:text-canvas-inverted fill-current"
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
          x="0"
          y="0"
          viewBox="0 0 100 100"
        >
          <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
        </svg>
        <span className="bg-brand-secondary-2 text-brand-primary text-xs font-semibold px-3 py-1 rounded-full w-fit">
          Recommended
        </span>
        <svg
          id="Layer_1"
          className="absolute w-9 h-9 -right-9 top-0 text-canvas dark:text-canvas-inverted fill-current"
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
          x="0"
          y="0"
          viewBox="0 0 100 100"
        >
          <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
        </svg>
      </div>

      <div className={`w-full flex flex-col gap-y-4`}>
        <h2 className="text-3xl font-semibold">{packageData.name}</h2>
        <p className="text-5xl font-semibold">${packageData.price}</p>
        <p className={`text-lg`}>{packageData.description}</p>
      </div>

      {/* Features Section */}
      <div className="h-max grow flex flex-col overflow-hidden transition-all duration-500">
        <h3
          className={`text-sm font-semibold uppercase tracking-wider $text-font-secondary-1`}
        >
          Features:
        </h3>
        <div
          ref={featuresRef}
          className="features max-h-[200px] flex flex-col grow gap-x-8 overflow-y-auto"
        >
          {packageData.features?.map((feature) => (
            <div key={feature._key} className="my-4">
              <h3
                className={`text-sm font-semibold uppercase tracking-wider mb-4 text-font-secondary-1`}
              >
                {feature.category}
              </h3>
              <ul className="space-y-4">
                {feature.features?.slice(0, 4).map((feature) => (
                  <li key={feature._key} className="flex items-start gap-x-3">
                    {feature.included ? (
                      <CheckIcon
                        className={`h-6 w-6 shrink-0 text-brand-primary`}
                      />
                    ) : (
                      <CrossIcon
                        className={`h-6 w-6 shrink-0 text-brand-primary`}
                      />
                    )}
                    <div>
                      <span className="text-base">{feature.name}</span>
                      {feature.note && (
                        <span
                          className={`block text-sm text-font-secondary-1 opacity-70`}
                        >
                          {feature.note}
                        </span>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={handleSelectPackage}
        className="w-full py-3 text-center font-semibold rounded-full transition-all duration-300 bg-brand-primary text-font-primary-inverted hover:bg-canvas-inverted 
          dark:hover:bg-canvas hover:text-font-primary-inverted dark:hover:text-brand-primary cursor-pointer"
      >
        Select plan
      </button>
    </div>
  )
}

export default PackageCard
