'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import AnimatedContent from '../animation/AnimatedContent'
import PackageCard from './PackageCard'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'
import BlockText from '../ui/text/BlockText'
import {
  PackageArrayType,
  PackageType,
  ServiceCategoriesType,
} from '@/app/lib/types/types'
import { useEffect, useMemo, useRef, useState } from 'react'
import Button from '../ui/button/Button'
import PackageFilter from './PackageFilter'
import ScrollingText from './ScrollingText'
import { usePackageContext } from '@/app/context/PackageContext'

gsap.registerPlugin(ScrollTrigger, SplitText)

const CheckIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="currentColor"
    className={className}
  >
    <path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z" />
  </svg>
)

const CrossIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="currentColor"
    className={className}
  >
    <path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z" />
  </svg>
)

const ArrowIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="currentColor"
    className={className}
  >
    <path d="M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z" />
  </svg>
)

const PricingPageBody = ({
  heroHeading,
  description,
  packages,
  categories,
}: {
  heroHeading: TypedObject | TypedObject[]
  description: TypedObject | TypedObject[]
  packages: PackageArrayType
  categories: ServiceCategoriesType
}) => {
  const [isSpecialOffersTab, setIsSpecialOffersTab] = useState(true)
  const [category, setCategory] = useState<string | null>('package')
  const { selectedPackages, setSelectedPackages } = usePackageContext()
  const [showFeatures, setShowFeatures] = useState(false)
  const [currentPackageId, setCurrentPackageId] = useState<string | null>(null)
  const featureRefs = useRef<Record<string, HTMLDivElement | null>>({})

  const handleSelectFilter = (category: string | null) => {
    setCategory(category)
  }

  const totalPrice = useMemo(() => {
    return selectedPackages.reduce((total, selectedPackageItem) => {
      const packageData = packages.find(
        (packageItem) => packageItem._id === selectedPackageItem._id
      )
      return total + (packageData?.price ?? 0)
    }, 0)
  }, [selectedPackages, packages])

  const handleSelectService = (selectedPackageItem: PackageType) => {
    setSelectedPackages((prevSelected) => {
      const exists = prevSelected.some(
        (packageItem) => packageItem._id === selectedPackageItem._id
      )

      if (exists) {
        return prevSelected.filter(
          (packageItem) => packageItem._id !== selectedPackageItem._id
        )
      } else {
        return [...prevSelected, selectedPackageItem]
      }
    })
  }

  useEffect(() => {
    const containers = Object.values(featureRefs.current).filter(Boolean)

    const handleWheel = (event: Event) => {
      event.stopPropagation()
    }

    containers.forEach((container) => {
      container!.addEventListener('wheel', handleWheel, { passive: false })
    })

    return () => {
      containers.forEach((container) => {
        container!.removeEventListener('wheel', handleWheel)
      })
    }
  }, [showFeatures, currentPackageId])

  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <section className="relative w-full flex flex-col gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] mt-8 lg:mt-0">
      <div>
        <div className="flex items-center gap-x-2 mb-1 md:mb-2">
          <div className="w-3 h-3 relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
          </div>
          <h1 className="text-lg font-semibold">Pricing</h1>
        </div>
        <h2 className="text-split w-full text-3xl lg:text-6xl font-semibold">
          <PortableText value={heroHeading} components={BlockText} />
        </h2>
      </div>

      <p className="text-split xl:w-1/3 text-xl lg:text-2xl">
        <PortableText value={description} components={BlockText} />
      </p>

      <div className="w-fit flex justify-center items-center self-center bg-font-secondary-3 dark:bg-font-primary-inverted rounded-full">
        <button
          className={`${isSpecialOffersTab ? 'bg-brand-primary text-font-primary-inverted rounded-full' : 'text-font-primary rounded-l-full'} text-center px-4 py-2`}
          onClick={() => setIsSpecialOffersTab(!isSpecialOffersTab)}
        >
          Special Offers
        </button>
        <button
          className={`${!isSpecialOffersTab ? 'bg-brand-primary text-font-primary-inverted rounded-full' : 'text-font-primary rounded-r-full'} text-center px-4 py-2`}
          onClick={() => setIsSpecialOffersTab(!isSpecialOffersTab)}
        >
          All Offers
        </button>
      </div>

      {/* Special Offers */}
      <AnimatedContent
        distance={300}
        direction="horizontal"
        reverse={false}
        duration={1.2}
        ease={'power3.out'}
      >
        <div
          className={`${isSpecialOffersTab ? 'grid' : 'hidden'} relative w-full lg:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-4`}
        >
          {packages.map(
            (packageData) =>
              packageData.isSpecialOffers && (
                <PackageCard key={packageData._id} packageData={packageData} />
              )
          )}
        </div>

        {/* All Offers */}
        {!isSpecialOffersTab ? (
          <PackageFilter
            categories={categories}
            currentCategory={category}
            selectFilter={handleSelectFilter}
          />
        ) : (
          <></>
        )}
        {packages.some((packageItem) => packageItem.category === null) &&
          category === 'package' && (
            <div
              className={`${isSpecialOffersTab ? 'hidden' : 'flex'} flex-col gap-y-8 mt-8`}
            >
              <div
                className={`${isSpecialOffersTab ? 'hidden' : 'grid'} relative w-full lg:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-4`}
              >
                {packages.map(
                  (packageData) =>
                    !packageData.category?.name && (
                      <PackageCard
                        key={packageData._id}
                        packageData={packageData}
                      />
                    )
                )}
              </div>
            </div>
          )}

        {packages.some(
          (packageItem) => packageItem.category?.name !== null
        ) && (
          <div
            className={`${isSpecialOffersTab ? 'hidden' : 'flex'} flex-col gap-y-8 mt-8`}
          >
            <div
              className={`${isSpecialOffersTab ? 'hidden' : 'grid'} relative w-full lg:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-4`}
            >
              {packages.map(
                (packageData) =>
                  packageData.category?.name === category && (
                    <PackageCard
                      key={packageData._id}
                      packageData={packageData}
                    />
                  )
              )}
            </div>
          </div>
        )}
      </AnimatedContent>

      <div className="w-full flex flex-col items-center gap-y-4">
        <div className="flex items-center self-start gap-x-2">
          <div className="w-3 h-3 relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
          </div>
          <h1 className="text-lg font-semibold">Custom Package</h1>
        </div>
        <h2 className="text-split w-full text-3xl lg:text-6xl font-semibold">
          Build Your Own Package
        </h2>
        <p className="self-start text-split xl:w-1/3 text-xl lg:text-2xl">
          Select the services you need and instantly see your custom price.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
          {packages.map((packageItem) => (
            <div
              key={packageItem._id}
              className={`
                self-start flex flex-col justify-between gap-y-4 p-6 rounded-3xl transition-all duration-300
                ${
                  selectedPackages.some(
                    (selected) => selected._id === packageItem._id
                  )
                    ? 'border-2 border-transparent border-gradient-animate bg-brand-secondary-4 dark:bg-brand-secondary-3'
                    : 'border-2 border-font-secondary-2 dark:border-canvas-secondary-inverted-shade hover:border-brand-secondary'
                }
              `}
            >
              <div className="flex flex-col gap-y-4">
                <h3 className="w-full flex items-center justify-between gap-x-4 text-xl font-bold text-font-primary dark:text-font-primary-inverted">
                  <ScrollingText>{packageItem.name}</ScrollingText>
                  <span
                    className={`text-lg font-semibold transition-colors duration-300 ${
                      selectedPackages.some(
                        (selected) => selected._id === packageItem._id
                      )
                        ? 'text-brand-primary'
                        : 'text-font-primary dark:text-font-primary-inverted'
                    }`}
                  >
                    ${packageItem.price}
                  </span>
                </h3>
              </div>

              <div className="h-max grow flex flex-col overflow-hidden transition-all duration-500">
                <h3
                  onClick={() => {
                    setShowFeatures(
                      packageItem._id !== currentPackageId
                        ? true
                        : !showFeatures
                    )
                    setCurrentPackageId(packageItem._id)
                  }}
                  className="flex items-center self-start gap-x-1 text-sm font-semibold uppercase tracking-wider $text-font-secondary-1 cursor-pointer"
                >
                  See details{' '}
                  <ArrowIcon
                    className={`${showFeatures && packageItem._id === currentPackageId ? 'rotate-180' : 'rotate-0'} h-8 w-8 shrink-0 text-brand-primary transition-all duration-300`}
                  />
                </h3>

                <p
                  className={`${showFeatures && packageItem._id === currentPackageId ? 'max-h-[1000px] visible' : 'max-h-0 invisible'} 
                    text-canvas-secondary-inverted-shade dark:text-font-secondary-2 text-lg transition-all duration-300`}
                >
                  {packageItem.description}
                </p>

                <div
                  ref={(el) => {
                    featureRefs.current[packageItem._id] = el
                  }}
                  className={`${showFeatures && packageItem._id === currentPackageId ? 'max-h-[200px]' : 'max-h-0'} features flex flex-col grow gap-x-8 overflow-y-auto transition-all duration-300`}
                >
                  {packageItem.features?.map((feature) => (
                    <div key={feature._key} className="my-4">
                      <h3
                        className={`text-sm font-semibold uppercase tracking-wider mb-4 text-font-secondary-1`}
                      >
                        {feature.category}
                      </h3>
                      <ul className="space-y-4">
                        {feature.features?.slice(0, 4).map((feature) => (
                          <li
                            key={feature._key}
                            className="flex items-start gap-x-3"
                          >
                            {feature.included ? (
                              <CheckIcon
                                className={`h-6 w-6 shrink-0 text-brand-primary`}
                              />
                            ) : (
                              <CrossIcon
                                className={`h-6 w-6 shrink-0 text-brand-primary`}
                              />
                            )}
                            <div>
                              <span className="text-base">{feature.name}</span>
                              {feature.note && (
                                <span
                                  className={`block text-sm text-font-secondary-1 opacity-70`}
                                >
                                  {feature.note}
                                </span>
                              )}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => handleSelectService(packageItem)}
                className="self-start px-8 py-2 transition-all duration-300 bg-brand-primary text-font-primary-inverted hover:bg-canvas-inverted 
                dark:hover:bg-canvas hover:text-font-primary-inverted dark:hover:text-brand-primary rounded-full cursor-pointer"
              >
                {selectedPackages.some(
                  (selected) => selected._id === packageItem._id
                )
                  ? 'Unselect'
                  : 'Select'}
              </button>
            </div>
          ))}
        </div>

        <div className="w-full bg-brand-primary rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row justify-between items-center text-font-primary-inverted text-center sm:text-left transition-colors duration-300">
          <p className="text-lg font-semibold mb-2 sm:mb-0">Your Total:</p>
          <p className="text-4xl sm:text-5xl font-extrabold">
            ${totalPrice.toLocaleString()}
          </p>
        </div>

        <Button primary={true} link="/finish-order" className="mt-8">
          Confirm package
        </Button>
      </div>
    </section>
  )
}

export default PricingPageBody
