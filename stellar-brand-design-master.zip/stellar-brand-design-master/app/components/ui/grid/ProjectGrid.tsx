'use client'

import ProjectCard from '../card/ProjectCard'
import { FeaturedProjectType } from '@/app/lib/types/types'
import { useRef, useState } from 'react'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import CursorFollower from '../../animation/CursorFollower'

const ProjectGrid = ({
  primaryColor,
  featuredProjects,
}: {
  primaryColor: boolean
  featuredProjects: FeaturedProjectType
}) => {
  const projectsWrapper = useRef<HTMLDivElement>(null)
  const cursorFollower = useRef<HTMLDivElement>(null)

  const [animation] = useState(gsap.timeline({ paused: true }))

  useGSAP(() => {
    const wrapper = projectsWrapper.current
    if (!wrapper) return

    gsap.set(cursorFollower.current, {
      xPercent: -50,
      yPercent: -50,
      scale: 0,
      opacity: 0,
    })

    const x = gsap.quickTo(cursorFollower.current, 'x', {
      duration: 0.6,
      ease: 'back',
    })

    const y = gsap.quickTo(cursorFollower.current, 'y', {
      duration: 0.6,
      ease: 'back',
    })

    window.addEventListener('mousemove', (e) => {
      x(e.clientX)
      y(e.clientY)
    })

    animation.fromTo(
      cursorFollower.current,
      {
        scale: 0,
        opacity: 0,
        duration: 0.3,
      },
      {
        scale: 1,
        opacity: 100,
        duration: 0.3,
      }
    )
    const targets = gsap.utils.toArray(wrapper.children) as HTMLDivElement[]

    targets.forEach((target: HTMLDivElement) => {
      target.addEventListener('mouseenter', () => {
        animation.play()
      })

      target.addEventListener('mouseleave', () => {
        animation.reverse()
      })
    })
  })

  return (
    <div
      ref={projectsWrapper}
      className="relative w-full flex flex-col md:grid grid-cols-2 gap-x-8 gap-y-8"
    >
      <CursorFollower ref={cursorFollower} />
      {featuredProjects?.map((project, index) =>
        (index + 1) % 3 !== 0 ? (
          <ProjectCard
            key={project._id}
            project={project}
            fullWidth={false}
            index={index}
            primaryColor={primaryColor}
          />
        ) : (
          <ProjectCard
            key={project._id}
            project={project}
            fullWidth={true}
            index={index}
            primaryColor={primaryColor}
          />
        )
      )}
    </div>
  )
}

export default ProjectGrid
