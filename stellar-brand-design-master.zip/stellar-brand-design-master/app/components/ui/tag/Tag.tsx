const Tag = ({ tag }: { tag: string }) => {
  return (
    <div className="px-4 py-1 bg-font-secondary-3 rounded-full">
      <p className="text-font-primary">
        {tag}
      </p>
    </div>
  )
}

export default Tag
