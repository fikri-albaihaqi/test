'use client'

import Link from 'next/link'
import { useRef } from 'react'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  link: string
  primary: boolean
}

const arrowIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m256-240-56-56 384-384H240v-80h480v480h-80v-344L256-240Z" />
  </svg>
)

const Button: React.FC<ButtonProps & React.HTMLProps<HTMLButtonElement>> = ({
  children,
  className,
  link,
  primary,
  ...props
}) => {
  const buttonRef = useRef(null)

  return primary ? (
    <Link href={link} className="group overflow-hidden">
      <button
        ref={buttonRef}
        className={`${className} w-max flex items-center gap-2 cursor-pointer`}
        {...props}
      >
        <p
          className="px-4 py-1.5 rounded-full bg-brand-primary group-hover:bg-canvas-inverted dark:group-hover:bg-canvas text-font-primary-inverted hover:text-font-inverted 
            dark:group-hover:text-font-primary font-semibold transition-all duration-300"
        >
          {children}
        </p>{' '}
        <div className="relative w-[24px] h-[24px]">
          <span className="absolute left-0 group-hover:translate-x-[32px] group-hover:-translate-y-[32px] transition-all ease-in-out duration-300">
            {arrowIcon}
          </span>
          <span className="absolute left-0 -translate-x-[32px] translate-y-[32px] group-hover:translate-x-0 group-hover:-translate-y-0 transition-all ease-in-out duration-300">
            {arrowIcon}
          </span>
        </div>
      </button>
    </Link>
  ) : (
    <Link href={link} className="group overflow-hidden">
      <button
        className={`${className} flex items-center gap-2 cursor-pointer`}
        {...props}
        ref={buttonRef}
      >
        <p className="py-1.5 rounded-full text-font-primary group-hover:text-brand-secondary dark:text-font-primary-inverted font-semibold transition-all duration-300">
          {children}
        </p>{' '}
        <div className="relative w-[24px] h-[24px]">
          <span className="absolute left-0 group-hover:translate-x-[32px] group-hover:-translate-y-[32px] transition-all ease-in-out duration-300">
            {arrowIcon}
          </span>
          <span className="absolute left-0 -translate-x-[32px] translate-y-[32px] group-hover:translate-x-0 group-hover:-translate-y-0 transition-all ease-in-out duration-300">
            {arrowIcon}
          </span>
        </div>
      </button>
    </Link>
  )
}

export default Button
