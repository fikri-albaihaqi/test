import { PortableTextComponents } from 'next-sanity'

const BlockText: PortableTextComponents = {
  marks: {
    highlight: ({ children }) => (
      <span className="bg-brand-secondary text-font-primary-inverted">
        {children}
      </span>
    ),
  },
  block: {
    normal: ({ children }) => <>{children}</>,
  },
}

export default BlockText
