import { urlFor } from '@/app/lib/utils/helpers/sanityImageUrl'
import { PortableTextComponents } from 'next-sanity'
import Image from 'next/image'

const BlogBlockText: PortableTextComponents = {
  types: {
    image: ({ value }) => {
      return (
        <figure className="my-8">
          <Image
            src={urlFor(value).url()}
            alt={value.asset.alt || 'Blog image'}
            width={800}
            height={500}
            className="rounded-xl w-full h-auto"
          />
          {value.caption && (
            <figcaption className="text-center text-sm text-gray-500 mt-2">
              {value.caption}
            </figcaption>
          )}
        </figure>
      )
    },
  },
  marks: {
    link: ({ value, children }) => {
      const href = value?.href
      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="underline text-brand-primary hover:text-brand-secondary transition"
        >
          {children}
        </a>
      )
    },
    highlight: ({ children }) => (
      <span className="bg-brand-secondary text-font-primary-inverted">
        {children}
      </span>
    ),
  },
  block: {
    normal: ({ children }) => <p className="mb-4 text-xl">{children}</p>,
    h1: ({ children }) => (
      <h1 className="text-4xl font-bold mt-12 mb-4">{children}</h1>
    ),
    h2: ({ children }) => (
      <h2 className="text-3xl font-semibold mt-10 mb-4">{children}</h2>
    ),
    h3: ({ children }) => (
      <h3 className="text-2xl font-semibold mt-8 mb-3">{children}</h3>
    ),
    h4: ({ children }) => (
      <h4 className="text-xl font-semibold mt-6 mb-2">{children}</h4>
    ),
    blockquote: ({ children }) => (
      <blockquote className="border-l-4 border-brand-primary pl-4 italic text-gray-600 my-4">
        {children}
      </blockquote>
    ),
  },
  list: {
    bullet: ({ children }) => (
      <ul className="list-disc pl-6 mb-4">{children}</ul>
    ),
    number: ({ children }) => (
      <ol className="list-decimal pl-6 mb-4">{children}</ol>
    ),
  },
  listItem: {
    bullet: ({ children }) => <li className="mb-2 text-xl">{children}</li>,
    number: ({ children }) => <li className="mb-2 text-xl">{children}</li>,
  },
}
export default BlogBlockText
