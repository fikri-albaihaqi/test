interface HighlightMarkProps {
  children: React.ReactNode
}

const HighlightMark = (props: HighlightMarkProps) => (
  <span
    style={{
      backgroundColor: '#6881ff',
      padding: '0 2px',
      borderRadius: '3px',
    }}
  >
    {props.children}
  </span>
)

export default HighlightMark
