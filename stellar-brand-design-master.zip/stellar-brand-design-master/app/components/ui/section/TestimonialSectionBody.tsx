'use client'

import { TestimonialArrayType } from '@/app/lib/types/types'
import { useRef, useState } from 'react'
import { Swiper as SwiperType } from 'swiper'
import TestimonialSlider from '../slider/TestimonialSlider'
import { usePathname } from 'next/navigation'
import useViewport from '@/app/lib/utils/helpers/useViewport'

const arrowRightIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary-inverted dark:fill-font-primary"
  >
    <path d="m560-240-56-58 142-142H160v-80h486L504-662l56-58 240 240-240 240Z" />
  </svg>
)

const arrowLeftIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary-inverted dark:fill-font-primary"
  >
    <path d="M400-240 160-480l240-240 56 58-142 142h486v80H314l142 142-56 58Z" />
  </svg>
)

const TestimonialSectionBody = ({
  testimonials,
}: {
  testimonials: TestimonialArrayType
}) => {
  const { width } = useViewport()
  const breakpoints = 1024
  const swiperRef = useRef<SwiperType | null>(null)
  const [posIsBeginning, setIsPosBeginning] = useState<boolean | undefined>(
    true
  )
  const [posIsEnd, setIsPosEnd] = useState<boolean | undefined>(false)
  const pathname = usePathname()

  const handleSwipeIndex = (index: number | undefined) => {
    if (testimonials) {
      if (index === 0) {
        setIsPosBeginning(true)
      } else if (index === testimonials.length - 1) {
        setIsPosEnd(true)
      } else if (index !== 0 && index !== testimonials.length - 1) {
        setIsPosBeginning(false)
        setIsPosEnd(false)
      }
    }
  }

  return (
    <section className="realtive w-full h-full flex flex-col gap-y-8 overflow-hidden">
      <div className="flex justify-between 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="flex flex-col">
          <div className="flex items-center gap-x-2 mb-1 md:mb-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-lg font-semibold">Testimonials</h2>
          </div>
          <p className="text-split text-4xl md:text-6xl font-semibold">
            What our clients say
          </p>
        </div>

        {width >= breakpoints && (
          <div className="flex items-center gap-x-4">
            <button
              className={`p-2 ${
                posIsBeginning ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
              } rounded-full cursor-pointer`}
              onClick={() => {
                swiperRef.current?.slidePrev()
                setIsPosBeginning(swiperRef.current?.isBeginning)
                setIsPosEnd(swiperRef.current?.isEnd)
              }}
              aria-label="Previous testimony"
            >
              {arrowLeftIcon}
            </button>
            <button
              className={`p-2 ${
                posIsEnd ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
              } rounded-full cursor-pointer`}
              onClick={() => {
                swiperRef.current?.slideNext()
                setIsPosBeginning(swiperRef.current?.isBeginning)
                setIsPosEnd(swiperRef.current?.isEnd)
              }}
              aria-label="Next testimony"
            >
              {arrowRightIcon}
            </button>
          </div>
        )}
      </div>

      <div
        className={`${
          pathname === '/' || pathname === '/about' ? 'block' : 'hidden'
        } absolute -z-50 w-full h-[45%] md:h-[40%] lg:h-[460px] xl:h-[500px] 2xl:h-[560px] bg-canvas-secondary dark:bg-canvas-secondary-inverted -translate-y-32`}
      ></div>
      <TestimonialSlider
        swiperRef={swiperRef}
        onIndexChange={handleSwipeIndex}
        featuredTestimonials={testimonials}
      />

      {width < breakpoints && (
        <div className="flex lg:hidden items-center justify-center gap-x-4">
          <button
            className={`p-2 ${
              posIsBeginning ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
            } rounded-full cursor-pointer`}
            onClick={() => {
              swiperRef.current?.slidePrev()
              setIsPosBeginning(swiperRef.current?.isBeginning)
              setIsPosEnd(swiperRef.current?.isEnd)
            }}
            aria-label="Previous testimony"
          >
            {arrowLeftIcon}
          </button>
          <button
            className={`p-2 ${
              posIsEnd ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
            } rounded-full cursor-pointer`}
            onClick={() => {
              swiperRef.current?.slideNext()
              setIsPosBeginning(swiperRef.current?.isBeginning)
              setIsPosEnd(swiperRef.current?.isEnd)
            }}
            aria-label="Next testimony"
          >
            {arrowRightIcon}
          </button>
        </div>
      )}
    </section>
  )
}

export default TestimonialSectionBody
