'use client'

import Button from '../button/Button'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import Image from 'next/image'
import { FeaturedProjectType } from '@/app/lib/types/types'

const CTASectionBody = ({
  heading,
  featuredProjects,
}: {
  heading: string | null | undefined
  featuredProjects: FeaturedProjectType
}) => {
  useGSAP(() => {
    gsap.matchMedia().add(
      {
        isIpadPro:
          '(min-width: 1024px) and (max-height: 1366px) and (orientation: portrait)',
        isSmall: '(max-width: 767px)',
        isMedium: '(max-width: 1023px)',
        isLarge: '(max-width: 1279px)',
        isXl: '(max-width: 1535px)',
        is2xl: '(min-width: 1536px)',
      },
      (context) => {
        const { isIpadPro, isSmall, isMedium, isLarge, isXl, is2xl } =
          context.conditions as gsap.Conditions
        const projectImages = document.querySelectorAll('.project')

        const projectAnimation = gsap.timeline({
          scrollTrigger: {
            trigger: '.cta',
            start: isSmall
              ? '-=520'
              : isMedium
                ? '-=750'
                : isIpadPro
                  ? '-=1500'
                  : isLarge
                    ? '-=200'
                    : isXl
                      ? '-=550'
                      : is2xl
                        ? '-=500'
                        : '',
            end: 'center 300px',
            scrub: true,
          },
        })

        projectAnimation.fromTo(
          projectImages,
          {
            yPercent: 100,
            stagger: 0.2,
          },
          {
            yPercent: 0,
            stagger: 0.2,
            ease: 'power2.out',
          }
        )
      }
    )
  })

  return (
    <section className="cta w-full flex flex-col justify-center 2xl:py-32 gap-x-16 gap-y-8 xl:gap-y-0 lg:items-center overflow-hidden">
      <div className="w-full flex flex-col items-center gap-y-4 lg:gap-y-8 px-[16px]">
        <div className="flex flex-col">
          <div className="flex justify-center items-center gap-x-2 mb-1 md:mb-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-lg font-semibold">{heading}</h2>
          </div>
          <p className="text-split text-center text-5xl md:text-8xl 2xl:text-9xl font-semibold">
            Have a project
            <br />
            in mind?
          </p>
        </div>
        <Button primary={true} link="/contact">
          Start a projects
        </Button>
      </div>

      <div className="w-fit flex gap-x-4 xl:mt-16">
        {featuredProjects?.map((project, index) => (
          <div
            key={index}
            className="project relative w-[116px] lg:w-[180px] xl:w-[240px] h-[116px] lg:h-[180px] xl:h-[240px]"
          >
            <Image
              src={project.images?.asset?.url || ''}
              alt={project.images?.alt || ''}
              fill
              className="object-cover"
            />
          </div>
        ))}

        {featuredProjects?.map((project, index) => (
          <div
            key={index}
            className="project relative w-[116px] lg:w-[180px] xl:w-[240px] h-[116px] lg:h-[180px] xl:h-[240px]"
          >
            <Image
              src={project.images?.asset?.url || ''}
              alt={project.images?.alt || ''}
              fill
              className="object-cover"
            />
          </div>
        ))}
      </div>
    </section>
  )
}

export default CTASectionBody
