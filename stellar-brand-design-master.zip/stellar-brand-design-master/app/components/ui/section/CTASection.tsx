import { CTA_SECTION_QUERY } from '@/sanity/lib/queries'
import CTASectionBody from './CTASectionBody'
import { client } from '@/sanity/lib/client'
import { FeaturedProjectType } from '@/app/lib/types/types'

const CTASection = async () => {
  const ctaSectionContent = await client.fetch(CTA_SECTION_QUERY)
  const heading = ctaSectionContent?.ctaHeading
  const featuredProjects =
    ctaSectionContent?.featuredProject as FeaturedProjectType

  return (
    <CTASectionBody heading={heading} featuredProjects={featuredProjects} />
  )
}

export default CTASection
