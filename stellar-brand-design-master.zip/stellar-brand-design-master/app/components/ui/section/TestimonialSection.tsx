import { TestimonialArrayType } from '@/app/lib/types/types'
import TestimonialSectionBody from './TestimonialSectionBody'
import { TESTIMONIALS_SECTION_QUERY } from '@/sanity/lib/queries'
import { client } from '@/sanity/lib/client'

const TestimonialSection = async () => {
  const testimonialSectionContent = await client.fetch(TESTIMONIALS_SECTION_QUERY)
  const featuredTestimonials =
    testimonialSectionContent?.featuredTestimonials as TestimonialArrayType

  return (
    <TestimonialSectionBody testimonials={featuredTestimonials} />
  )
}

export default TestimonialSection
