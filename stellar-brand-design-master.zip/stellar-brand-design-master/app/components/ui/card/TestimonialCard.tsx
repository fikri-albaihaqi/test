'use client'

import { TestimonialType } from '@/app/lib/types/types'
import React, { useRef, useState } from 'react'
import AnimatedContent from '../../animation/AnimatedContent'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'

const quoteIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 -960 960 960"
    className="w-[24px] md:w-[40px] h-[24px] md:h-[40px] rotate-180 fill-font-primary-inverted"
  >
    <path d="m228-240 92-160q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 23-5.5 42.5T458-480L320-240h-92Zm360 0 92-160q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 23-5.5 42.5T818-480L680-240h-92Z" />
  </svg>
)

const playButtonIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 -960 960 960"
    fill="#f9f9f9"
    className="w-[24px] h-[24px] lg:w-[40px] lg:h-[40px]"
  >
    <path d="M320-200v-560l440 280-440 280Z" />
  </svg>
)

const TestimonialCard = ({
  testimonial,
  className,
}: {
  testimonial: TestimonialType
  className?: string
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const [show, setShow] = useState<boolean>(true)

  const togglePlay = () => {
    if (videoRef.current?.paused) {
      videoRef.current?.play()
      setShow(false)
    } else {
      videoRef.current?.pause()
      setShow(true)
    }
  }

  return (
    <AnimatedContent
      distance={300}
      direction="horizontal"
      reverse={false}
      duration={1.5}
      ease={'power3.out'}
    >
      <div
        className={`${className} group relative w-[300px] md:w-[600px] lg:w-[900px] xl:w-[1000px] 2xl:w-[1200px]`}
        onClick={togglePlay}
      >
        <div className="relative w-full h-[320px] lg:h-[400px] 2xl:h-[600px]">
          {testimonial.hasVideo ? (
            <div className="">
              <video
                className="absolute w-full h-full top-0 left-0 object-cover rounded-2xl lg:rounded-3xl"
                ref={videoRef}
                playsInline
                loop
              >
                <source
                  src={testimonial.testimonyVideo?.asset?.url || ''}
                  type="video/mp4"
                />
                Your browser does not support the video tag.
              </video>

              <div
                className={`${
                  show ? 'block' : 'hidden'
                } absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 p-2 group-hover:p-3 md:p-4 md:group-hover:p-5 lg:p-8 lg:group-hover:p-9 bg-brand-primary rounded-full transition-all duration-300`}
              >
                {playButtonIcon}
              </div>
            </div>
          ) : (
            <div
              className={`${className} w-[300px] md:w-[600px] lg:w-[900px] xl:w-[1000px] 2xl:w-[1200px] h-[320px] lg:h-[400px] 2xl:h-[600px] 
            bg-brand-secondary flex xl:items-center gap-x-2 p-4 md:p-8 lg:p-16 font-light rounded-2xl lg:rounded-3xl`}
            >
              <div className="w-full flex flex-col md:flex-row gap-x-2">
                <span>{quoteIcon}</span>
                <span className="md:mt-4 md:text-xl lg:text-2xl 2xl:text-3xl text-font-primary-inverted">
                  <PortableText
                    value={
                      testimonial.testimonyBody as TypedObject | TypedObject[]
                    }
                  />
                </span>
              </div>
            </div>
          )}

          <div className="absolute flex flex-col z-50 bottom-0 bg-canvas dark:bg-canvas-inverted pt-4 pr-6 rounded-tr-2xl lg:rounded-tr-3xl">
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            <p className="font-semibold">{testimonial.clientName}</p>
            <p>
              {testimonial.position}, {testimonial.company}
            </p>
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
          </div>
        </div>
      </div>
    </AnimatedContent>
  )
}

export default TestimonialCard
