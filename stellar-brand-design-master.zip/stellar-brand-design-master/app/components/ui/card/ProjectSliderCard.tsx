import { ProjectType } from '@/app/lib/types/types'
import Image from 'next/image'
import Link from 'next/link'
import Tag from '../tag/Tag'

const ProjectSliderCard = ({ project }: { project: ProjectType }) => {
  return (
    <Link
      href={`/work/${project.slug?.current}`}
      className="group relative h-fit flex flex-col rounded-2xl lg:rounded-3xl hover:cursor-none"
    >
      <div className="relative w-[320px] md:w-[400px] xl:w-[600px] h-[250px] md:h-[300px] lg:h-[316px] xl:h-[480px] group-hover:-translate-y-4 transition-all duration-500 rounded-2xl lg:rounded-3xl">
        <Image
          src={project.images?.asset?.url || ''}
          alt={project.images?.alt || ''}
          fill
          className="object-cover rounded-2xl lg:rounded-3xl"
        />
        <div className="absolute flex flex-col bottom-0 bg-canvas dark:bg-canvas-inverted pt-4 pr-6 rounded-tr-3xl transition-all duration-300">
          <svg
            id="Layer_1"
            className="absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 fill-canvas dark:fill-canvas-inverted"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>

          <div className="flex 2xl:hidden gap-x-2">
            {project.tags && project.tags?.length > 2
              ? project.tags
                  ?.slice(1, 3)
                  .map((tag, index) => <Tag key={index} tag={tag} />)
              : project.tags?.map((tag, index) => (
                  <Tag key={index} tag={tag} />
                ))}
            {project.tags && project.tags?.length > 3 ? (
              <Tag tag={`${project.tags?.length - 3} +`} />
            ) : (
              <></>
            )}
          </div>

          <div className="hidden 2xl:flex gap-x-2">
            {project.tags && project.tags?.length > 3
              ? project.tags
                  ?.slice(1, 4)
                  .map((tag, index) => <Tag key={index} tag={tag} />)
              : project.tags?.map((tag, index) => (
                  <Tag key={index} tag={tag} />
                ))}
            {project.tags && project.tags?.length > 3 ? (
              <Tag tag={`${project.tags?.length - 3} +`} />
            ) : (
              <></>
            )}
          </div>

          <svg
            id="Layer_1"
            className="absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 fill-canvas dark:fill-canvas-inverted"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>
        </div>
      </div>

      <div className="w-[320px] md:w-[400px] xl:w-[600px] bg-canvas dark:bg-canvas-inverted flex flex-col gap-y-2 pt-4">
        <p>
          {project.client} - {project.year}
        </p>
        <h2 className="text-2xl font-semibold">{project.name}</h2>
      </div>
    </Link>
  )
}

export default ProjectSliderCard
