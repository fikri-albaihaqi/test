'use client'

import { ProjectType } from '@/app/lib/types/types'
import Image from 'next/image'
import Link from 'next/link'
import Tag from '../tag/Tag'
import AnimatedContent from '../../animation/AnimatedContent'
import ParallaxBackground from '../../animation/ParallaxBackground'
import useViewport from '@/app/lib/utils/helpers/useViewport'

const ProjectCard = ({
  project,
  fullWidth,
  index,
  primaryColor,
}: {
  project: ProjectType
  fullWidth: boolean
  index: number
  primaryColor: boolean
}) => {
  const { width } = useViewport()
  const breakpoints = 1536

  return fullWidth ? (
    <Link
      href={`/work/${project.slug?.current}`}
      className="group relative flex flex-col col-span-2 hover:cursor-none"
    >
      <AnimatedContent
        distance={150}
        direction="vertical"
        reverse={false}
        duration={1.2}
        ease={'power3.out'}
      >
        <ParallaxBackground
          src={project.images?.asset?.url || ''}
          alt={project.images?.alt || ''}
          className="relative w-full h-[300px] md:h-[560px] xl:h-[800px] group-hover:-translate-y-4 transition-all duration-300 rounded-2xl lg:rounded-3xl hover:rounded-bl-none"
          overlayClassName="w-full max-w-[70%] top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2"
          overlayImage={
            project.overlayImage && (
              <Image
                src={project.overlayImage?.asset?.url || ''}
                alt={project.overlayImage?.alt || ''}
                fill
                className="w-auto! left-1/2! -translate-x-1/2 object-contain object-top rounded-2xl lg:rounded-3xl"
              />
            )
          }
          otherContent={
            <div
              className={`absolute flex flex-col -bottom-20 group-hover:bottom-0 pt-4 pr-6 rounded-tr-3xl transition-all duration-300 ${
                primaryColor
                  ? 'bg-canvas dark:bg-canvas-inverted'
                  : 'bg-canvas-secondary dark:bg-canvas-secondary-inverted'
              }`}
            >
              <svg
                id="Layer_1"
                className={`absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 ${
                  primaryColor
                    ? 'fill-canvas dark:fill-canvas-inverted'
                    : 'fill-canvas-secondary dark:fill-canvas-secondary-inverted'
                }`}
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                x="0"
                y="0"
                viewBox="0 0 100 100"
              >
                <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
              </svg>

              <div className="flex gap-x-2">
                {project.tags &&
                  project.tags.map((tag, index) => (
                    <Tag key={index} tag={tag} />
                  ))}
              </div>

              <svg
                id="Layer_1"
                className={`absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 ${
                  primaryColor
                    ? 'fill-canvas dark:fill-canvas-inverted'
                    : 'fill-canvas-secondary dark:fill-canvas-secondary-inverted'
                }`}
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                x="0"
                y="0"
                viewBox="0 0 100 100"
              >
                <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
              </svg>
            </div>
          }
        />

        <div
          className={`relative z-50 w-full flex flex-col gap-y-2 pt-4 ${
            primaryColor
              ? 'bg-canvas dark:bg-canvas-inverted'
              : 'bg-canvas-secondary dark:bg-canvas-secondary-inverted'
          }`}
        >
          <p>
            {project.client} - {project.year}
          </p>
          <h2 className="text-2xl font-semibold">{project.name}</h2>
        </div>
      </AnimatedContent>
    </Link>
  ) : (
    <Link
      href={`/work/${project.slug?.current}`}
      className={`group relative h-fit flex flex-col hover:cursor-none ${
        index % 3 === 1 ? 'md:mt-16' : 'mt-0'
      }`}
    >
      <AnimatedContent
        distance={150}
        direction="vertical"
        reverse={false}
        duration={1.2}
        ease={'power3.out'}
      >
        <ParallaxBackground
          src={project.images?.asset?.url || ''}
          alt={project.images?.alt || ''}
          className="h-[300px] lg:h-[400px] 2xl:h-[600px] group-hover:-translate-y-4 transition-all duration-300 rounded-2xl lg:rounded-3xl hover:rounded-bl-none"
          overlayClassName="w-full max-w-[70%] top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 rounded-2xl lg:rounded-3xl overflow-hidden"
          overlayImage={
            project.overlayImage && (
              <Image
                src={project.overlayImage?.asset?.url || ''}
                alt={project.overlayImage?.alt || ''}
                fill
                className="w-auto! left-1/2! -translate-x-1/2 object-contain rounded-2xl lg:rounded-3xl"
              />
            )
          }
          otherContent={
            <div
              className={`absolute flex flex-col -bottom-20 group-hover:bottom-0 ${
                primaryColor
                  ? 'bg-canvas dark:bg-canvas-inverted'
                  : 'bg-canvas-secondary dark:bg-canvas-secondary-inverted'
              } pt-4 pr-6 rounded-tr-3xl transition-all duration-300`}
            >
              <svg
                id="Layer_1"
                className={`absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 ${
                  primaryColor
                    ? 'fill-canvas dark:fill-canvas-inverted'
                    : 'fill-canvas-secondary dark:fill-canvas-secondary-inverted'
                }`}
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                x="0"
                y="0"
                viewBox="0 0 100 100"
              >
                <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
              </svg>

              {width < breakpoints ? (
                <div className="flex gap-x-2">
                  {project.tags && project.tags?.length > 2
                    ? project.tags
                        ?.slice(1, 3)
                        .map((tag, index) => <Tag key={index} tag={tag} />)
                    : project.tags?.map((tag, index) => (
                        <Tag key={index} tag={tag} />
                      ))}
                  {project.tags && project.tags?.length > 3 ? (
                    <Tag tag={`${project.tags?.length - 3} +`} />
                  ) : (
                    <></>
                  )}
                </div>
              ) : (
                <div className="flex gap-x-2">
                  {project.tags && project.tags?.length > 3
                    ? project.tags
                        ?.slice(1, 4)
                        .map((tag, index) => <Tag key={index} tag={tag} />)
                    : project.tags?.map((tag, index) => (
                        <Tag key={index} tag={tag} />
                      ))}
                  {project.tags && project.tags?.length > 3 ? (
                    <Tag tag={`${project.tags?.length - 3} +`} />
                  ) : (
                    <></>
                  )}
                </div>
              )}

              <svg
                id="Layer_1"
                className={`absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 ${
                  primaryColor
                    ? 'fill-canvas dark:fill-canvas-inverted'
                    : 'fill-canvas-secondary dark:fill-canvas-secondary-inverted'
                }`}
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                x="0"
                y="0"
                viewBox="0 0 100 100"
              >
                <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
              </svg>
            </div>
          }
        />

        <div
          className={`relative z-50 w-full ${
            primaryColor
              ? 'bg-canvas dark:bg-canvas-inverted'
              : 'bg-canvas-secondary dark:bg-canvas-secondary-inverted'
          } flex flex-col gap-y-2 pt-4`}
        >
          <p>
            {project.client} - {project.year}
          </p>
          <h2 className="text-2xl font-semibold">{project.name}</h2>
        </div>
      </AnimatedContent>
    </Link>
  )
}

export default ProjectCard
