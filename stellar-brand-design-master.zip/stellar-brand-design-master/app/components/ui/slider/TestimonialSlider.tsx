import TestimonialCard from '../card/TestimonialCard'
import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css'
import { TestimonialArrayType } from '@/app/lib/types/types'
import { Swiper as SwiperType } from 'swiper'
import { RefObject } from 'react'

const TestimonialSlider = ({
  swiperRef,
  onIndexChange,
  featuredTestimonials,
}: {
  swiperRef: RefObject<SwiperType | null>
  onIndexChange: (index: number | undefined) => void
  featuredTestimonials: TestimonialArrayType
}) => {
  const sendIndex = (index: number | undefined) => {
    onIndexChange(index)
  }

  return (
    <Swiper
      slidesPerView={'auto'}
      breakpoints={{
        320: {
          spaceBetween: 16,
          slidesOffsetBefore: 16,
          slidesOffsetAfter: 16,
        },
        768: {
          spaceBetween: 32,
          slidesOffsetBefore: 32,
          slidesOffsetAfter: 32,
        },
        1280: {
          spaceBetween: 32,
          slidesOffsetBefore: 80,
          slidesOffsetAfter: 80,
        },
        1920: {
          spaceBetween: 32,
          slidesOffsetBefore: 160,
          slidesOffsetAfter: 160,
        },
      }}
      className="w-full h-full"
      onSwiper={(swiper: SwiperType) => (swiperRef.current = swiper)}
      onSlideChange={() => sendIndex(swiperRef.current?.realIndex)}
    >
      {featuredTestimonials?.map((testimonial) => (
        <SwiperSlide key={testimonial._id} className="w-auto! h-full">
          <TestimonialCard testimonial={testimonial} />
        </SwiperSlide>
      ))}
    </Swiper>
  )
}

export default TestimonialSlider
