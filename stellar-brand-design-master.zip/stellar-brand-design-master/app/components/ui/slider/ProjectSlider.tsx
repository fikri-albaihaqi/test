'use client'

import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css'
import { FeaturedProjectType } from '@/app/lib/types/types'
import { Swiper as SwiperType } from 'swiper'
import { RefObject, useRef, useState } from 'react'
import ProjectSliderCard from '../card/ProjectSliderCard'
import AnimatedContent from '../../animation/AnimatedContent'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import CursorFollower from '../../animation/CursorFollower'

const ProjectSlider = ({
  swiperRef,
  onIndexChange,
  featuredProjects,
}: {
  swiperRef: RefObject<SwiperType | null>
  onIndexChange: (index: number | undefined) => void
  featuredProjects: FeaturedProjectType
}) => {
  const sendIndex = (index: number | undefined) => {
    onIndexChange(index)
  }

  const projectsWrapper = useRef<HTMLDivElement>(null)
  const cursorFollower = useRef<HTMLDivElement>(null)

  const [animation] = useState(gsap.timeline({ paused: true }))

  useGSAP(() => {
    const wrapper = projectsWrapper.current
    if (!wrapper) return

    gsap.set(cursorFollower.current, {
      xPercent: -50,
      yPercent: -50,
      scale: 0,
      opacity: 0,
    })

    const x = gsap.quickTo(cursorFollower.current, 'x', {
      duration: 0.6,
      ease: 'back',
    })

    const y = gsap.quickTo(cursorFollower.current, 'y', {
      duration: 0.6,
      ease: 'back',
    })

    window.addEventListener('mousemove', (e) => {
      x(e.clientX)
      y(e.clientY)
    })

    animation.fromTo(
      cursorFollower.current,
      {
        scale: 0,
        opacity: 0,
        duration: 0.3,
      },
      {
        scale: 1,
        opacity: 100,
        duration: 0.3,
      }
    )
    const targets = gsap.utils.toArray(wrapper.children) as HTMLDivElement[]

    targets.forEach((target: HTMLDivElement) => {
      target.addEventListener('mouseenter', () => {
        animation.play()
      })

      target.addEventListener('mouseleave', () => {
        animation.reverse()
      })
    })
  })

  return (
    <div ref={projectsWrapper}>
      <CursorFollower ref={cursorFollower} />
      <AnimatedContent
        distance={300}
        direction="horizontal"
        reverse={false}
        duration={1.2}
        ease={'power3.out'}
      >
        <Swiper
          slidesPerView={'auto'}
          breakpoints={{
            320: {
              spaceBetween: 16,
              slidesOffsetBefore: 16,
              slidesOffsetAfter: 16,
            },
            768: {
              spaceBetween: 32,
              slidesOffsetBefore: 32,
              slidesOffsetAfter: 32,
            },
            1280: {
              spaceBetween: 32,
              slidesOffsetBefore: 80,
              slidesOffsetAfter: 80,
            },
            1920: {
              spaceBetween: 32,
              slidesOffsetBefore: 160,
              slidesOffsetAfter: 160,
            },
          }}
          className="w-full h-full"
          onSwiper={(swiper: SwiperType) => (swiperRef.current = swiper)}
          onSlideChange={() => sendIndex(swiperRef.current?.realIndex)}
        >
          {featuredProjects?.map((project) => (
            <SwiperSlide key={project._id} className="w-auto! h-full">
              <ProjectSliderCard project={project} />
            </SwiperSlide>
          ))}
        </Swiper>
      </AnimatedContent>
    </div>
  )
}

export default ProjectSlider
