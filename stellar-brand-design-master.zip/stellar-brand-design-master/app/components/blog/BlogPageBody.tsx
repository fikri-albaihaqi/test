'use client'

import { useState, useMemo } from 'react'
import { Form, FormProps, Input, Pagination } from 'antd'
import BlogCard from './BlogCard'
import { BlogArrayType, NewsletterFieldType } from '@/app/lib/types/types'
import AnimatedContent from '../animation/AnimatedContent'
import BlogFilter from './BlogFilter'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'
import BlockText from '../ui/text/BlockText'

gsap.registerPlugin(ScrollTrigger, SplitText)

const loadingIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-current animate-spin"
  >
    <path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-155.5t86-127Q252-817 325-848.5T480-880q17 0 28.5 11.5T520-840q0 17-11.5 28.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q133 0 226.5-93.5T800-480q0-17 11.5-28.5T840-520q17 0 28.5 11.5T880-480q0 82-31.5 155t-86 127.5q-54.5 54.5-127 86T480-80Z" />
  </svg>
)

const enterIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary-inverted"
  >
    <path d="m560-120-57-57 144-143H200v-480h80v400h367L503-544l56-57 241 241-240 240Z" />
  </svg>
)

const searchIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="#2d2d2d"
  >
    <path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z" />
  </svg>
)

const BlogPageBody = ({
  heading,
  posts,
  tags,
}: {
  heading: TypedObject | TypedObject[]
  posts: BlogArrayType
  tags: Array<string | null>
}) => {
  const [isLoading, setIsLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 15

  const filteredPosts = useMemo(() => {
    return posts.filter((post) =>
      post.title?.toLowerCase().includes(searchQuery.toLowerCase())
    )
  }, [posts, searchQuery])

  const paginatedPosts = useMemo(() => {
    const start = (currentPage - 1) * pageSize
    return filteredPosts.slice(start, start + pageSize)
  }, [filteredPosts, currentPage])

  const [subscriptionMessage, setSubscriptionMessage] = useState(
    'Stay inspired — subscribe to our newsletter for fresh insights on design, growth, SaaS, and Marketing.'
  )

  const onFinish: FormProps<NewsletterFieldType>['onFinish'] = async (
    values
  ) => {
    setIsLoading(true)
    const response = await fetch('/api/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: values.email }),
    })

    const data = await response.json()

    if (response.ok) {
      setIsLoading(false)
      setSubscriptionMessage(
        "Welcome aboard! It's great to have you with us. From now on, you’ll be the first to hear about our latest projects, stories, and special deals."
      )
    } else {
      setIsLoading(false)
      if (data.error === 'Member Exists') {
        setSubscriptionMessage(
          'This email is already registered with our newsletter.'
        )
      } else {
        setSubscriptionMessage(
          'We couldn’t process your subscription. Please try again.'
        )
      }
    }
  }

  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-24 xl:pt-32 overflow-hidden">
      <section className="relative w-full flex flex-col lg:flex-row justify-between gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] overflow-hidden">
        <div className="w-full md:w-[70%] lg:w-2/3 xl:w-1/2 2xl:w-1/3 flex flex-col">
          <div className="flex items-center gap-x-2 mb-1 md:mb-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h1 className="text-lg font-semibold">Blog</h1>
          </div>
          <h2 className="text-split text-4xl md:text-6xl font-semibold">
            <PortableText value={heading} components={BlockText} />
          </h2>
        </div>
      </section>

      <section className="w-full flex flex-col gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <AnimatedContent
          distance={150}
          direction="vertical"
          reverse={false}
          duration={1.2}
          ease={'power3.out'}
        >
          <div className="w-full flex flex-col-reverse lg:flex-row justify-between gap-y-8">
            <BlogFilter tags={tags} />

            <Input
              placeholder="Search articles"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value)
                setCurrentPage(1)
              }}
              className="w-full! lg:w-1/2! xl:w-1/3! h-12 rounded-lg"
              prefix={searchIcon}
            />
          </div>
        </AnimatedContent>

        {/* Grid for big screen */}
        <div className="w-full hidden lg:grid grid-cols-3 gap-8">
          {paginatedPosts.slice(0, 9).map((blog, index) => (
            <BlogCard key={index} blog={blog} />
          ))}
        </div>

        {/* Grid for medium screen */}
        <div className="w-full grid lg:hidden md:grid-cols-2 gap-8">
          {paginatedPosts.slice(0, 10).map((blog, index) => (
            <BlogCard key={index} blog={blog} />
          ))}
        </div>

        <div className="w-full flex flex-col gap-y-4 md:gap-y-8 p-6 md:px-8 md:py-16 bg-brand-secondary rounded-3xl">
          <h2 className="w-full lg:w-2/3 xl:w-1/2 text-2xl md:text-4xl text-font-primary-inverted font-semibold">
            {subscriptionMessage}
          </h2>

          <Form
            name="newsletterBlog"
            onFinish={onFinish}
            autoComplete="off"
            className="flex flex-col md:flex-row gap-x-4"
          >
            <Form.Item<NewsletterFieldType>
              name="email"
              rules={[{ required: true, message: 'Please input your email!' }]}
            >
              <Input
                type="email"
                placeholder="Your email"
                variant="underlined"
                className="w-full md:w-[240px]! border-b-font-secondary-2! focus:border-b-canvas! placeholder:text-font-secondary-2!"
                style={{
                  border: 'none',
                  color: '#f9f9f9',
                  backgroundColor: 'transparent',
                  borderBottom: '1px solid var(--color-font-secondary-1)',
                  borderRadius: '0',
                }}
              />
            </Form.Item>

            <Form.Item label={null} className='mb-0!'>
              <button
                type="submit"
                className="flex items-center gap-x-2 -mt-6 md:mt-2 text-lg md:text-2xl text-font-primary-inverted hover:text-font-secondary-2 font-semibold cursor-pointer 
                  transition-all duration-300"
              >
                {isLoading ? loadingIcon : <>{enterIcon} Subscribe</>}
              </button>
            </Form.Item>
          </Form>
        </div>

        {/* Grid for big screen */}
        <div className="w-full hidden lg:grid grid-cols-3 gap-8">
          {paginatedPosts.slice(9, 15).map((blog, index) => (
            <BlogCard key={index} blog={blog} />
          ))}
        </div>

        {/* Grid for medium screen */}
        <div className="w-full grid lg:hidden md:grid-cols-2 gap-x-8">
          {paginatedPosts.slice(10, 14).map((blog, index) => (
            <BlogCard key={index} blog={blog} />
          ))}
        </div>

        <div className="w-full flex justify-center mt-8">
          <Pagination
            current={currentPage}
            total={filteredPosts.length}
            pageSize={pageSize}
            onChange={setCurrentPage}
            className="text-center"
          />
        </div>
      </section>
    </main>
  )
}

export default BlogPageBody
