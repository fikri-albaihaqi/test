'use client'

import Image from 'next/image'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import { BlogDetailType } from '@/app/lib/types/types'

gsap.registerPlugin(ScrollTrigger, SplitText)

const BlogDetailHeroSection = ({ blogData }: { blogData: BlogDetailType }) => {
  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <section className="relative w-full 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] mt-8 lg:mt-0">
      <div className="relative">
        <div className="relative w-full h-[240px] md:h-[730px] lg:h-[440px] xl:h-[600px] 2xl:h-[730px]">
          <Image
            src={blogData?.mainImage?.asset?.url || ''}
            alt={blogData?.mainImage?.alt || ''}
            fill
            className="object-cover rounded-xl lg:rounded-3xl"
          />
        </div>

        <div className="hidden md:block absolute w-[80%] lg:w-1/2 xl:w-[40%] top-0 pr-8 pb-8 bg-canvas dark:bg-canvas-inverted rounded-br-3xl">
          <svg
            id="Layer_1"
            className="absolute w-9 h-9 -right-[35px] top-0 text-canvas dark:text-canvas-inverted fill-current"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>
          <h1 className="text-split leading-tight text-4xl 2xl:text-5xl font-semibold">
            {blogData?.title}
          </h1>

          <svg
            id="Layer_1"
            className="absolute w-9 h-9 left-0 -bottom-[35px] text-canvas dark:text-canvas-inverted fill-current"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>
        </div>
      </div>

      <div className="flex md:hidden mt-8">
        <h1 className="text-split leading-tight text-3xl font-semibold">
          {blogData?.title}
        </h1>
      </div>
    </section>
  )
}

export default BlogDetailHeroSection
