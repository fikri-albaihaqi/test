'use client'

import { NewsletterFieldType } from '@/app/lib/types/types'
import formatDate from '@/app/lib/utils/helpers/formatDate'
import { Form, FormProps, Input, message } from 'antd'
import Link from 'next/link'
import { useEffect, useState } from 'react'

const linkedinIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 448 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z" />
  </svg>
)

const facebookIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 512 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z" />
  </svg>
)

const xIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 512 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z" />
  </svg>
)

const linkIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    <path d="M440-280H280q-83 0-141.5-58.5T80-480q0-83 58.5-141.5T280-680h160v80H280q-50 0-85 35t-35 85q0 50 35 85t85 35h160v80ZM320-440v-80h320v80H320Zm200 160v-80h160q50 0 85-35t35-85q0-50-35-85t-85-35H520v-80h160q83 0 141.5 58.5T880-480q0 83-58.5 141.5T680-280H520Z" />
  </svg>
)

const enterIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m560-120-57-57 144-143H200v-480h80v400h367L503-544l56-57 241 241-240 240Z" />
  </svg>
)

const loadingIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-current animate-spin"
  >
    <path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-155.5t86-127Q252-817 325-848.5T480-880q17 0 28.5 11.5T520-840q0 17-11.5 28.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q133 0 226.5-93.5T800-480q0-17 11.5-28.5T840-520q17 0 28.5 11.5T880-480q0 82-31.5 155t-86 127.5q-54.5 54.5-127 86T480-80Z" />
  </svg>
)

const BlogSidebar = ({
  blogTitle,
  publishedAt,
}: {
  blogTitle: string | number | boolean
  publishedAt: string | null | undefined
}) => {
  const [blogUrl, setBlogUrl] = useState('')
  const [messageApi, contextHolder] = message.useMessage()
  const [isLoading, setIsLoading] = useState(false)
  const [messageTitle, setMessageTitle] = useState(
    'Subscribe to Our Newsletter'
  )
  const [messageBody, setMessageBody] = useState(
    'Stay inspired — subscribe to our newsletter for fresh insights on design, growth, SaaS, and Marketing.'
  )

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setBlogUrl(window.location.href)
    }
  }, [])

  const onFinish: FormProps<NewsletterFieldType>['onFinish'] = async (
    values
  ) => {
    setIsLoading(true)
    const response = await fetch('/api/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: values.email }),
    })

    const data = await response.json()

    if (response.ok) {
      setIsLoading(false)
      setMessageTitle("Welcome aboard! It's great to have you with us.")
      setMessageBody(
        'From now on, you’ll be the first to hear about our latest projects, stories, and special deals.'
      )
    } else {
      setIsLoading(false)
      if (data.error === 'Member Exists') {
        setMessageTitle('This email is already registered with our newsletter.')
        setMessageBody('')
      } else {
        setMessageTitle('Oops! Something went wrong')
        setMessageBody(
          'We couldn’t process your subscription. Please try again.'
        )
      }

      console.log()
    }
  }

  return (
    <div className="xl:sticky top-8 w-full xl:w-[40%] flex flex-col">
      {contextHolder}
      <p className="text-font-secondary-1">{formatDate(publishedAt)}</p>
      <h2 className="text-2xl">Share article</h2>

      <div className="flex items-center gap-x-4 my-4 bg-canvas dark:bg-canvas-inverted rounded-br-3xl">
        <Link
          href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(blogUrl)}&title=${encodeURIComponent(blogTitle)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
        >
          {linkedinIcon}
        </Link>

        <Link
          href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(blogUrl)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
        >
          {facebookIcon}
        </Link>

        <Link
          href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(blogTitle)}&url=${encodeURIComponent(blogUrl)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
        >
          {xIcon}
        </Link>

        <button
          className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300 cursor-pointer"
          onClick={() => {
            navigator.clipboard.writeText(blogUrl)
            messageApi.success('Link copied!')
          }}
        >
          {linkIcon}
        </button>
      </div>

      <div className="w-full flex flex-col gap-y-4">
        <h3 className="text-2xl font-semibold">{messageTitle}</h3>
        <p className="text-2xl">{messageBody}</p>

        <Form
          name="blogNewsletter"
          onFinish={onFinish}
          autoComplete="off"
          className="flex flex-col md:flex-row gap-x-4"
        >
          <Form.Item<NewsletterFieldType>
            name="email"
            rules={[{ required: true, message: 'Please input your email!' }]}
          >
            <Input
              type="email"
              placeholder="Your email"
              variant="underlined"
              className="w-full md:w-[240px]! focus:border-b-brand-secondary!"
              style={{
                border: 'none',
                backgroundColor: 'transparent',
                borderBottom: '1px solid var(--color-font-secondary-1)',
                borderRadius: '0',
              }}
            />
          </Form.Item>

          <Form.Item label={null} className="mb-0!">
            <button
              type="submit"
              className="flex items-center gap-x-2 -mt-6 md:mt-2 text-lg md:text-2xl text-font-primary dark:text-font-primary-inverted hover:text-brand-secondary font-semibold 
              transition-all duration-300 cursor-pointer"
            >
              {isLoading ? loadingIcon : <>{enterIcon} Subscribe</>}
            </button>
          </Form.Item>
        </Form>
      </div>
    </div>
  )
}

export default BlogSidebar
