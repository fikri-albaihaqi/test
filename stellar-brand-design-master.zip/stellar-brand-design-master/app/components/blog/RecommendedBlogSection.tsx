'use client'

import { useRef, useState } from 'react'
import { Swiper as SwiperType } from 'swiper'
import BlogSlider from './BlogSlider'
import { BlogArrayType } from '@/app/lib/types/types'

const arrowRightIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary-inverted dark:fill-font-primary"
  >
    <path d="m560-240-56-58 142-142H160v-80h486L504-662l56-58 240 240-240 240Z" />
  </svg>
)

const arrowLeftIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary-inverted dark:fill-font-primary"
  >
    <path d="M400-240 160-480l240-240 56 58-142 142h486v80H314l142 142-56 58Z" />
  </svg>
)

const RecommendedBlogSection = ({
  recommendedPosts,
}: {
  recommendedPosts: BlogArrayType
}) => {
  const swiperRef = useRef<SwiperType | null>(null)
  const [posIsBeginning, setIsPosBeginning] = useState<boolean | undefined>(
    true
  )
  const [posIsEnd, setIsPosEnd] = useState<boolean | undefined>(false)

  const handleSwipeIndex = (index: number | undefined) => {
    if (index === 0) {
      setIsPosBeginning(true)
    } else if (index === recommendedPosts.length - 1) {
      setIsPosEnd(true)
    } else if (index !== 0 && index !== recommendedPosts.length - 1) {
      setIsPosBeginning(false)
      setIsPosEnd(false)
    }
  }

  return (
    <section className="w-full h-full flex flex-col gap-y-8 overflow-hidden">
      <div className="flex justify-between 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <h2 className="text-split text-4xl md:text-6xl font-semibold">
          Don’t Miss These Posts
        </h2>

        <div className="hidden lg:flex items-center gap-x-4">
          <button
            className={`p-2 ${
              posIsBeginning ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
            } rounded-full cursor-pointer`}
            onClick={() => {
              swiperRef.current?.slidePrev()
              setIsPosBeginning(swiperRef.current?.isBeginning)
              setIsPosEnd(swiperRef.current?.isEnd)
            }}
          >
            {arrowLeftIcon}
          </button>
          <button
            className={`p-2 ${
              posIsEnd ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
            } rounded-full cursor-pointer`}
            onClick={() => {
              swiperRef.current?.slideNext()
              setIsPosBeginning(swiperRef.current?.isBeginning)
              setIsPosEnd(swiperRef.current?.isEnd)
            }}
          >
            {arrowRightIcon}
          </button>
        </div>
      </div>

      <BlogSlider
        recommendedPosts={recommendedPosts}
        swiperRef={swiperRef}
        onIndexChange={handleSwipeIndex}
      />

      <div className="flex lg:hidden items-center justify-center gap-x-4">
        <button
          className={`p-2 ${
            posIsBeginning ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
          } rounded-full cursor-pointer`}
          onClick={() => {
            swiperRef.current?.slidePrev()
            setIsPosBeginning(swiperRef.current?.isBeginning)
            setIsPosEnd(swiperRef.current?.isEnd)
          }}
        >
          {arrowLeftIcon}
        </button>
        <button
          className={`p-2 ${
            posIsEnd ? 'bg-brand-secondary/50' : 'bg-brand-secondary'
          } rounded-full cursor-pointer`}
          onClick={() => {
            swiperRef.current?.slideNext()
            setIsPosBeginning(swiperRef.current?.isBeginning)
            setIsPosEnd(swiperRef.current?.isEnd)
          }}
        >
          {arrowRightIcon}
        </button>
      </div>
    </section>
  )
}

export default RecommendedBlogSection
