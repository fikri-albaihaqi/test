import Link from 'next/link'

const BlogFilter = ({ tags }: { tags: Array<string | null> }) => {
  return (
    <div className="w-full flex flex-wrap gap-x-4 gap-y-4">
      <Link
        href="/blog/"
        className="px-4 py-2 text-xl bg-font-secondary-3 hover:bg-brand-secondary text-font-primary hover:text-font-primary-inverted transition-all rounded-full"
      >
        All
      </Link>

      {tags.map((tag, index) => (
        <Link
          key={index}
          href={`/blog/category/${tag}`}
          className="px-4 py-2 text-xl bg-font-secondary-3 hover:bg-brand-secondary text-font-primary hover:text-font-primary-inverted transition-all rounded-full"
        >
          {tag}
        </Link>
      ))}
    </div>
  )
}

export default BlogFilter
