import { BlogType } from '@/app/lib/types/types'
import Image from 'next/image'
import Link from 'next/link'
import Tag from '../ui/tag/Tag'
import AnimatedContent from '../animation/AnimatedContent'
import formatDate from '@/app/lib/utils/helpers/formatDate'

const BlogCard = ({ blog, slider }: { blog: BlogType; slider?: boolean }) => {
  return (
    <Link
      href={`/blog/${blog.slug?.current}`}
      className="group relative h-fit flex flex-col"
    >
      <AnimatedContent
        distance={150}
        direction="vertical"
        reverse={false}
        duration={1.2}
        ease={'power3.out'}
      >
        <div
          className={`relative ${
            slider ? 'w-[320px] md:w-[512px]' : 'w-full'
          } h-[200px] md:h-[280px]`}
        >
          <Image
            src={blog.mainImage?.asset?.url || ''}
            alt={blog.mainImage?.alt || ''}
            fill
            className="object-cover rounded-2xl lg:rounded-3xl"
          />
          <div className="absolute flex flex-col -bottom-20 group-hover:bottom-0 pt-4 pr-6 bg-canvas dark:bg-canvas-inverted rounded-tr-3xl transition-all duration-300">
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 fill-canvas dark:fill-canvas-inverted"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>

            <div className="flex 2xl:hidden gap-x-2">
              {blog.tags && blog.tags?.length > 1
                ? blog.tags
                    ?.slice(1, 2)
                    .map((tag, index) => <Tag key={index} tag={tag} />)
                : blog.tags?.map((tag, index) => <Tag key={index} tag={tag} />)}
              {blog.tags && blog.tags?.length > 1 ? (
                <Tag tag={`${blog.tags?.length - 1} +`} />
              ) : (
                <></>
              )}
            </div>

            <div className="hidden 2xl:flex gap-x-2">
              {blog.tags && blog.tags?.length > 3
                ? blog.tags
                    ?.slice(1, 4)
                    .map((tag, index) => <Tag key={index} tag={tag} />)
                : blog.tags?.map((tag, index) => <Tag key={index} tag={tag} />)}
              {blog.tags && blog.tags?.length > 3 ? (
                <Tag tag={`${blog.tags?.length - 3} +`} />
              ) : (
                <></>
              )}
            </div>

            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 fill-canvas dark:fill-canvas-inverted"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
          </div>
        </div>

        <div
          className={`relative z-50 ${
            slider ? 'w-[320px] md:w-[512px]' : 'w-full'
          } flex flex-col gap-y-2 pt-4 bg-canvas dark:bg-canvas-inverted`}
        >
          <p>{formatDate(blog.publishedAt)}</p>
          <h2 className="text-2xl font-semibold">{blog.title}</h2>
        </div>
      </AnimatedContent>
    </Link>
  )
}

export default BlogCard
