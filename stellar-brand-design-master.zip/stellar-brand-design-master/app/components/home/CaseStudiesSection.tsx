'use client'

import FadeContent from '../animation/FadeContent'
import Button from '../ui/button/Button'
import ProjectGrid from '../ui/grid/ProjectGrid'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import { FeaturedProjectType } from '@/app/lib/types/types'

gsap.registerPlugin(ScrollTrigger, SplitText)

const CaseStudiesSection = ({
  projectsSectionHeading,
  projectsSectionSubHeading,
  featuredProjects,
}: {
  projectsSectionHeading: string | undefined
  projectsSectionSubHeading: string | undefined
  featuredProjects: FeaturedProjectType
}) => {
  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()
      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <section className="case-studies relative w-screen flex flex-col 2xl:px-[160px] xl:px-[80px] md:pr-[32px] pr-[16px] bg-canvas-secondary dark:bg-canvas-secondary-inverted rounded-t-3xl lg:rounded-t-4xl overflow-hidden">
      <div className="w-full flex justify-between">
        <div className="relative w-fit">
          <h2 className="text-split w-fit pl-4 pr-[23px] md:px-8 pb-2 rounded-br-xl lg:rounded-br-3xl bg-canvas dark:bg-canvas-inverted text-4xl md:text-6xl font-semibold">
            <svg
              id="Layer_1"
              className="hidden md:block absolute w-9 h-9 -left-9 top-0 rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            {projectsSectionHeading}
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -right-9 top-0 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
          </h2>
          <p className="text-split relative w-fit px-[17px] md:px-8 py-2 rounded-br-2xl lg:rounded-br-3xl xl:rounded-b-3xl bg-canvas dark:bg-canvas-inverted text-lg md:text-2xl">
            <svg
              id="Layer_1"
              className="md:block absolute w-9 h-9 -right-9 top-0 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            {projectsSectionSubHeading}
          </p>
        </div>

        <div className="relative w-1/2 self-end hidden lg:flex flex-col items-start gap-y-4 py-8 lg:py-0 pl-[16px] md:pl-[32px] mt-24">
          <FadeContent duration={1000} easing="ease-out" initialOpacity={0}>
            <div className="flex items-center gap-x-2">
              <div className="w-3 h-3 relative overflow-hidden">
                <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
              </div>
              <h2 className="text-lg font-semibold">
                Discover What We’ve Done
              </h2>
            </div>
          </FadeContent>

          <Button primary={true} link="/work">
            See our work
          </Button>
        </div>
      </div>

      <div className="relative w-full self-end flex lg:hidden flex-col items-start gap-y-4 py-8 lg:py-0 pl-[16px] md:pl-[32px]">
        <FadeContent duration={1000} easing="ease-out" initialOpacity={0}>
          <div className="flex items-center gap-x-2">
            <div className="w-[8px] h-[8px] bg-brand-primary"></div>
            <h2 className="text-lg font-semibold">Discover What We’ve Done</h2>
          </div>
        </FadeContent>

        <Button primary={true} link="/work">
          See our works
        </Button>
      </div>

      <div className="pl-[16px] md:pl-[32px] xl:pl-0">
        <ProjectGrid primaryColor={false} featuredProjects={featuredProjects} />
      </div>
    </section>
  )
}

export default CaseStudiesSection
