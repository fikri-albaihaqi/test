'use client'

import { gsap } from 'gsap'
import horizontalLoop from '@/app/lib/utils/animations/horizontalLoop'
import { useGSAP } from '@gsap/react'
import Image from 'next/image'

const LogoSlider = ({
  clientLogo,
}: {
  clientLogo: {
    logo: Array<{
      alt: string | null
      asset: {
        url: string | null
      } | null
    }> | null
  } | null
}) => {
  useGSAP(() => {
    gsap.matchMedia().add(
      {
        isSmall: '(max-width: 1023px)',
        isBig: '(min-width: 1024px)',
      },
      (context) => {
        const { isBig } = context.conditions as gsap.Conditions
        const logoBig: Array<HTMLElement> = gsap.utils.toArray(`.logo-big`)
        const logoSmall: Array<HTMLElement> = gsap.utils.toArray(`.logo-small`)

        horizontalLoop(isBig ? logoBig : logoSmall, {
          paused: false,
          repeat: -1,
          paddingRight: isBig ? '128' : '96',
          speed: 0.5,
        })
      }
    )
  })

  return (
    <>
      <div className="w-fit hidden lg:flex items-center justify-center gap-x-16 lg:gap-x-32 z-30">
        {clientLogo?.logo?.map((logo, index) => (
          <div key={index} className="relative logo-big w-[200px] h-[56px]">
            {logo.asset && (
              <Image
                src={logo.asset.url || ''}
                alt={logo.alt || ''}
                fill
                className="object-scale-down grayscale saturate-0 brightness-0 dark:brightness-[5000%]"
              />
            )}
          </div>
        ))}

        {clientLogo?.logo?.map((logo, index) => (
          <div key={index} className="relative logo-big w-[200px] h-[56px]">
            {logo.asset && (
              <Image
                src={logo.asset.url || ''}
                alt={logo.alt || ''}
                fill
                className="object-scale-down grayscale saturate-0 brightness-0 dark:brightness-[5000%]"
              />
            )}
          </div>
        ))}
      </div>

      <div className="w-fit flex lg:hidden items-center justify-center gap-x-24 overflow-hidden z-30">
        {clientLogo?.logo?.map((logo, index) => (
          <div key={index} className="relative logo-small w-[200px] h-[56px]">
            {logo.asset && (
              <Image
                src={logo.asset.url || ''}
                alt={logo.alt || ''}
                fill
                className="object-scale-down grayscale saturate-0 brightness-0 dark:brightness-[5000%]"
              />
            )}
          </div>
        ))}

        {clientLogo?.logo?.map((logo, index) => (
          <div key={index} className="relative logo-small w-[200px] h-[56px]">
            {logo.asset && (
              <Image
                src={logo.asset.url || ''}
                alt={logo.alt || ''}
                fill
                className="object-scale-down grayscale saturate-0 brightness-0 dark:brightness-[5000%]"
              />
            )}
          </div>
        ))}
      </div>
    </>
  )
}

export default LogoSlider
