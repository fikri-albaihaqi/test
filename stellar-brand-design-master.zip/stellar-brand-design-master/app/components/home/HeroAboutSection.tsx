'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import Button from '../ui/button/Button'
import CardSwap, { Card } from './CardSwap'
import Image from 'next/image'
import LogoSlider from './LogoSlider'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import React, { useEffect, useRef, useState } from 'react'
import { PortableText } from 'next-sanity'
import BlockText from '../ui/text/BlockText'
import { TypedObject } from 'sanity'
import ScrollReveal from '../animation/ScrollReveal'
import useViewport from '@/app/lib/utils/helpers/useViewport'

gsap.registerPlugin(ScrollTrigger)

const HeroAboutSection = ({
  desktopVideoUrl,
  mobileVideoUrl,
  heroHeadingLine1,
  heroHeadingLine2,
  about,
  aboutSectionProjects,
  clientLogo,
}: {
  desktopVideoUrl: string
  mobileVideoUrl: string
  heroHeadingLine1: TypedObject | TypedObject[]
  heroHeadingLine2: TypedObject | TypedObject[]
  about: TypedObject | TypedObject[]
  aboutSectionProjects:
    | {
        _id: string
        client: string | null
        images: {
          _key: string
          _type: 'image'
          asset: {
            url: string | null
          } | null
          alt: string | null
        } | null
      }[]
    | null
    | undefined
  clientLogo: {
    logo: Array<{
      alt: string | null
      asset: {
        url: string | null
      } | null
    }> | null
  } | null
}) => {
  const { width } = useViewport()
  const heroTextBreakpoints = 768
  const cardSwapLgBreakpoints = 1024
  const cardSwapXlBreakpoints = 1280
  const cardSwap2XlBreakpoints = 1536

  const firstLineTextRef = useRef<HTMLSpanElement>(null)
  const secondLineTextRef = useRef<HTMLSpanElement>(null)

  const [firstLineTextWidth, setFirstLineTextWidth] = useState(0)
  const [isFirstLineWider, setIsFirstLineWider] = useState(false)

  useEffect(() => {
    const updateWidths = () => {
      if (firstLineTextRef.current && secondLineTextRef.current) {
        const firstWidth =
          firstLineTextRef.current.getBoundingClientRect().width
        const secondWidth =
          secondLineTextRef.current.getBoundingClientRect().width

        setFirstLineTextWidth(firstWidth)
        setIsFirstLineWider(firstWidth >= secondWidth)
      }
    }

    if (document.fonts) {
      document.fonts.ready.then(() => {
        setTimeout(updateWidths, 50)
      })
    }

    const observer = new ResizeObserver(updateWidths)

    if (firstLineTextRef.current) observer.observe(firstLineTextRef.current)
    if (secondLineTextRef.current) observer.observe(secondLineTextRef.current)

    return () => observer.disconnect()
  }, [])

  useGSAP(() => {
    gsap.matchMedia().add(
      {
        isXl: '(min-width: 1025px)',
      },
      (context) => {
        const { isXl } = context.conditions as gsap.Conditions

        if (!isXl) return

        const aboutSection = document.querySelector('.about')
        const caseStudiesSection = document.querySelector('.case-studies')

        if (!aboutSection) {
          console.warn(
            'About section not found, skipping background animation.'
          )
          return
        }

        // Function to get the current computed value of a CSS custom property
        const getCssVar = (varName: string) =>
          getComputedStyle(document.documentElement)
            .getPropertyValue(varName)
            .trim()

        const initialColorCanvas = getCssVar('--color-canvas')
        const initialColorCanvasInverted = getCssVar('--color-canvas-inverted')
        const targetLightBodyColor = '#d2e6f4'
        const targetDarkBodyColor = '#111111'

        // Change bg color when scroll in to about section
        const bgAboutSectionTimeline = gsap.timeline({
          scrollTrigger: {
            trigger: aboutSection,
            start: 'top center',
            end: 'bottom bottom',
            toggleActions: 'play none none reverse',
          },
          defaults: { ease: 'power3.inOut' },
        })

        bgAboutSectionTimeline.fromTo(
          document.documentElement,
          {
            duration: 0.5,
            '--color-canvas': initialColorCanvas,
            '--color-canvas-inverted': initialColorCanvasInverted,
          },
          {
            duration: 0.5,
            '--color-canvas': targetLightBodyColor,
            '--color-canvas-inverted': targetDarkBodyColor,
          }
        )

        // Change the bg color back when scroll in to case studies section
        const bgAboutSectionTimelineEnd = gsap.timeline({
          scrollTrigger: {
            trigger: caseStudiesSection,
            start: 'top top',
            end: 'center center',
            scrub: true,
          },
          defaults: { ease: 'none' },
        })

        bgAboutSectionTimelineEnd.to(document.documentElement, {
          '--color-canvas': initialColorCanvas,
          '--color-canvas-inverted': initialColorCanvasInverted,
        })
        ScrollTrigger.refresh()
      }
    )
  }, [])

  return (
    <>
      {/* Hero section */}
      <section className="relative w-full 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] mt-8 lg:mt-0 overflow-hidden">
        <div
          className="relative w-full 2xl:h-[720px] h-[500px] md:h-[600px] lg:aspect-video md:aspect-1/1 aspect-9/16 rounded-xl lg:rounded-3xl transform-gpu 
          bg-canvas-secondary-shade dark:bg-font-secondary-1"
        >
          <video
            className="absolute w-full h-full top-0 left-0 object-cover object-bottom md:object-center rounded-xl lg:rounded-3xl"
            playsInline
            autoPlay
            loop
            muted
            preload="auto"
          >
            <source
              src={mobileVideoUrl}
              type="video/mp4"
              media="(max-width: 1023px)"
            />
            <source src={desktopVideoUrl} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>

        <div className="absolute bottom-0 2xl:left-72 xl:left-40 lg:left-32 md:left-0">
          <div className="relative w-fit flex gap-x-4 md:px-6 md:py-4 xl:py-6 pt-4 bg-canvas dark:bg-canvas-inverted rounded-tr-3xl md:rounded-t-3xl">
            <svg
              id="Layer_1"
              className="lg:hidden block absolute w-9 h-9 -left-[0.8px] md:left-8 -top-[35px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            <Button primary={true} link="/work">
              See our work
            </Button>
            <Button primary={false} link="/about" className="hidden md:flex">
              About us
            </Button>
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
          </div>

          <div>
            {width < heroTextBreakpoints ? (
              <h1 className="relative w-[90%] flex flex-col text-2xl font-semibold">
                <span className="text-split w-fit pr-2 pt-4 bg-canvas dark:bg-canvas-inverted rounded-tr-3xl">
                  <PortableText
                    value={heroHeadingLine1}
                    components={BlockText}
                  />{' '}
                  <PortableText
                    value={heroHeadingLine2}
                    components={BlockText}
                  />
                </span>
                <svg
                  id="Layer_1"
                  className="absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  x="0"
                  y="0"
                  viewBox="0 0 100 100"
                >
                  <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
                </svg>
              </h1>
            ) : (
              <h1 className="flex flex-col xl:text-5xl md:text-3xl font-semibold">
                <span
                  ref={firstLineTextRef}
                  className="text-split relative w-fit px-6 xl:pt-4 pt-2 xl:pb-4 bg-canvas dark:bg-canvas-inverted rounded-tr-3xl"
                >
                  <PortableText
                    value={heroHeadingLine1}
                    components={BlockText}
                  />
                  <svg
                    id="Layer_1"
                    className={`${isFirstLineWider ? 'hidden' : 'block'} absolute w-9 h-9 -right-8.5 bottom-0 -rotate-90 text-canvas dark:text-canvas-inverted fill-current`}
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    x="0"
                    y="0"
                    viewBox="0 0 100 100"
                  >
                    <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
                  </svg>
                </span>
                <span
                  ref={secondLineTextRef}
                  className="text-split relative px-6 xl:pt-4 pt-2 bg-canvas dark:bg-canvas-inverted"
                  style={{
                    width: isFirstLineWider
                      ? `${firstLineTextWidth}px`
                      : 'fit-content',
                    borderTopRightRadius: isFirstLineWider ? '0px' : '24px',
                  }}
                >
                  <svg
                    id="Layer_1"
                    className="absolute w-9 h-9 -left-8.5 bottom-0 rotate-180 text-canvas dark:text-canvas-inverted fill-current"
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    x="0"
                    y="0"
                    viewBox="0 0 100 100"
                  >
                    <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
                  </svg>
                  <PortableText
                    value={heroHeadingLine2}
                    components={BlockText}
                  />
                  <svg
                    id="Layer_1"
                    className="absolute w-9 h-9 -right-8.5 bottom-0 -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    x="0"
                    y="0"
                    viewBox="0 0 100 100"
                  >
                    <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
                  </svg>
                </span>
              </h1>
            )}
          </div>
        </div>
      </section>

      {/* About section */}
      <section className="about w-full flex flex-col justify-center gap-y-16 xl:gap-y-40 xl:pt-16 overflow-hidden">
        <div className="w-full flex flex-col md:flex-row justify-between md:items-center 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
          <div className="lg:w-1/2">
            <div className="flex items-center gap-x-2 mb-1 md:mb-2">
              <div className="w-3 h-3 relative overflow-hidden">
                <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
              </div>
              <h2 className="text-lg font-semibold">About us</h2>
            </div>
            <ScrollReveal
              baseOpacity={0.1}
              enableBlur={true}
              baseRotation={0}
              blurStrength={10}
              textClassName="text-2xl md:text-3xl 2xl:text-5xl leading-tight font-semibold"
            >
              <PortableText value={about} components={BlockText} />
            </ScrollReveal>

            <div className="relative w-fit flex gap-x-4 mt-4">
              <Button primary={true} link="/services">
                See our services
              </Button>
              <Button primary={false} link="/about">
                About us
              </Button>
            </div>
          </div>

          {width >= cardSwapLgBreakpoints && width < cardSwapXlBreakpoints ? (
            <div className="relative w-1/2 h-[400px] shrink-0">
              <CardSwap
                width={300}
                height={200}
                cardDistance={30}
                verticalDistance={40}
                delay={3000}
                pauseOnHover={false}
                skewAmount={6}
              >
                {aboutSectionProjects?.map((project, index) => (
                  <Card key={index}>
                    {project.images && (
                      <Image
                        src={project.images.asset?.url || ''}
                        alt={project.images.alt || ''}
                        fill
                        className="object-cover rounded-3xl"
                      />
                    )}
                    <h2 className="absolute bottom-0 m-4 text-font-primary-inverted">
                      {project.client}
                    </h2>
                  </Card>
                ))}
              </CardSwap>
            </div>
          ) : width >= cardSwapXlBreakpoints &&
            width < cardSwap2XlBreakpoints ? (
            <div className="relative w-1/2 h-[400px]">
              <CardSwap
                width={400}
                height={300}
                cardDistance={50}
                delay={3000}
                pauseOnHover={false}
                skewAmount={6}
              >
                {aboutSectionProjects?.map((project) => (
                  <Card key={project._id}>
                    {project.images && (
                      <Image
                        src={project.images.asset?.url || ''}
                        alt={project.images.alt || ''}
                        fill
                        className="object-cover rounded-3xl"
                      />
                    )}
                    <h2 className="absolute bottom-0 m-4 text-font-primary-inverted">
                      {project.client}
                    </h2>
                  </Card>
                ))}
              </CardSwap>
            </div>
          ) : width >= cardSwap2XlBreakpoints ? (
            <div className="hidden 2xl:block relative w-1/2 h-[400px]">
              <CardSwap
                cardDistance={60}
                delay={3000}
                pauseOnHover={false}
                skewAmount={6}
              >
                {aboutSectionProjects?.map((project) => (
                  <Card key={project._id}>
                    {project.images && (
                      <Image
                        src={project.images.asset?.url || ''}
                        alt={project.images.alt || ''}
                        fill
                        className="object-cover rounded-3xl"
                      />
                    )}
                    <h2 className="absolute bottom-0 m-4 text-font-primary-inverted">
                      {project.client}
                    </h2>
                  </Card>
                ))}
              </CardSwap>
            </div>
          ) : (
            <></>
          )}
        </div>

        <LogoSlider clientLogo={clientLogo} />
      </section>
    </>
  )
}

export default HeroAboutSection
