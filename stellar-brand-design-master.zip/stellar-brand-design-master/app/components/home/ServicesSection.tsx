'use client'

import Button from '../ui/button/Button'
import Image from 'next/image'
import AnimatedContent from '../animation/AnimatedContent'
import { Swiper, SwiperSlide } from 'swiper/react'
import { useRef, useEffect, useCallback } from 'react'
import { Swiper as SwiperType } from 'swiper'
import { Autoplay } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/autoplay'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'
import BlockText from '../ui/text/BlockText'
import { FeaturedServicesType } from '@/app/lib/types/types'
import useViewport from '@/app/lib/utils/helpers/useViewport'

const arrowRightIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="40px"
    viewBox="0 -960 960 960"
    width="40px"
    className="fill-font-primary dark:group-hover:fill-font-primary-inverted transition-all"
  >
    <path d="m560-240-56-58 142-142H160v-80h486L504-662l56-58 240 240-240 240Z" />
  </svg>
)

const ServicesSection = ({
  servicesSectionHeading,
  servicesSectionDescription,
  featuredServices,
}: {
  servicesSectionHeading: string | undefined
  servicesSectionDescription: TypedObject | TypedObject[]
  featuredServices: FeaturedServicesType
}) => {
  const { width } = useViewport()
  const breakpoints = 1024
  const swiperRef = useRef<SwiperType>(null)
  const isPointerDownRef = useRef(false)

  const stopAutoplay = (source: string = '') => {
    if (swiperRef.current && swiperRef.current.autoplay.running) {
      swiperRef.current.autoplay.stop()
      console.log(`Autoplay Stopped: ${source}`)
    } else {
      console.log(`Autoplay already stopped or not running: ${source}`)
    }
  }

  const startAutoplay = (source: string = '') => {
    if (
      swiperRef.current &&
      swiperRef.current.autoplay &&
      !isPointerDownRef.current
    ) {
      if (!swiperRef.current.autoplay.running) {
        swiperRef.current.autoplay.start()
        console.log(`Autoplay Started: ${source}`)
      } else {
        console.log(`Autoplay already running: ${source}`)
      }
    } else {
      console.log(
        `Autoplay not started (pointer down or ref missing): ${source}`
      )
    }
  }

  const setEqualSlideHeight = useCallback(() => {
    if (!swiperRef.current) return

    const slides = swiperRef.current.slides
    if (slides.length === 0) return

    let maxHeight = 0

    slides.forEach((slide) => {
      const panelContent = slide.querySelector('.panel')
      if (panelContent) {
        maxHeight = Math.max(maxHeight, panelContent.scrollHeight)
      }
    })

    slides.forEach((slide) => {
      const panelContent = slide.querySelector('.panel') as HTMLElement
      if (panelContent) {
        panelContent.style.height = `${maxHeight}px`
        ;(slide as HTMLElement).style.height = `${maxHeight}px`
      }
    })

    swiperRef.current.update()
  }, [])

  useEffect(() => {
    const swiperInstance = swiperRef.current
    if (swiperInstance) {
      swiperInstance.on('resize', setEqualSlideHeight)
    }

    return () => {
      if (swiperInstance) {
        swiperInstance.off('resize', setEqualSlideHeight)
      }
    }
  }, [setEqualSlideHeight])

  return (
    <section className="services w-screen flex flex-col justify-center items-center pt-8 overflow-hidden">
      <div className="flex flex-col xl:flex-row items-end gap-y-4 gap-x-16 mb-4 2xl:mb-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="xl:w-1/2 flex flex-col self-start">
          <div className="flex items-center gap-x-2 mb-1 md:mb-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-split text-lg font-semibold">What we do</h2>
          </div>
          <p className="text-split text-4xl lg:text-6xl font-semibold">
            {servicesSectionHeading}
          </p>
        </div>

        <div className="xl:w-1/2 flex flex-col items-start gap-y-4">
          <p className="text-split text-xl 2xl:text-2xl">
            <PortableText
              value={servicesSectionDescription}
              components={BlockText}
            />
          </p>
          <Button primary={true} link="/services">
            See our services
          </Button>
        </div>
      </div>

      {width <= breakpoints ? (
        <div className="flex flex-col gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
          {featuredServices?.map((service, index) => (
            <div
              key={index}
              className="relative w-full flex flex-col border-[0.5px] border-font-secondary-2 dark:border-font-secondary-1 rounded-2xl lg:rounded-3xl"
            >
              <AnimatedContent
                distance={50}
                direction="vertical"
                reverse={false}
                duration={1.2}
                ease={'power3.out'}
              >
                <div className="relative w-full h-[280px] md:h-[50vh] bg-cover bg-center">
                  <Image
                    src={service.mainImage?.asset?.url || ''}
                    alt={service.mainImage?.alt || ''}
                    fill
                    className="object-cover rounded-t-2xl lg:rounded-t-3xl"
                  />

                  <p className="absolute w-fit bottom-0 px-[16px] py-2 text-xl md:text-2xl font-semibold bg-canvas-secondary dark:bg-canvas-secondary-inverted rounded-tr-2xl">
                    <svg
                      id="Layer_1"
                      className="absolute w-9 h-9 left-0 -top-9 -rotate-90 text-canvas-secondary dark:text-canvas-secondary-inverted fill-current"
                      version="1.1"
                      xmlns="http://www.w3.org/2000/svg"
                      x="0"
                      y="0"
                      viewBox="0 0 100 100"
                    >
                      <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
                    </svg>
                    {service.name}
                    <svg
                      id="Layer_1"
                      className="absolute w-9 h-9 -right-9 bottom-0 -rotate-90 text-canvas-secondary dark:text-canvas-secondary-inverted fill-current"
                      version="1.1"
                      xmlns="http://www.w3.org/2000/svg"
                      x="0"
                      y="0"
                      viewBox="0 0 100 100"
                    >
                      <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
                    </svg>
                  </p>
                </div>
              </AnimatedContent>

              <div className="flex flex-col gap-y-4 pt-4 bg-canvas-secondary dark:bg-canvas-secondary-inverted rounded-b-2xl lg:rounded-b-3xl">
                <AnimatedContent
                  distance={50}
                  direction="vertical"
                  reverse={false}
                  duration={1.2}
                  ease={'power3.out'}
                  className="[&>p]:text-xl [&>p]:md:text-2xl [&>p]:px-[16px]"
                >
                  <PortableText
                    value={service.heroTitle as TypedObject | TypedObject[]}
                  />
                </AnimatedContent>

                <div className="relative w-full flex flex-col gap-x-4 gap-y-4 px-[16px]">
                  {service.stats &&
                    service.stats.map((stat, index) => (
                      <div key={index} className="relative text-xl">
                        <AnimatedContent
                          distance={50}
                          direction="vertical"
                          reverse={false}
                          duration={1.2}
                          ease={'power3.out'}
                        >
                          <div className="flex items-center gap-x-6">
                            <div className="w-3 h-3 relative overflow-hidden shrink-0">
                              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
                            </div>
                            <span className="text-xl md:text-2xl">{stat}</span>
                          </div>
                        </AnimatedContent>
                      </div>
                    ))}
                </div>

                <AnimatedContent
                  distance={50}
                  direction="vertical"
                  reverse={false}
                  duration={1.2}
                  ease={'power3.out'}
                  className="overflow-hidden px-[16px] pb-[16px]"
                >
                  <Button
                    primary={true}
                    link={`/services/${service.slug?.current}`}
                    className="overflow-hidden"
                  >
                    Find out more
                  </Button>
                </AnimatedContent>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="relative w-screen hidden min-[1025px]:block">
          <Swiper
            slidesPerView={'auto'}
            loop={true}
            autoplay={{
              delay: 6000,
              disableOnInteraction: false,
            }}
            modules={[Autoplay]}
            breakpoints={{
              1025: {
                spaceBetween: 64,
                slidesOffsetBefore: 32,
                slidesOffsetAfter: 32,
              },
              1280: {
                spaceBetween: 128,
                slidesOffsetBefore: 80,
                slidesOffsetAfter: 80,
              },
              1536: {
                spaceBetween: 80,
                slidesOffsetBefore: 160,
                slidesOffsetAfter: 160,
              },
            }}
            className="w-full h-full [&_.swiper-wrapper]:items-stretch"
            onSwiper={(swiper: SwiperType) => {
              swiperRef.current = swiper
              setTimeout(() => {
                setEqualSlideHeight()
              }, 0)
            }}
            onMouseEnter={() => {
              if (swiperRef.current && swiperRef.current.autoplay) {
                swiperRef.current.autoplay.pause()
                console.log('Swiper: Mouse Enter - Autoplay Paused')
              }
            }}
            onMouseLeave={() => {
              if (
                swiperRef.current &&
                swiperRef.current.autoplay &&
                !isPointerDownRef.current
              ) {
                swiperRef.current.autoplay.resume()
                console.log(
                  'Swiper: Mouse Leave - Autoplay Resumed (if not holding)'
                )
              }
            }}
          >
            <button
              className={`group absolute z-40 translate-x-[32px] xl:translate-x-[80px] 2xl:translate-x-[160px] left-[932px] min-[1536px]:left-[1256px] top-1/4 p-6 bg-white 
              hover:bg-canvas dark:hover:bg-canvas-inverted transition-all rounded-full cursor-pointer`}
              onClick={() => {
                swiperRef.current?.slideNext()
              }}
              aria-label='Next service'
            >
              {arrowRightIcon}
            </button>
            {featuredServices?.map((service, index) => (
              <SwiperSlide key={index} className="w-auto!">
                <div
                  onPointerDown={() => {
                    isPointerDownRef.current = true
                    stopAutoplay('Pointer Down')
                  }}
                  onPointerUp={() => {
                    isPointerDownRef.current = false
                    startAutoplay('Pointer Up')
                  }}
                  className="panel w-[980px] 2xl:w-[1300px] 2xl:min-h-[60vh] flex justify-center items-center gap-x-8 2xl:gap-x-16 pl-8 pr-16 py-4 2xl:py-8 2xl:px-16 bg-brand-secondary 
                  dark:bg-canvas-secondary-inverted text-font-primary-inverted rounded-2xl xl:rounded-3xl"
                >
                  <div className="relative w-1/3 aspect-square">
                    <Image
                      src={service.mainImage?.asset?.url || ''}
                      alt={service.mainImage?.alt || ''}
                      fill
                      className="object-cover rounded-2xl lg:rounded-3xl"
                    />
                  </div>

                  <div className="w-2/3 flex flex-col items-start gap-y-2 2xl:gap-y-4">
                    <AnimatedContent
                      distance={50}
                      direction="vertical"
                      reverse={false}
                      duration={1.2}
                      ease={'power3.out'}
                    >
                      <h2 className="font-semibold text-3xl 2xl:text-4xl">
                        {service.name}
                      </h2>
                    </AnimatedContent>

                    <AnimatedContent
                      distance={50}
                      direction="vertical"
                      reverse={false}
                      duration={1.2}
                      ease={'power3.out'}
                      className="flex flex-col items-start [&>p]:2xl:text-xl [&>p]:mb-4"
                    >
                      <PortableText
                        value={service.heroTitle as TypedObject | TypedObject[]}
                      />
                      <Button
                        primary={true}
                        link={`/services/${service.slug?.current}`}
                        className="[&_svg]:fill-font-primary-inverted! overflow-hidden"
                      >
                        Find out more
                      </Button>
                    </AnimatedContent>

                    <div className="relative w-full flex flex-col flex-wrap">
                      {service.stats &&
                        service.stats.map((stat, statIndex) => (
                          <div
                            key={statIndex}
                            className="relative flex justify-between items-center gap-x-4 my-1 2xl:my-2 2xl:text-xl"
                          >
                            <AnimatedContent
                              distance={50}
                              direction="vertical"
                              reverse={false}
                              duration={1.2}
                              ease={'power3.out'}
                            >
                              <div className="flex items-center gap-x-6">
                                <div className="w-3 h-3 relative overflow-hidden shrink-0">
                                  <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
                                </div>
                                <span className="leading-normal">{stat}</span>
                              </div>
                            </AnimatedContent>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      )}
    </section>
  )
}

export default ServicesSection
