import Image from 'next/image'
import ScrollReveal from '../animation/ScrollReveal'

const ClientLogo = ({
  heading,
  clientLogo,
}: {
  heading: string | null | undefined
  clientLogo: {
    logo: Array<{
      alt: string | null
      asset: {
        url: string | null
      } | null
    }> | null
  } | null
}) => {
  return (
    <section className="2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
      <div className="flex flex-col">
        <div className="flex items-center gap-x-2 mb-1 md:mb-2">
          <div className="w-3 h-3 relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
          </div>
          <h2 className="text-lg font-semibold">Our Clients</h2>
        </div>
        <ScrollReveal
          baseOpacity={0.1}
          enableBlur={true}
          baseRotation={0}
          blurStrength={10}
          textClassName="text-4xl md:text-6xl font-semibold"
        >
          {heading}
        </ScrollReveal>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 md:gap-4 mt-16">
        {clientLogo?.logo?.map((item, index) => (
          <div
            key={index}
            className="group flex items-center justify-center bg-font-secondary-3 hover:bg-brand-secondary-2 dark:bg-canvas-secondary-inverted 
              dark:hover:bg-canvas-secondary-inverted-shade rounded-xl md:rounded-3xl px-8 py-8 md:py-16 xl:py-24 2xl:py-32 transition-all duration-300"
          >
            <div className="relative w-[240px] h-[80px] flex items-center justify-center">
              <Image
                src={item.asset?.url || ''}
                alt={item.alt || ''}
                fill
                className="relative! w-auto! object-scale-down scale-100 group-hover:scale-105 grayscale saturate-0 brightness-0 dark:brightness-[5000%] transition-all duration-300"
              />
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default ClientLogo
