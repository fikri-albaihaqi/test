'use client'

import { Ref, useRef } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/dist/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import ScrollReveal from '../animation/ScrollReveal'
import { Slug } from '@/sanity/types'
import FadeContent from '../animation/FadeContent'
import Link from 'next/link'
import Image from 'next/image'

gsap.registerPlugin(ScrollTrigger, useGSAP)

const arrowIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m256-240-56-56 384-384H240v-80h480v480h-80v-344L256-240Z" />
  </svg>
)

export default function HighlightScrollList({
  heading,
  services,
}: {
  heading: string | null | undefined
  services: Array<{
    _id: string
    name: string | null
    slug: null
    shortDescription: string | null
    services: Array<{
      _id: string
      name: string | null
      slug: Slug | null
      mainImage: {
        asset: {
          url: string | null
        } | null
        alt: string | null
      } | null
    }>
  }>
}) {
  const containerRef = useRef(null)
  const itemsRef = useRef<Array<HTMLDivElement | null>>([])
  const headerRef = useRef(null)
  const setItemRef =
    (index: number): Ref<HTMLDivElement> =>
    (el: HTMLDivElement | null) => {
      itemsRef.current[index] = el
    }

  useGSAP(
    () => {
      // Set initial state for all items (blurred and faded)
      gsap.set(itemsRef.current, {
        opacity: 0.4,
        filter: 'blur(4px)',
        scale: 0.95,
        immediateRender: true, // Render immediately without animation
      })

      // Create faster scroll triggers for each item
      itemsRef.current.forEach((item, i) => {
        ScrollTrigger.create({
          trigger: item,
          start: 'top center',
          end: 'bottom center',
          onEnter: () => highlightItem(i),
          onEnterBack: () => highlightItem(i),
          onLeave: () => unhighlightItem(i),
          onLeaveBack: () => unhighlightItem(i),
          // Faster response by reducing the scroll distance needed
          scrub: 0.5, // Reduced from default 1 for faster response
        })
      })

      // Highlight function with faster animation
      function highlightItem(index: number) {
        // First quickly unhighlight all items
        gsap.to(itemsRef.current, {
          opacity: 0.4,
          filter: 'blur(4px)',
          scale: 0.95,
          duration: 0.2, // Faster transition out (200ms)
          ease: 'power1.out',
        })

        // Then highlight the current item quickly
        gsap.to(itemsRef.current[index], {
          opacity: 1,
          filter: 'blur(0px)',
          scale: 1,
          duration: 0.3, // Faster transition in (300ms)
          ease: 'power2.out',
        })

        // Active state visuals
        gsap.to(`.highlight-border-${index}`, {
          opacity: 1,
          duration: 0.2,
        })
      }

      // Unhighlight function with faster animation
      function unhighlightItem(index: number) {
        gsap.to(itemsRef.current[index], {
          opacity: 0.4,
          filter: 'blur(4px)',
          scale: 0.95,
          duration: 0.2, // Faster transition out (200ms)
          ease: 'power1.out',
        })

        // Remove active state visuals
        gsap.to(`.highlight-border-${index}`, {
          opacity: 0,
          duration: 0.1,
        })
      }

      // Header animation (faster entrance)
      gsap.from(headerRef.current, {
        opacity: 0,
        y: 30,
        duration: 0.5, // Faster entrance (500ms)
        ease: 'power2.out',
      })
    },
    { scope: containerRef }
  )

  return (
    <section
      ref={containerRef}
      className="relative w-full flex flex-col xl:flex-row justify-between xl:gap-x-16 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]"
    >
      <div className="lg:sticky xl:w-[40%] h-fit xl:top-[20%] 2xl:top-1/3 flex flex-col mb-8 lg:mb-0">
        <div className="flex items-center gap-x-2 mb-1 md:mb-2">
          <div className="w-3 h-3 relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
          </div>
          <h2 className="text-lg font-semibold">Our Expertise</h2>
        </div>
        <ScrollReveal
          baseOpacity={0.1}
          enableBlur={true}
          baseRotation={0}
          blurStrength={10}
          textClassName="text-4xl md:text-6xl font-semibold"
        >
          {heading}
        </ScrollReveal>
      </div>

      <div className="xl:w-[60%]">
        <div className="space-y-8 md:space-y-16 lg:space-y-24">
          {services.map((service, index) => (
            <div
              key={service._id}
              ref={setItemRef(index)}
              className="flex flex-col gap-y-4 md:gap-y-8 relative px-6 py-8 md:p-8 bg-brand-secondary-2 dark:bg-brand-secondary-3 border-gradient-animate rounded-xl md:rounded-3xl"
            >
              <div className="flex flex-col lg:flex-row justify-between gap-x-8">
                <div className="w-full flex flex-col gap-y-4">
                  <h2 className="text-split text-3xl lg:text-5xl font-semibold">
                    {service.name}
                  </h2>

                  <div className="w-full flex flex-col lg:flex-row gap-x-8 gap-y-4">
                    <FadeContent
                      duration={1000}
                      easing="ease-out"
                      initialOpacity={0}
                      className="w-full lg:w-1/2 text-lg 2xl:text-xl"
                    >
                      <p>{service.shortDescription}</p>
                    </FadeContent>

                    <div className="relative w-full lg:w-1/2 flex flex-col">
                      {service.services.map((subService, index) => (
                        <Link
                          href={`/services/${subService.slug?.current}`}
                          key={index}
                          className="relative text-split flex justify-between items-center gap-x-4 text-2xl transition-all before:w-0 before:h-[1px] before:absolute before:-bottom-2 
                            before:right-0 before:transition-all before:duration-500 hover:before:w-full hover:before:left-0 hover:before:bg-font-secondary-1"
                        >
                          <div className="flex items-end gap-x-4">
                            <span className="text-lg 2xl:text-xl text-font-secondary-1 font-light shrink-0">
                              0{index + 1}
                            </span>{' '}
                            <span className="text-lg 2xl:text-xl leading-normal">
                              {subService.name}
                            </span>
                          </div>

                          {arrowIcon}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative w-full h-[200px] md:h-[380px] 2xl:h-[460px]">
                <Image
                  src={
                    (service.services[0].mainImage &&
                      service.services[0].mainImage.asset?.url) ||
                    ''
                  }
                  alt={
                    (service.services[0].mainImage &&
                      service.services[0].mainImage.alt) ||
                    ''
                  }
                  fill
                  className="object-cover rounded-xl lg:rounded-3xl"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
