'use client'

import { useRef, useState } from 'react'

const pauseIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-canvas dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    <path d="M560-200v-560h160v560H560Zm-320 0v-560h160v560H240Z" />
  </svg>
)

const playIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-canvas dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    <path d="M320-200v-560l440 280-440 280Z" />
  </svg>
)

const AboutSection = ({
  stats,
  desktopHeroVideo,
  mobileHeroVideo,
}: {
  stats?:
    | {
        name?: string | undefined
        statistic?: string | undefined
        _type: 'statItem'
        _key: string
      }[]
    | null
    | undefined
  desktopHeroVideo:
    | {
        asset: {
          url: string | null
        } | null
      }
    | null
    | undefined
  mobileHeroVideo:
    | {
        asset: {
          url: string | null
        } | null
      }
    | null
    | undefined
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const [isPlaying, setIsPlaying] = useState<boolean>(true)

  const togglePlay = () => {
    if (videoRef.current?.paused) {
      videoRef.current?.play()
      setIsPlaying(true)
    } else {
      videoRef.current?.pause()
      setIsPlaying(false)
    }
  }

  return (
    <section className="w-full about flex flex-col items-center gap-y-16 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
      <div className="w-full grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-16">
        {stats?.map((item) => (
          <div key={item._key} className="flex flex-col items-center gap-y-8">
            <p className="text-split text-center text-5xl xl:text-8xl font-semibold text-brand-secondary">
              {item.statistic}
            </p>
            <h2 className="text-split text-center text-lg xl:text-2xl font-semibold">
              {item.name}
            </h2>
          </div>
        ))}
      </div>

      <div
        className="relative w-full h-[500px] md:h-[600px] 2xl:h-full lg:aspect-video md:aspect-1/1 aspect-9/16 rounded-3xl transform-gpu bg-canvas-secondary-shade 
        dark:bg-font-secondary-1"
      >
        <video
          ref={videoRef}
          className="absolute w-full h-full top-0 left-0 object-cover rounded-3xl"
          playsInline
          autoPlay
          loop
          muted
        >
          <source
            src={mobileHeroVideo?.asset?.url || ''}
            type="video/mp4"
            media="(max-width: 1023px)"
          />
          <source src={desktopHeroVideo?.asset?.url || ''} type="video/mp4" />
          Your browser does not support the video tag.
        </video>

        <div
          className={`absolute flex flex-col bottom-0 pt-4 pr-6 rounded-tr-3xl bg-canvas dark:bg-canvas-inverted`}
        >
          <svg
            id="Layer_1"
            className={`absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 fill-canvas dark:fill-canvas-inverted`}
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>

          <button
            className="group flex gap-x-1 px-4 py-1.5 rounded-full bg-brand-primary hover:bg-canvas-inverted dark:hover:bg-canvas text-font-primary-inverted 
                hover:text-font-inverted dark:hover:text-font-primary font-semibold transition-all duration-300 cursor-pointer"
            onClick={togglePlay}
          >
            {isPlaying ? 'Pause' : 'Play'} {isPlaying ? pauseIcon : playIcon}
          </button>

          <svg
            id="Layer_1"
            className={`absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 fill-canvas dark:fill-canvas-inverted`}
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>
        </div>
      </div>
    </section>
  )
}

export default AboutSection
