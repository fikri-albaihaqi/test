'use client'

import { TeamMembersQueryResult } from '@/app/lib/types/types'
import horizontalLoop from '@/app/lib/utils/animations/horizontalLoop'
import { useGSAP } from '@gsap/react'
import { gsap } from 'gsap'
import TeamMemberCard from './TeamMemberCard'

const MemberTicker = ({ members }: { members: TeamMembersQueryResult }) => {
  useGSAP(() => {
    const projects: Array<HTMLElement> = gsap.utils.toArray(`.member-card`)

    horizontalLoop(projects, {
      paused: false,
      repeat: -1,
      paddingRight: '32',
      speed: 0.3,
    })
  })

  return (
    <div className="relative w-fit flex self-center gap-x-8 overflow-hidden">
      {members?.map((member, index) => (
        <TeamMemberCard key={index} member={member} index={index} />
      ))}
    </div>
  )
}

export default MemberTicker
