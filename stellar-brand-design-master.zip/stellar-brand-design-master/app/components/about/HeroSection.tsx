'use client'

import Image from 'next/image'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { FeaturedProjectType } from '@/app/lib/types/types'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'
import BlockText from '../ui/text/BlockText'
import { useRef } from 'react'
import FadeContent from '../animation/FadeContent'

gsap.registerPlugin(ScrollTrigger, SplitText)

const HeroSection = ({
  heroHeading,
  heroProjects,
  description,
}: {
  heroHeading: TypedObject | TypedObject[]
  heroProjects: FeaturedProjectType
  description: TypedObject | TypedObject[]
}) => {
  const containerRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  useGSAP(
    () => {
      const images = gsap.utils.toArray<HTMLDivElement>('.parallax-img')

      images.forEach((img, i) => {
        gsap.fromTo(
          img,
          { y: i % 2 === 0 ? -80 : 80 },
          {
            y: i % 2 === 0 ? 80 : -80,
            scrollTrigger: {
              trigger: containerRef.current,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            },
            ease: 'none',
          }
        )
      })
    },
    { scope: containerRef }
  )

  return (
    <section
      ref={containerRef}
      className="relative w-full min-h-[110vh] min-[376px]:min-h-screen md:min-h-[80vh] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:min-h-[70vh] 
        xl:min-h-[120vh] 2xl:min-h-screen flex items-center justify-center lg:px-16 overflow-x-clip"
    >
      {/* Background scattered images */}
      <div
        className="parallax-img absolute w-[160px] md:w-[200px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:w-[300px] lg:w-[180px] xl:w-[300px] 
          2xl:w-[400px] h-[120px] md:h-[160px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:h-[240px] lg:h-[120px] xl:h-[200px] 2xl:h-[300px] left-16 
          md:left-1/2 [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:left-1/3 xl:-left-12 2xl:left-24 top-3 min-[376px]:top-8 lg:-top-8 xl:top-40 
          2xl:top-56 overflow-hidden rounded-xl"
      >
        <Image
          src={heroProjects?.[0].images?.asset?.url || ''}
          alt={heroProjects?.[0].images?.alt || ''}
          fill
          className="w-full h-full object-cover"
        />
      </div>

      <div
        className="parallax-img absolute w-[160px] md:w-[300px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:w-[340px] lg:w-[160px] xl:w-[300px] 
          2xl:w-[320px] h-[120px] md:h-[200px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:h-[240px] lg:h-[100px] xl:h-[240px] 2xl:h-[240px] left-8 
          md:-left-24 [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:left-1/3 lg:left-1/2 xl:left-4 2xl:left-32 -bottom-16 min-[376px]:bottom-0 
          md:-bottom-16 [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:bottom-0 lg:-bottom-16 xl:bottom-4 2xl:bottom-16 overflow-hidden rounded-xl"
      >
        <Image
          src={heroProjects?.[1].images?.asset?.url || ''}
          alt={heroProjects?.[1].images?.alt || ''}
          fill
          className="w-full h-full object-cover"
        />
      </div>

      <div
        className="parallax-img absolute w-[200px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:w-[260px] lg:w-[200px] xl:w-[240px] 2xl:w-[320px] 
          h-[160px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:h-[180px] lg:h-[160px] xl:h-[180px] 2xl:h-[240px] -right-40 
          [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:-right-12 xl:right-8 2xl:right-40 top-4 min-[376px]:top-12 
          [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:top-24 lg:top-0 xl:top-40 overflow-hidden rounded-xl"
      >
        <Image
          src={heroProjects?.[2].images?.asset?.url || ''}
          alt={heroProjects?.[2].images?.alt || ''}
          fill
          className="w-full h-full object-cover"
        />
      </div>

      <div
        className="parallax-img absolute w-[160px] md:w-[200px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:w-[240px] lg:w-[160px] xl:w-[200px] 
          2xl:w-[220px] h-[120px] md:h-[160px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:h-[200px] xl:h-[140px] 2xl:h-[140px] -left-32 
          lg:-left-16 xl:left-[75%] 2xl:left-1/2 top-8 min-[376px]:top-24 md:top-16 [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:top-32 lg:top-8 
          xl:top-24 2xl:top-24 overflow-hidden rounded-xl"
      >
        <Image
          src={heroProjects?.[3].images?.asset?.url || ''}
          alt={heroProjects?.[3].images?.alt || ''}
          fill
          className="w-full h-full object-cover"
        />
      </div>

      <div
        className="parallax-img absolute w-[200px] md:w-[280px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:w-[280px] lg:w-[200px] xl:w-[240px] 
          2xl:w-[380px] h-[120px] md:h-[180px] xl:h-[180px] 2xl:h-[240px] -right-40 min-[376px]:-right-16 md:-right-40 lg:-right-18 xl:left-1/3 2xl:left-[40%] bottom-8
          xl:-bottom-16 2xl:-bottom-8 overflow-hidden rounded-xl"
      >
        <Image
          src={heroProjects?.[4].images?.asset?.url || ''}
          alt={heroProjects?.[4].images?.alt || ''}
          fill
          className="w-full h-full object-cover"
        />
      </div>

      <div
        className="parallax-img absolute w-[200px] [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:w-[200px] lg:w-[200px] xl:w-[240px] 2xl:w-[440px] 
          h-[160px] md:h-[160px] xl:h-[180px] 2xl:h-[300px] -left-40 md:-left-26 [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:left-16 xl:left-[74%]
          2xl:left-9/12 bottom-4 min-[376px]:bottom-16 md:bottom-1/3 [@media_(min-width:_1024px)_and_(max-height:_1366px)_and_(orientation:_portrait)]:bottom-16 lg:bottom-8 xl:bottom-16 
          overflow-hidden rounded-xl"
      >
        <Image
          src={heroProjects?.[5].images?.asset?.url || ''}
          alt={heroProjects?.[5].images?.alt || ''}
          fill
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full md:w-[80%] lg:w-[90%] xl:w-[55%] 2xl:w-1/2 px-[16px] text-center text-font-primary dark:text-font-primary-inverted">
        <h1 className="text-split w-full text-3xl md:text-6xl lg:text-5xl 2xl:text-6xl font-semibold leading-tight mb-2 md:mb-6">
          <PortableText value={heroHeading} components={BlockText} />
        </h1>

        <FadeContent
          className="px-[16px] text-lg lg:text-xl text-font-primary dark:text-font-primary-inverted leading-relaxed"
          duration={1000}
          easing="ease-out"
          initialOpacity={0}
        >
          <PortableText value={description} />
        </FadeContent>
      </div>
    </section>
  )
}

export default HeroSection
