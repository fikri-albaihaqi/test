import Image from 'next/image'
import AnimatedContent from '../animation/AnimatedContent'
import { TeamMemberType } from '@/app/lib/types/types'

const TeamMemberCard = ({
  className,
  member,
  index,
}: {
  className?: string
  member: TeamMemberType
  index: number
}) => {
  return (
    <AnimatedContent
      distance={150}
      direction="vertical"
      reverse={false}
      duration={1.2}
      ease={'power3.out'}
      className={`${className} ${index % 2 !== 0 ? 'mt-16' : 'mt-0'} member-card relative w-[60vw] md:w-[40vw] lg:w-[28vw] xl:w-[25vw] h-[340px] md:h-[386px] lg:h-[356px] xl:h-[460px] 2xl:h-[590px]`}
    >
      <Image
        src={member.photo?.asset.url || ''}
        alt={member.photo?.alt || ''}
        fill
        className="object-cover object-top rounded-2xl"
      />

      <div className="absolute flex flex-col bottom-0 bg-canvas-secondary dark:bg-canvas-secondary-inverted pt-4 pr-6 rounded-tr-3xl">
        <svg
          id="Layer_1"
          className="absolute w-9 h-9 -left-0 -top-[35px] -rotate-90 fill-canvas-secondary dark:fill-canvas-secondary-inverted"
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
          x="0"
          y="0"
          viewBox="0 0 100 100"
        >
          <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
        </svg>

        <div className="flex flex-col xl:text-xl">
          <p className="font-semibold">{member.name}</p>
          <p className="text-font-secondary-1 font-light">{member.position}</p>
        </div>

        <svg
          id="Layer_1"
          className="absolute w-9 h-9 -right-[35px] -bottom-[0.5px] -rotate-90 fill-canvas-secondary dark:fill-canvas-secondary-inverted"
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
          x="0"
          y="0"
          viewBox="0 0 100 100"
        >
          <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
        </svg>
      </div>
    </AnimatedContent>
  )
}

export default TeamMemberCard
