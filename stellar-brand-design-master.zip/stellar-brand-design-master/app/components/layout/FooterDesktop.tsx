'use client'

import {
  FooterContentType,
  MenuVisibilityType,
  SocialsContactType,
} from '@/app/lib/types/types'
import Link from 'next/link'
import FooterTicker from './FooterTicker'
import Button from '../ui/button/Button'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'
import BlockText from '../ui/text/BlockText'
import NewsletterForm from './NewsletterForm'
import useViewport from '@/app/lib/utils/helpers/useViewport'
import PhysicsComponent from '../animation/PhysicsComponent'
import { useTheme } from 'next-themes'

const linkedinIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 448 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z" />
  </svg>
)

const instagramIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 448 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z" />
  </svg>
)

const facebookIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 512 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z" />
  </svg>
)

const xIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20px"
    height="20px"
    viewBox="0 0 512 512"
    className="fill-font-primary-inverted dark:group-hover:fill-canvas-inverted transition-all duration-300"
  >
    Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License -
    https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.
    <path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z" />
  </svg>
)

const FooterDesktop = ({
  content,
  socialsContact,
  menuVisibility,
}: {
  content: FooterContentType
  socialsContact: SocialsContactType
  menuVisibility: MenuVisibilityType
}) => {
  const { width } = useViewport()
  const breakpoints = 1025
  const { theme } = useTheme()

  const lightLogo = [
    '/images/s-light.png',
    '/images/t-light.png',
    '/images/e-light.png',
    '/images/l-light.png',
    '/images/l-light.png',
    '/images/a-light.png',
    '/images/r-light.png',
    '/images/brand-light.png',
    '/images/design-light.png',
  ]

  const darkLogo = [
    '/images/s-dark.png',
    '/images/t-dark.png',
    '/images/e-dark.png',
    '/images/l-dark.png',
    '/images/l-dark.png',
    '/images/a-dark.png',
    '/images/r-dark.png',
    '/images/brand-dark.png',
    '/images/design-dark.png',
  ]

  return width < breakpoints ? (
    <></>
  ) : (
    <footer className="relative flex flex-col justify-center xl:mx-[32px] 2xl:mx-[64px] mt-32 bg-canvas-secondary dark:bg-canvas-secondary-inverted rounded-t-3xl lg:rounded-t-4xl">
      <FooterTicker
        sliderText={content?.sliderText as TypedObject | TypedObject[]}
      />

      <div className="relative flex flex-col gap-y-16 2xl:gap-y-32 p-12 pb-4 mx-[100px] bg-canvas dark:bg-canvas-inverted rounded-t-3xl lg:rounded-t-4xl">
        <div className="relative z-20 flex 2xl:justify-between gap-x-16 2xl:gap-x-0">
          <div className="w-1/3 2xl:w-[45%] flex flex-col gap-y-8">
            <div className="w-full flex flex-col gap-y-4 xl:-mt-1 2xl:-mt-4">
              <h2 className="text-4xl 2xl:text-6xl font-semibold leading-tight">
                <PortableText
                  value={content?.ctaText as TypedObject | TypedObject[]}
                  components={BlockText}
                />
              </h2>

              <Button primary={true} link="/contact">
                Start a projects
              </Button>
            </div>

            <NewsletterForm />
          </div>

          <div className="self-start relative w-1/2 flex gap-x-16">
            <div className="w-fit flex flex-col gap-y-4">
              <h3 className="text-2xl font-light text-font-secondary-1">
                Explore
              </h3>
              <ul className="flex flex-col gap-y-4">
                <li className="relative w-fit">
                  <Link
                    href="/"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    Home
                  </Link>{' '}
                </li>
                <li className="relative w-fit">
                  <Link
                    href="/about"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    About
                  </Link>{' '}
                </li>
                <li className="relative w-fit">
                  <Link
                    href="/services"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    Services
                  </Link>{' '}
                </li>
                <li className="relative w-fit">
                  <Link
                    href="/work"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    Work
                  </Link>{' '}
                </li>
                <li
                  className={`${menuVisibility?.isShowPackageMenu ? 'block' : 'hidden'} relative w-fit`}
                >
                  <Link
                    href="/pricing"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    Pricing
                  </Link>{' '}
                </li>
                <li className="relative w-fit">
                  <Link
                    href="/blog"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    Blog
                  </Link>{' '}
                </li>
                <li className="relative w-fit">
                  <Link
                    href="/contact"
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    Contact
                  </Link>{' '}
                </li>
              </ul>
            </div>

            <div className="w-fit text-wrap flex flex-col gap-y-4">
              <h3 className="text-2xl font-light text-font-secondary-1">
                Get in touch
              </h3>
              <ul className="flex flex-col gap-y-4">
                <li className="relative w-fit">
                  <Link
                    href={`mailto:${socialsContact?.email}`}
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    {socialsContact?.email}
                  </Link>{' '}
                </li>
                <li className="text-2xl">{socialsContact?.address}</li>
                <li className="relative w-fit">
                  <Link
                    href={`tel:${socialsContact?.phoneNumber}`}
                    className="text-2xl transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
                  >
                    {socialsContact?.phoneNumber}
                  </Link>{' '}
                </li>
              </ul>
            </div>
          </div>

          <div className="absolute flex flex-col gap-y-4 p-11 -right-[154px] -top-[48px] bg-canvas dark:bg-canvas-inverted">
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 right-1 -top-9 rotate-180 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            <Link
              href={socialsContact?.linkedin || ''}
              target="_blank"
              className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
              aria-label="Go to Stellar Brand Design's LinkedIn"
            >
              {linkedinIcon}
            </Link>
            <Link
              href={socialsContact?.instagram || ''}
              target="_blank"
              className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
              aria-label="Go to Stellar Brand Design's Instagram"
            >
              {instagramIcon}
            </Link>

            <Link
              href={socialsContact?.facebook || ''}
              target="_blank"
              className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
              aria-label="Go to Stellar Brand Design's Facebook"
            >
              {facebookIcon}
            </Link>

            <Link
              href={socialsContact?.twitter || ''}
              className="group p-3 bg-brand-secondary hover:bg-canvas-inverted dark:hover:bg-canvas rounded-full transition-all duration-300"
              aria-label="Go to Stellar Brand Design's Twitter/X"
            >
              {xIcon}
            </Link>
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 left-[25px] -bottom-9 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 right-[5px] -bottom-9 rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
          </div>
        </div>

        <PhysicsComponent
          images={theme === 'dark' ? darkLogo : lightLogo}
          className={`absolute w-full min-h-[520px] self-center`}
        />

        <div className="flex justify-between pb-4">
          <p>
            © Copyright {new Date().getFullYear()} Stellar Brand Design. All
            rights reserved
          </p>

          <ul className="relative z-20 flex gap-x-4">
            <li className="relative">
              <Link
                href="/terms-of-service"
                className="transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
              >
                Terms of Service
              </Link>
            </li>
            <li className="relative">
              <Link
                href="/privacy-policy"
                className="transition-all before:w-0 before:h-[2px] before:absolute before:-bottom-1 before:right-0 before:transition-all before:duration-500
                      hover:before:w-full hover:before:left-0 hover:before:bg-brand-primary"
              >
                Privacy Policy
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  )
}

export default FooterDesktop
