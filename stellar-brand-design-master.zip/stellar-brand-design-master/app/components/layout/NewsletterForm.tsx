'use client'

import { NewsletterFieldType } from '@/app/lib/types/types'
import { Form, FormProps, Input } from 'antd'
import { useState } from 'react'

const enterIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m560-120-57-57 144-143H200v-480h80v400h367L503-544l56-57 241 241-240 240Z" />
  </svg>
)

const loadingIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-current animate-spin"
  >
    <path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-155.5t86-127Q252-817 325-848.5T480-880q17 0 28.5 11.5T520-840q0 17-11.5 28.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q133 0 226.5-93.5T800-480q0-17 11.5-28.5T840-520q17 0 28.5 11.5T880-480q0 82-31.5 155t-86 127.5q-54.5 54.5-127 86T480-80Z" />
  </svg>
)

const NewsletterForm = () => {
  const [isLoading, setIsLoading] = useState(false)
  const [messageTitle, setMessageTitle] = useState(
    'Subscribe to Our Newsletter'
  )
  const [messageBody, setMessageBody] = useState(
    'Stay inspired — subscribe to our newsletter for fresh insights on design, growth, SaaS, and Marketing.'
  )

  const onFinish: FormProps<NewsletterFieldType>['onFinish'] = async (
    values
  ) => {
    setIsLoading(true)
    const response = await fetch('/api/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: values.email }),
    })

    const data = await response.json()

    if (response.ok) {
      setIsLoading(false)
      setMessageTitle("Welcome aboard! It's great to have you with us.")
      setMessageBody(
        'From now on, you’ll be the first to hear about our latest projects, stories, and special deals.'
      )
    } else {
      setIsLoading(false)
      if (data.error === 'Member Exists') {
        setMessageTitle('This email is already registered with our newsletter.')
        setMessageBody('')
      } else {
        setMessageTitle('Oops! Something went wrong')
        setMessageBody(
          'We couldn’t process your subscription. Please try again.'
        )
      }

      console.log()
    }
  }

  return (
    <div className="w-full flex flex-col gap-y-4">
      <h3 className="text-2xl font-semibold">{messageTitle}</h3>
      <p className="text-2xl">{messageBody}</p>

      <Form
        name="newsletter"
        onFinish={onFinish}
        autoComplete="off"
        className="flex flex-col md:flex-row gap-x-4"
      >
        <Form.Item<NewsletterFieldType>
          name="email"
          rules={[{ required: true, message: 'Please input your email!' }]}
        >
          <Input
            type="email"
            placeholder="Your email"
            variant="underlined"
            className="w-full md:w-[240px]! focus:border-b-brand-secondary!"
            style={{
              border: 'none',
              backgroundColor: 'transparent',
              borderBottom: '1px solid var(--color-font-secondary-1)',
              borderRadius: '0',
            }}
          />
        </Form.Item>

        <Form.Item label={null} className='mb-0!'>
          <button
            type="submit"
            className="flex items-center gap-x-2 -mt-6 md:mt-2 text-lg md:text-2xl text-font-primary dark:text-font-primary-inverted hover:text-brand-secondary font-semibold 
              transition-all duration-300 cursor-pointer"
          >
            {isLoading ? loadingIcon : <>{enterIcon} Subscribe</>}
          </button>
        </Form.Item>
      </Form>
    </div>
  )
}

export default NewsletterForm
