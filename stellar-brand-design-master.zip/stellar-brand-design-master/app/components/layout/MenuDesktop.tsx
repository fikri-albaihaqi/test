'use client'

import Link from 'next/link'
import ThemeButton from '../ui/button/ThemeButton'
import { useEffect, useRef } from 'react'
import Button from '../ui/button/Button'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import { usePathname } from 'next/navigation'
import Image from 'next/image'
import { MenuVisibilityType } from '@/app/lib/types/types'

gsap.registerPlugin(ScrollTrigger)

const MenuDesktop = ({
  menuVisibility,
}: {
  menuVisibility: MenuVisibilityType
}) => {
  const pathname = usePathname()
  const navRef = useRef<HTMLDivElement>(null)
  const menuRef = useRef<HTMLUListElement>(null)

  useGSAP(() => {
    const nav = navRef.current

    if (!nav) return

    gsap.matchMedia().add(
      {
        isXl: '(max-width: 1535px)',
        is2xl: '(min-width: 1536px)',
      },
      (context) => {
        const { is2xl } = context.conditions as gsap.Conditions

        ScrollTrigger.create({
          start: 'top+=100 top',
          end: 'bottom bottom',
          onLeaveBack: () => {
            navRef.current?.classList.remove(
              'bg-canvas-secondary-shade/60',
              'dark:bg-canvas-secondary-inverted-shade/60',
              'py-2'
            )
            navRef.current?.classList.add('py-4')
            menuRef.current?.classList.add(
              'bg-canvas-secondary-shade/60',
              'dark:bg-canvas-secondary-inverted-shade/60'
            )
            gsap.to(nav, {
              width: is2xl ? '86%' : '92%',
              top: '0',
              duration: 0.3,
              ease: 'power2.out',
            })
          },
          onEnter: () => {
            navRef.current?.classList.add(
              'bg-canvas-secondary-shade/60',
              'dark:bg-canvas-secondary-inverted-shade/60',
              'py-2'
            )
            navRef.current?.classList.remove('py-4')
            menuRef.current?.classList.remove(
              'bg-canvas-secondary-shade/60',
              'dark:bg-canvas-secondary-inverted-shade/60'
            )
            gsap.to(nav, {
              width: is2xl ? '60%' : '85%',
              top: '16',
              duration: 0.3,
              ease: 'power2.out',
            })
          },
        })
      }
    )
  }, [])

  useEffect(() => {
    let lastScrollY = window.scrollY

    const handleScroll = () => {
      const currentScrollY = window.scrollY

      if (currentScrollY < lastScrollY) {
        // Scrolling up
        gsap.to(navRef.current, {
          y: 0,
          duration: 0.3,
          ease: 'power2.out',
        })
      } else {
        // Scrolling down
        gsap.to(navRef.current, {
          y: -110,
          duration: 0.3,
          ease: 'power2.out',
        })
      }

      lastScrollY = currentScrollY
    }

    window.addEventListener('scroll', handleScroll)

    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  return (
    <nav
      ref={navRef}
      className="fixed z-[99] w-[92%] 2xl:w-[86%] left-1/2 -translate-x-1/2 hidden xl:flex justify-center py-4 rounded-full backdrop-blur-sm transition-[background] duration-300"
      style={{
        WebkitBackdropFilter: 'blur(8px)',
      }}
    >
      <div className="w-full flex justify-between items-center px-8">
        {/* Logo */}
        <Link href="/" className="dark:hidden text-xl font-bold">
          <Image
            src="/logo-light.png"
            alt="Stellar Brand Design Logo"
            style={{
              width: '160px',
              height: 'auto',
            }}
            width={160}
            height={53.75}
          />
        </Link>

        <Link href="/" className="hidden dark:block text-xl font-bold">
          <Image
            src="/logo-dark.png"
            alt="Stellar Brand Design Logo"
            style={{
              width: '160px',
              height: 'auto',
            }}
            width={160}
            height={53.75}
          />
        </Link>

        <ul
          ref={menuRef}
          className="h-[48px] flex items-center px-4 bg-canvas-secondary-shade/60 dark:bg-canvas-secondary-inverted-shade/60 rounded-full transition-all"
        >
          <li>
            <Link
              href="/"
              className={`${
                pathname === '/'
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              Home
            </Link>{' '}
          </li>
          <li>
            <Link
              href="/about"
              className={`${
                pathname.includes('/about')
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              About
            </Link>{' '}
          </li>
          <li>
            <Link
              href="/services"
              className={`${
                pathname.includes('/services')
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              Services
            </Link>{' '}
          </li>
          <li>
            <Link
              href="/work"
              className={`${
                pathname.includes('/work')
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              Work
            </Link>{' '}
          </li>
          <li
            className={menuVisibility?.isShowPackageMenu ? 'block' : 'hidden'}
          >
            <Link
              href="/pricing"
              className={`${
                pathname.includes('/pricing')
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              Pricing
            </Link>{' '}
          </li>
          <li>
            <Link
              href="/blog"
              className={`${
                pathname.includes('/blog')
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              Blog
            </Link>{' '}
          </li>
          <li>
            <Link
              href="/contact"
              className={`${
                pathname.includes('/contact')
                  ? 'bg-brand-primary text-canvas'
                  : 'hover:bg-brand-secondary-2 dark:hover:text-font-primary'
              } px-4 py-1 text-lg rounded-full transition-all duration-300`}
            >
              Contact
            </Link>{' '}
          </li>
        </ul>

        <div className="flex gap-x-4">
          <ThemeButton />
          <Button primary={true} link="/contact">
            Start a project
          </Button>
        </div>
      </div>
    </nav>
  )
}

export default MenuDesktop
