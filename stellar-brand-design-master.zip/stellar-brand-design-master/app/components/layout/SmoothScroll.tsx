'use client'

import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { LenisRef, ReactLenis } from 'lenis/react'
import { useEffect, useRef } from 'react'

gsap.registerPlugin(ScrollTrigger)

function SmoothScroll({ children }: { children: React.ReactNode }) {
  const lenisRef = useRef<LenisRef>(null)

  useEffect(() => {
    function update(time: number) {
      const lenis = lenisRef.current?.lenis
      if (!lenis) return

      lenis.raf(time * 1000)
      ScrollTrigger.update()
    }

    gsap.ticker.add(update)
    return () => gsap.ticker.remove(update)
  }, [])

  return (
    <ReactLenis
      root
      options={{ autoRaf: false, touchMultiplier: 0 }}
      ref={lenisRef}
    >
      {children}
    </ReactLenis>
  )
}

export default SmoothScroll
