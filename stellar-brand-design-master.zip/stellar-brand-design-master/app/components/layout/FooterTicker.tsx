'use client'

import { useGSAP } from '@gsap/react'
import { gsap } from 'gsap'
import horizontalLoop from '@/app/lib/utils/animations/horizontalLoop'
import { useRef } from 'react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'

gsap.registerPlugin(ScrollTrigger)

const arrowIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 -960 960 960"
    fill="#6881FF"
    className="w-[59px] xl:w-[74px] 2xl:w-[80px] h-[59px] xl:h-[74px] 2xl:h-[80px]"
  >
    <path d="M647-440H160v-80h487L423-744l57-56 320 320-320 320-57-56 224-224Z" />
  </svg>
)

const FooterTicker = ({
  sliderText,
}: {
  sliderText: TypedObject | TypedObject[]
}) => {
  const tickerRef = useRef<HTMLDivElement>(null)
  const tickerInstance = useRef<gsap.core.Animation | null>(null)

  useGSAP(() => {
    const items: HTMLElement[] = gsap.utils.toArray('.text-ticker')
    const arrowItems: HTMLElement[] = gsap.utils.toArray('.arrow')
    if (items.length === 0) return

    tickerInstance.current = horizontalLoop(items, {
      paused: false,
      repeat: -1,
      speed: 1.5,
      paddingRight: '16',
      reversed: true,
    })

    let lastScroll = window.scrollY

    window.addEventListener('scroll', () => {
      const curr = window.scrollY
      if (curr > lastScroll) {
        // scrolling down
        tickerInstance.current?.timeScale(-1)
        gsap.to(arrowItems, { rotate: 0, overwrite: true })
      } else {
        // scrolling up
        tickerInstance.current?.timeScale(1)
        gsap.to(arrowItems, { rotate: 180, overwrite: true })
      }
      lastScroll = curr
    })
  })

  return (
    <div
      ref={tickerRef}
      className="hidden md:flex w-full overflow-hidden py-6 xl:py-8 2xl:py-16"
    >
      <div className="flex flex-nowrap w-max gap-x-4">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="text-ticker flex-shrink-0 flex items-center gap-x-4 text-4xl xl:text-5xl 2xl:text-7xl font-semibold whitespace-nowrap"
          >
            <h2>
              <PortableText value={sliderText} />
            </h2>
            <span className="arrow">{arrowIcon}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default FooterTicker
