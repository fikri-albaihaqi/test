'use client'

import Link from 'next/link'
import ThemeButton from '../ui/button/ThemeButton'
import { useEffect, useRef, useState } from 'react'
import Button from '../ui/button/Button'
import styles from './MenuMobile.module.css'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { usePathname } from 'next/navigation'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Image from 'next/image'
import { MenuVisibilityType } from '@/app/lib/types/types'

gsap.registerPlugin(ScrollTrigger)

const menuIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z" />
  </svg>
)

const closeIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z" />
  </svg>
)

const MenuMobile = ({
  menuVisibility,
}: {
  menuVisibility: MenuVisibilityType
}) => {
  const [show, setShow] = useState(false)
  const pathname = usePathname()

  const toggleMenu = () => {
    setShow(!show)

    if (show) {
      document.body.classList.remove('overflow-hidden')
    } else {
      document.body.classList.add('overflow-hidden')
    }
  }

  useEffect(() => {
    if (show) {
      setShow(!show)
    }

    if (show) {
      document.body.classList.remove('overflow-hidden')
    }
  }, [pathname])

  const navRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    const nav = navRef.current

    if (!nav) return

    ScrollTrigger.create({
      start: 'top+=30 top',
      end: 'bottom bottom',
      onLeaveBack: () => {
        navRef.current?.classList.remove(
          'bg-canvas-secondary-shade/60',
          'dark:bg-canvas-secondary-inverted-shade/60'
        )
        gsap.to(nav, {
          width: '100%',
          top: '0',
          duration: 0.3,
          ease: 'power2.out',
        })
      },
      onEnter: () => {
        navRef.current?.classList.add(
          'bg-canvas-secondary-shade/60',
          'dark:bg-canvas-secondary-inverted-shade/60'
        )
        gsap.to(nav, {
          width: '92%',
          left: '50%',
          translateX: '-50%',
          top: '16',
          duration: 0.3,
          ease: 'power2.out',
        })
      },
    })
  }, [])

  useEffect(() => {
    let lastScrollY = window.scrollY

    const handleScroll = () => {
      const currentScrollY = window.scrollY

      if (currentScrollY < lastScrollY) {
        // Scrolling up
        gsap.to(navRef.current, {
          y: 0,
          duration: 0.3,
          ease: 'power2.out',
        })
      } else {
        // Scrolling down
        gsap.to(navRef.current, {
          y: -110,
          duration: 0.3,
          ease: 'power2.out',
        })
      }

      lastScrollY = currentScrollY
    }

    window.addEventListener('scroll', handleScroll)

    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  return (
    <>
      <div
        className={`${
          show ? 'block' : 'hidden'
        } fixed z-[80] w-screen h-screen bg-white/0 backdrop-blur-sm`}
        style={{
          WebkitBackdropFilter: 'blur(8px)',
        }}
      ></div>

      <nav
        ref={navRef}
        className="fixed z-[99] w-full flex xl:hidden flex-col rounded-full backdrop-blur-sm"
        style={{
          WebkitBackdropFilter: 'blur(8px)',
        }}
      >
        <div className="flex justify-between items-center md:mx-[32px] mx-[16px] py-[8px] md:py-[16px]">
          {/* Logo */}
          <Link href="/" className="dark:hidden text-xl font-bold">
            <Image
              src="/logo-light.png"
              alt="Stellar Brand Design Logo"
              style={{
                width: '140px',
                height: 'auto',
              }}
              width={160}
              height={47.03}
            />
          </Link>

          <Link href="/" className="hidden dark:block text-xl font-bold">
            <Image
              src="/logo-dark.png"
              alt="Stellar Brand Design Logo"
              style={{
                width: '140px',
                height: 'auto',
              }}
              width={160}
              height={47.03}
            />
          </Link>

          <div className="flex gap-x-4">
            <ThemeButton />
            <button onClick={toggleMenu} aria-label='Menu'>{show ? closeIcon : menuIcon}</button>
          </div>
        </div>

        <ul
          className={`${
            show ? styles.show + ' py-8 md:py-16' : styles.hide + ' py-0'
          } w-full absolute top-[80px] md:top-[100px] md:pl-[32px] pl-[16px] z-50 bg-canvas-secondary-shade dark:bg-canvas-secondary-inverted-shade transition-[padding] rounded-xl`}
        >
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } py-1 transition-opacity duration-700`}
          >
            <Link href="/" className={`text-5xl font-semibold rounded-full`}>
              Home
            </Link>{' '}
          </li>
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } py-1 transition-opacity duration-100`}
          >
            <Link
              href="/about"
              className={`text-5xl font-semibold rounded-full`}
            >
              About
            </Link>{' '}
          </li>
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } py-1 transition-opacity duration-100`}
          >
            <Link
              href="/services"
              className={`text-5xl font-semibold rounded-full`}
            >
              Services
            </Link>{' '}
          </li>
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } py-1 transition-opacity duration-100`}
          >
            <Link
              href="/work"
              className={`text-5xl font-semibold rounded-full`}
            >
              Work
            </Link>{' '}
          </li>
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } ${menuVisibility?.isShowPackageMenu ? 'block' : 'hidden'} py-1 transition-opacity duration-100`}
          >
            <Link
              href="/pricing"
              className={`text-5xl font-semibold rounded-full`}
            >
              Pricing
            </Link>{' '}
          </li>
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } py-1 transition-opacity duration-100`}
          >
            <Link
              href="/blog"
              className={`text-5xl font-semibold rounded-full`}
            >
              Blog
            </Link>{' '}
          </li>
          <li
            className={`${
              show ? styles.menuItems + ' opacity-100' : ' opacity-0'
            } py-1 transition-opacity duration-100`}
          >
            <Link
              href="/contact"
              className={`text-5xl font-semibold rounded-full`}
            >
              Contact
            </Link>{' '}
          </li>
          <li>
            <Button
              link="/contact"
              primary={true}
              className={`${
                show ? styles.menuItems + ' opacity-100' : ' opacity-0'
              } mt-8 py-1 transition-opacity duration-100 overflow-hidden`}
            >
              Start a project
            </Button>
          </li>
        </ul>
      </nav>
    </>
  )
}

export default MenuMobile
