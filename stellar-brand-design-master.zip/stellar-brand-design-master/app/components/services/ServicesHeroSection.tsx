'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import Image from 'next/image'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'
import BlockText from '../ui/text/BlockText'

gsap.registerPlugin(ScrollTrigger, SplitText)

const ServicesHeroSection = ({
  heroHeading,
  heroImage,
}: {
  heroHeading: TypedObject | TypedObject[]
  heroImage:
    | {
        _key: null
        _type: 'image'
        asset: {
          url: string | null
        } | null
        alt: string | null
      }
    | null
    | undefined
}) => {
  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <section className="relative w-full 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] overflow-hidden">
      <div className="relative">
        <div className="relative w-full h-[240px] md:h-[730px] lg:h-[440px] xl:h-[600px] 2xl:h-[730px] overflow-hidden">
          <Image
            src={heroImage?.asset?.url || ''}
            alt={heroImage?.alt || ''}
            fill
            className="object-cover rounded-xl lg:rounded-3xl"
          />
        </div>

        <div className="hidden md:block absolute w-[80%] lg:w-2/3 xl:w-[55%] bottom-0 pr-8 bg-canvas dark:bg-canvas-inverted rounded-tr-3xl">
          <svg
            id="Layer_1"
            className="absolute w-9 h-9 left-0 -top-[35px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>

          <div className="flex items-center gap-x-2 mt-4">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 [clip-path:polygon(0%_100%,100%_100%,0%_0%)]"></div>
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h1 className="text-split text-lg">What we do</h1>
          </div>
          <svg
            id="Layer_1"
            className="absolute w-9 h-9 left-[27%] lg:left-[33%] xl:left-[40%] -top-[35px] -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>
          <p className="text-split leading-tight text-[40px] 2xl:text-6xl font-semibold">
            <PortableText value={heroHeading} components={BlockText} />
          </p>

          <svg
            id="Layer_1"
            className="absolute w-9 h-9 -right-9 bottom-0 -rotate-90 text-canvas dark:text-canvas-inverted fill-current"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            x="0"
            y="0"
            viewBox="0 0 100 100"
          >
            <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
          </svg>
        </div>
      </div>

      <div className="flex md:hidden flex-col gap-y-2 mt-8">
        <div className="flex items-center gap-x-2">
          <div className="w-3 h-3 relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
          </div>
          <h2 className="text-split ">What we do</h2>
        </div>
        <h2 className="text-split leading-tight text-3xl font-semibold">
          <PortableText value={heroHeading} components={BlockText} />
        </h2>
      </div>
    </section>
  )
}

export default ServicesHeroSection
