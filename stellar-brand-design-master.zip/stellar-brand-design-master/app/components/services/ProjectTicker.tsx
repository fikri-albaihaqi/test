'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import horizontalLoop from '@/app/lib/utils/animations/horizontalLoop'
import { FeaturedProjectType } from '@/app/lib/types/types'
import ProjectTickerCard from './ProjectTickerCard'
import { useRef, useState } from 'react'
import CursorFollower from '../animation/CursorFollower'

const ProjectTicker = ({
  projects,
  index,
}: {
  projects: FeaturedProjectType
  index: number
}) => {
  useGSAP(() => {
    const projects: Array<HTMLElement> = gsap.utils.toArray(`.project-${index}`)

    horizontalLoop(projects, {
      paused: false,
      repeat: -1,
      paddingRight: '16',
      speed: 0.3,
      reversed: index % 2 === 0,
    })
  })

  const projectsWrapper = useRef<HTMLDivElement>(null)
  const cursorFollower = useRef<HTMLDivElement>(null)

  const [animation] = useState(gsap.timeline({ paused: true }))

  useGSAP(() => {
    const wrapper = projectsWrapper.current
    if (!wrapper) return

    gsap.set(cursorFollower.current, {
      xPercent: -50,
      yPercent: -50,
      scale: 0,
      opacity: 0,
    })

    const x = gsap.quickTo(cursorFollower.current, 'x', {
      duration: 0.6,
      ease: 'back',
    })

    const y = gsap.quickTo(cursorFollower.current, 'y', {
      duration: 0.6,
      ease: 'back',
    })

    window.addEventListener('mousemove', (e) => {
      x(e.clientX)
      y(e.clientY)
    })

    animation.fromTo(
      cursorFollower.current,
      {
        scale: 0,
        opacity: 0,
        duration: 0.3,
      },
      {
        scale: 1,
        opacity: 100,
        duration: 0.3,
      }
    )
    const targets = gsap.utils.toArray(wrapper.children) as HTMLDivElement[]

    targets.forEach((target: HTMLDivElement) => {
      target.addEventListener('mouseenter', () => {
        animation.play()
      })

      target.addEventListener('mouseleave', () => {
        animation.reverse()
      })
    })
  })

  return (
    <div
      ref={projectsWrapper}
      className="relative w-screen flex self-start gap-x-4 overflow-hidden"
    >
      <CursorFollower ref={cursorFollower} />
      {projects?.map((project) => (
        <ProjectTickerCard key={project._id} project={project} index={index} />
      ))}
    </div>
  )
}

export default ProjectTicker
