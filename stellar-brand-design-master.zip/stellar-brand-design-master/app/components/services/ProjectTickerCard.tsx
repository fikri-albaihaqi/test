import { ProjectType } from '@/app/lib/types/types'
import Image from 'next/image'
import Link from 'next/link'

const ProjectTickerCard = ({
  project,
  index,
}: {
  project: ProjectType
  index: number
}) => {
  return (
    <Link
      href={`/work/${project.slug?.current}`}
      className={`project-${index} relative w-[300px] md:w-[524px] h-[200px] md:h-[350px] shrink-0 overflow-hidden rounded-xl lg:rounded-3xl`}
    >
      <Image
        src={project.images?.asset?.url || ''}
        alt={project.images?.alt || ''}
        fill
        className="object-cover rounded-xl lg:rounded-3xl hover:scale-105 transition-all duration-500"
      />

      <h2 className="absolute bottom-4 left-4 font-semibold text-font-primary-inverted">
        {project.name}
      </h2>
    </Link>
  )
}

export default ProjectTickerCard
