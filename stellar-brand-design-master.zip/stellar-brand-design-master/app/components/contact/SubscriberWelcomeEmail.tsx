import {
  Html,
  Preview,
  Body,
  Container,
  Section,
  Text,
  Button,
  Img,
} from '@react-email/components'

const SubscriberWelcomeEmail = () => {
  return (
    <Html>
      <Preview>Welcome to Stellar Brand Design 🎉</Preview>
      <Body style={main}>
        <Container style={container}>
          {/* Header with Logo */}
          <Section style={header}>
            <Img
              src="https://stellarbranddesign.com/_next/image?url=%2Flogo-dark.png&w=256&q=75"
              alt="Stellar Brand Design"
              width="180"
              height="auto"
              style={logo}
            />
          </Section>

          {/* Hero */}
          <Section style={hero}>
            <Text style={heroTitle}>Welcome aboard!</Text>
          </Section>

          {/* Content */}
          <Section style={content}>
            <Text style={heroSubtitle}>
              It&apos;s great to have you with us. Here&apos;s what you can expect:
            </Text>
            <ul style={list}>
              <li>✨ Updates on our latest blog posts</li>
              <li>📢 Updates on our latest projects & case studies</li>
              <li>🎁 Special offers</li>
            </ul>
            <Text style={contentText}>
              Our mission is to help your brand shine brighter than ever. Keep
              an eye on your inbox—you won&apos;t want to miss what&apos;s coming next.
            </Text>
          </Section>

          {/* CTA */}
          <Section style={cta}>
            <Button style={button} href="https://stellarbranddesign.com/work">
              Explore Our Work
            </Button>
          </Section>

          {/* Footer */}
          <Section style={footer}>
            <Text style={footerText}>
              © {new Date().getFullYear()} Stellar Brand Design · All Rights
              Reserved
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export default SubscriberWelcomeEmail

/* === Styles === */
const main = {
  backgroundColor: '#f4f4f7',
  fontFamily: 'Arial, sans-serif',
  padding: '40px 0',
}

const container = {
  backgroundColor: '#ffffff',
  borderRadius: '10px',
  padding: 0,
  maxWidth: '600px',
  margin: '0 auto',
  border: '1px solid #e0e0e0',
  overflow: 'hidden',
}

const header = {
  backgroundColor: '#6881ff',
  padding: '20px',
  textAlign: 'center' as const,
}

const logo = {
  display: 'block',
  margin: '0 auto',
}

const hero = {
  textAlign: 'center' as const,
  marginTop: '16px',
}

const heroTitle = {
  fontSize: '22px',
  fontWeight: 'bold',
  color: '#222',
}

const heroSubtitle = {
  fontSize: '15px',
  color: '#555',
}

const content = {
  padding: '0px 56px',
}

const contentText = {
  fontSize: '15px',
  color: '#444',
  marginTop: '15px',
}

const list = {
  paddingLeft: '32px',
  color: '#444',
  fontSize: '15px',
  lineHeight: '24px',
}

const cta = {
  textAlign: 'center' as const,
  padding: '30px',
}

const button = {
  backgroundColor: '#3355ff',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  padding: '12px 24px',
  borderRadius: '6px',
  display: 'inline-block',
}

const footer = {
  backgroundColor: '#f4f4f7',
  padding: '20px',
  textAlign: 'center' as const,
}

const footerText = {
  fontSize: '12px',
  color: '#888',
  lineHeight: '18px',
}
