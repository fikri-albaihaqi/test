import {
  Html,
  Head,
  Preview,
  Body,
  Container,
  Section,
  Text,
  Img,
} from '@react-email/components'

const ContactEmail = (props: {
  name: string
  companyName: string
  email: string
  timeline: string
  projectDescription: string
}) => {
  const { name, companyName, email, timeline, projectDescription } = props

  return (
    <Html>
      <Head />
      <Preview>New Contact Form Submission from {name}</Preview>
      <Body style={main}>
        <Container style={container}>
          {/* Header */}
          <Section style={header}>
            <Img
              src="https://stellarbranddesign.com/_next/image?url=%2Flogo-dark.png&w=256&q=75"
              alt="Stellar Brand Design"
              width="180"
              height="auto"
              style={logo}
            />
          </Section>

          {/* Hero */}
          <Section style={hero}>
            <h1 style={heroTitle}>📩 New Contact Form Submission</h1>
            <Text>
              You’ve received a new message from <strong>{name}</strong>.
            </Text>
          </Section>

          {/* Details */}
          <Section style={section}>
            <h2 style={h2}>Details</h2>
            <Text style={detail}>
              <strong>Name:</strong> {name}
            </Text>
            {companyName && (
              <Text style={detail}>
                <strong>Company:</strong> {companyName}
              </Text>
            )}
            <Text style={detail}>
              <strong>Email:</strong> {email}
            </Text>
            {timeline && (
              <Text style={detail}>
                <strong>Timeline:</strong> {timeline}
              </Text>
            )}

            <Text style={{ ...detail, marginTop: '12px' }}>
              <strong>Project Details:</strong>
            </Text>
            <Text style={message}>{projectDescription}</Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export default ContactEmail

/* === Styles === */
const logo = {
  display: 'block',
  margin: '0 auto',
}

const hero = {
  textAlign: 'center' as const,
  marginTop: '16px',
}

const heroTitle = {
  fontSize: '22px',
  fontWeight: 'bold',
  color: '#222',
}

const main = {
  backgroundColor: '#f4f4f7',
  fontFamily: 'Arial, sans-serif',
  padding: '40px 0',
}

const container = {
  backgroundColor: '#ffffff',
  borderRadius: '10px',
  maxWidth: '600px',
  margin: '0 auto',
  border: '1px solid #e0e0e0',
  overflow: 'hidden',
}

const header = {
  padding: '25px',
  borderBottom: '1px solid #eee',
  backgroundColor: '#6881ff',
  color: '#fff',
  textAlign: 'center' as const,
}

const section = {
  padding: '25px',
  borderBottom: '1px solid #eee',
}

const h2 = {
  fontSize: '18px',
  fontWeight: '600',
  marginBottom: '12px',
  color: '#111',
}

const detail = {
  fontSize: '14px',
  marginBottom: '6px',
  color: '#333',
}

const message = {
  fontSize: '14px',
  lineHeight: '1.6',
  color: '#222',
  backgroundColor: '#f9f9f9',
  padding: '12px',
  borderRadius: '6px',
}
