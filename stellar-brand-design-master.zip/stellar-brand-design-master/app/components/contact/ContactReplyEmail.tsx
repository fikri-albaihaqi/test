import {
  Html,
  Preview,
  Body,
  Container,
  Section,
  Text,
  Img,
} from '@react-email/components'

const ContactReplyEmail = (props: { name: string }) => {
  const { name } = props

  return (
    <Html>
      <Preview>Welcome to Stellar Brand Design 🎉</Preview>
      <Body style={main}>
        <Container style={container}>
          {/* Header with Logo */}
          <Section style={header}>
            <Img
              src="https://stellarbranddesign.com/_next/image?url=%2Flogo-dark.png&w=256&q=75"
              alt="Stellar Brand Design"
              width="180"
              height="auto"
              style={logo}
            />
          </Section>

          {/* Hero */}
          <Section style={hero}>
            <h1 style={heroTitle}>
              Hi {name}, thanks for getting in touch! 👋
            </h1>
          </Section>

          {/* Content */}
          <Section style={section}>
            <Text style={bodyText}>
              We’ve received your message and our team will get back to you as
              soon as possible.
            </Text>
            <Text style={bodyText}>
              In the meantime, feel free to explore our website or reply to this
              email if you’d like to share more details.
            </Text>
          </Section>

          {/* Footer */}
          <Section style={footer}>
            <Text style={footerText}>
              © {new Date().getFullYear()} Stellar Brand Design · All Rights
              Reserved
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export default ContactReplyEmail

/* === Styles === */
const main = {
  backgroundColor: '#f4f4f7',
  fontFamily: 'Arial, sans-serif',
  padding: '40px 0',
}

const container = {
  backgroundColor: '#ffffff',
  borderRadius: '10px',
  maxWidth: '600px',
  margin: '0 auto',
  border: '1px solid #e0e0e0',
  overflow: 'hidden',
}

const header = {
  padding: '25px',
  borderBottom: '1px solid #eee',
  backgroundColor: '#6881ff',
  color: '#fff',
  textAlign: 'center' as const,
}

const logo = {
  display: 'block',
  margin: '0 auto',
}

const hero = {
  textAlign: 'center' as const,
  marginTop: '16px',
}

const heroTitle = {
  fontSize: '22px',
  fontWeight: 'bold',
  color: '#222',
}

const section = {
  padding: '25px',
  borderBottom: '1px solid #eee',
}

const bodyText = {
  fontSize: '15px',
  color: '#333',
  marginBottom: '12px',
  lineHeight: '1.5',
}

const footer = {
  padding: '20px',
  textAlign: 'center' as const,
  backgroundColor: '#f9f9f9',
}

const footerText = {
  fontSize: '13px',
  color: '#777',
}
