import {
  Html,
  Head,
  Preview,
  Body,
  Container,
  Section,
  Text,
  Img,
} from '@react-email/components'

const ProjectEmail = (props: {
  name: string
  companyName: string
  email: string
  timeline: string
  selectedOffers: { _id: string; name: string; price: number }[]
  totalPrice: number
  projectBrief: string
}) => {
  const {
    name,
    companyName,
    email,
    timeline,
    selectedOffers,
    totalPrice,
    projectBrief,
  } = props

  return (
    <Html>
      <Head />
      <Preview>New Project Inquiry from {name}</Preview>
      <Body style={main}>
        <Container style={container}>
          {/* Header with Logo */}
          <Section style={header}>
            <Img
              src="https://stellarbranddesign.com/_next/image?url=%2Flogo-dark.png&w=256&q=75"
              alt="Stellar Brand Design"
              width="180"
              height="auto"
              style={logo}
            />
          </Section>

          {/* Intro */}
          <Section style={intro}>
            <h1 style={h1}>New Project Inquiry</h1>
            <Text style={introText}>
              You’ve received a new project inquiry from <strong>{name}</strong>
              .
            </Text>
          </Section>

          {/* Project Details */}
          <Section style={section}>
            <h2 style={h2}>Project Details</h2>
            <Text style={detail}>
              <strong>Name:</strong> {name}
            </Text>
            <Text style={detail}>
              <strong>Company:</strong> {companyName}
            </Text>
            <Text style={detail}>
              <strong>Email:</strong> {email}
            </Text>
            <Text style={detail}>
              <strong>Timeline:</strong> {timeline}
            </Text>
            <Text style={detail}>
              <strong>Project Brief:</strong>
            </Text>
            <Text style={brief}>{projectBrief}</Text>
          </Section>

          {/* Order Summary */}
          <Section style={section}>
            <h2 style={h2}>Order Summary</h2>
            <table style={table}>
              <tbody>
                {selectedOffers.map((offer) => (
                  <tr key={offer._id} style={row}>
                    <td style={td}>{offer.name}</td>
                    <td style={tdRight}>${offer.price}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <Section style={totalBox}>
              <Text style={totalLabel}>Total Price</Text>
              <Text style={totalValue}>${totalPrice.toLocaleString()}</Text>
            </Section>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export default ProjectEmail

/* === Styles === */
const main = {
  backgroundColor: '#f4f4f7',
  fontFamily: 'Arial, sans-serif',
  padding: '40px 0',
}

const container = {
  backgroundColor: '#ffffff',
  borderRadius: '10px',
  padding: '0',
  maxWidth: '600px',
  margin: '0 auto',
  border: '1px solid #e0e0e0',
  overflow: 'hidden',
}

const header = {
  padding: '25px',
  borderBottom: '1px solid #eee',
  backgroundColor: '#6881ff',
  color: '#fff',
  textAlign: 'center' as const,
}

const logo = {
  display: 'block',
  margin: '0 auto',
}

const intro = {
  padding: '25px',
  borderBottom: '1px solid #eee',
}

const h1 = {
  fontSize: '22px',
  fontWeight: '700',
  marginBottom: '8px',
  color: '#111',
}

const introText = {
  fontSize: '15px',
  color: '#444',
}

const section = {
  padding: '25px',
  borderBottom: '1px solid #eee',
}

const h2 = {
  fontSize: '18px',
  fontWeight: '600',
  marginBottom: '12px',
  color: '#111',
}

const detail = {
  fontSize: '14px',
  marginBottom: '8px',
  color: '#333',
}

const brief = {
  fontSize: '14px',
  lineHeight: '1.5',
  color: '#222',
  backgroundColor: '#f9f9f9',
  padding: '12px',
  borderRadius: '6px',
}

const table = {
  width: '100%',
  borderCollapse: 'collapse' as const,
  marginTop: '10px',
}

const row = {
  borderBottom: '1px solid #ddd',
}

const td = {
  fontSize: '14px',
  padding: '8px 0',
  color: '#333',
}

const tdRight = {
  ...td,
  textAlign: 'right' as const,
  fontWeight: '600',
}

const totalBox = {
  backgroundColor: '#3355ff',
  borderRadius: '6px',
  padding: '16px',
  marginTop: '20px',
  textAlign: 'center' as const,
  color: '#fff',
}

const totalLabel = {
  fontSize: '16px',
  fontWeight: '600',
}

const totalValue = {
  fontSize: '28px',
  fontWeight: '800',
}
