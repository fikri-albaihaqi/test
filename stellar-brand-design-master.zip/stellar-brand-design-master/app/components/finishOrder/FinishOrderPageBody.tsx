'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import { usePackageContext } from '@/app/context/PackageContext'
import { useRouter } from 'next/navigation'
import { useMemo, useRef, useState } from 'react'
import { Form, FormProps, Input } from 'antd'
import { ContactFieldType } from '@/app/lib/types/types'
import { RuleObject } from 'antd/es/form'
import { CONTACT_PAGE_QUERYResult } from '@/sanity/types'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'
import BlockText from '../ui/text/BlockText'

gsap.registerPlugin(ScrollTrigger, SplitText)

const { TextArea } = Input

const loadingIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-current animate-spin"
  >
    <path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-155.5t86-127Q252-817 325-848.5T480-880q17 0 28.5 11.5T520-840q0 17-11.5 28.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q133 0 226.5-93.5T800-480q0-17 11.5-28.5T840-520q17 0 28.5 11.5T880-480q0 82-31.5 155t-86 127.5q-54.5 54.5-127 86T480-80Z" />
  </svg>
)

const arrowIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m256-240-56-56 384-384H240v-80h480v480h-80v-344L256-240Z" />
  </svg>
)

const FinishOrderPageBody = ({
  pageContent,
}: {
  pageContent: CONTACT_PAGE_QUERYResult
}) => {
  const [form] = Form.useForm()
  const { selectedPackages, setSelectedPackages } = usePackageContext()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [isFormValid, setIsFormValid] = useState<boolean>(false)
  const page1Ref = useRef<HTMLDivElement>(null)
  const page2Ref = useRef<HTMLDivElement>(null)

  const totalPrice = useMemo(() => {
    return selectedPackages.reduce((total, selectedPackageItem) => {
      return total + (selectedPackageItem?.price ?? 0)
    }, 0)
  }, [selectedPackages])

  const handleFieldsChange = () => {
    const fieldsToCheck = ['name', 'email']

    const allFieldsTouched = fieldsToCheck.every((field) =>
      form.isFieldTouched(field)
    )

    const hasSpecificErrors = fieldsToCheck.some(
      (field) => form.getFieldError(field).length > 0
    )

    setIsFormValid(allFieldsTouched && !hasSpecificErrors)
  }

  const validateEmail = (_: RuleObject, value: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!value) {
      return Promise.reject(new Error('Please enter an email!'))
    }
    if (!emailRegex.test(value)) {
      return Promise.reject(new Error('Please enter a valid email address!'))
    }
    return Promise.resolve()
  }

  const getButtonClass = () => {
    return isFormValid
      ? 'opacity-100 pointer-events-auto'
      : 'opacity-50 pointer-events-none'
  }

  const handleNextStep = async (page: number) => {
    try {
      if (currentPage === 1) {
        await form.validateFields(['name', 'email'])
      }

      gsap.to(page1Ref.current, {
        x: '-100%',
        opacity: 0,
        duration: 0.6,
        ease: 'power2.inOut',
        onComplete: () => {
          setCurrentPage(page)
          gsap.fromTo(
            page2Ref.current,
            { x: '100%', opacity: 0 },
            { x: '0%', opacity: 1, duration: 0.6, ease: 'power2.inOut' }
          )
        },
      })
    } catch (error) {
      console.log(error)
    }
  }

  const handlePrevStep = (page: number) => {
    gsap.to(page2Ref.current, {
      x: '100%',
      opacity: 0,
      duration: 0.6,
      ease: 'power2.inOut',
      onComplete: () => {
        setCurrentPage(page)
        gsap.fromTo(
          page1Ref.current,
          { x: '-100%', opacity: 0 },
          { x: '0%', opacity: 1, duration: 0.6, ease: 'power2.inOut' }
        )
      },
    })
  }

  const onFinish: FormProps<ContactFieldType>['onFinish'] = async (values) => {
    setIsLoading(true)
    const res = await fetch('/api/project-confirmation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: values.name,
        companyName: values.company,
        email: values.email,
        timeline: values.timeline,
        selectedOffers: selectedPackages,
        totalPrice: totalPrice,
        projectBrief: values.projectDescription,
      }),
    })

    if (res.ok) {
      router.replace('/thank-you')
      setIsLoading(false)
      setSelectedPackages([])
    } else {
      setIsLoading(false)
      alert('Failed to send email')
    }
  }

  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-24 xl:pt-32 overflow-x-hidden">
      <section className="w-full flex flex-col xl:flex-row items-start justify-between gap-x-8 xl:gap-x-16 gap-y-16 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="relative z-20 w-full xl:w-[40%] 2xl:w-[45%] flex flex-col gap-y-8">
          <h1 className="text-split text-6xl font-semibold">
            <PortableText
              value={
                pageContent?.welcomeText?.heading as TypedObject | TypedObject[]
              }
              components={BlockText}
            />
          </h1>
          <p className="text-split text-2xl">
            <PortableText
              value={
                pageContent?.welcomeText?.subHeading as
                  | TypedObject
                  | TypedObject[]
              }
              components={BlockText}
            />
          </p>

          <div className="flex flex-col gap-y-8">
            <div className="flex flex-col gap-y-4">
              <h2 className="text-2xl font-semibold">Order summary</h2>

              <ul className="space-y-2">
                {selectedPackages.map((packageItem) => (
                  <li
                    key={packageItem._id}
                    className="flex justify-between text-xl text-canvas-secondary-inverted-shade dark:text-gray-400"
                  >
                    <p>{packageItem.name}</p>
                    <p>${packageItem.price}</p>
                  </li>
                ))}
              </ul>
            </div>

            <div className="w-full bg-brand-primary rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row justify-between items-center text-font-primary-inverted text-center sm:text-left transition-colors duration-300">
              <p className="text-lg font-semibold mb-2 sm:mb-0">Your Total:</p>
              <p className="text-4xl sm:text-5xl font-extrabold">
                ${totalPrice.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <Form
          form={form}
          name="projectForm"
          onFinish={onFinish}
          onFieldsChange={handleFieldsChange}
          layout="vertical"
          variant="underlined"
          autoComplete="off"
          className={`relative z-10 w-full xl:w-[60%] 2xl:w-[55%] flex flex-col gap-y-8`}
        >
          <div
            ref={page1Ref}
            className={`${currentPage === 1 ? 'block' : 'hidden'} flex flex-col`}
          >
            <div className="flex flex-col gap-y-4 mb-8 2xl:mb-16">
              <h2 className="text-5xl text-font-primary dark:text-font-primary-inverted font-semibold">
                <PortableText
                  value={
                    pageContent?.contactText?.heading as
                      | TypedObject
                      | TypedObject[]
                  }
                  components={BlockText}
                />
              </h2>
              <p className="text-xl">
                <PortableText
                  value={
                    pageContent?.contactText?.subHeading as
                      | TypedObject
                      | TypedObject[]
                  }
                  components={BlockText}
                />
              </p>
            </div>

            <Form.Item<ContactFieldType>
              name="name"
              label={
                <span className="text-2xl text-font-primary dark:text-font-primary-inverted font-semibold">
                  What&apos;s your name?
                </span>
              }
              rules={[{ required: true, message: 'Please input your name!' }]}
              className="w-full"
            >
              <Input
                className="border-b-font-secondary-1! focus:border-b-brand-secondary! placeholder:text-font-secondary-1! placeholder:font-light"
                placeholder="Your name"
                style={{
                  border: 'none',
                  backgroundColor: 'transparent',
                  borderBottom: '1px solid var(--color-font-secondary-1)',
                  borderRadius: '0',
                  fontSize: 24,
                }}
              />
            </Form.Item>

            <Form.Item<ContactFieldType>
              name="company"
              label={
                <span className="text-2xl text-font-primary dark:text-font-primary-inverted font-semibold">
                  Company name
                </span>
              }
              className="w-full"
            >
              <Input
                className="border-b-font-secondary-1! focus:border-b-brand-secondary! placeholder:text-font-secondary-1! placeholder:font-light"
                placeholder="Company name"
                style={{
                  border: 'none',
                  backgroundColor: 'transparent',
                  borderBottom: '1px solid var(--color-font-secondary-1)',
                  borderRadius: '0',
                  fontSize: 24,
                }}
              />
            </Form.Item>

            <Form.Item<ContactFieldType>
              name="email"
              label={
                <span className="text-2xl text-font-primary dark:text-font-primary-inverted font-semibold">
                  Email
                </span>
              }
              rules={[
                {
                  validator: validateEmail,
                },
              ]}
              className="w-full"
            >
              <Input
                className="border-b-font-secondary-1! focus:border-b-brand-secondary! placeholder:text-font-secondary-1! placeholder:font-light"
                placeholder="Email address"
                type="email"
                style={{
                  border: 'none',
                  backgroundColor: 'transparent',
                  borderBottom: '1px solid var(--color-font-secondary-1)',
                  borderRadius: '0',
                  fontSize: 24,
                }}
              />
            </Form.Item>

            <button
              type="button"
              className={`${getButtonClass()} group w-max flex items-center gap-2 mt-4 cursor-pointer overflow-hidden text-base`}
              onClick={() => {
                handleNextStep(2)
              }}
            >
              <p
                className="px-4 py-1.5 rounded-full bg-brand-primary group-hover:bg-canvas-inverted dark:group-hover:bg-canvas text-font-primary-inverted 
                group-hover:text-font-inverted dark:group-hover:text-font-primary font-semibold transition-all duration-300"
              >
                Next step
              </p>
              <div className="relative w-[24px] h-[24px]">
                <span className="absolute left-0 group-hover:translate-x-[32px] group-hover:-translate-y-[32px] transition-all ease-in-out duration-300">
                  {arrowIcon}
                </span>
                <span className="absolute left-0 -translate-x-[32px] translate-y-[32px] group-hover:translate-x-0 group-hover:-translate-y-0 transition-all ease-in-out duration-300">
                  {arrowIcon}
                </span>
              </div>
            </button>
          </div>

          <div
            ref={page2Ref}
            className={`${currentPage === 2 ? 'block' : 'hidden'} flex flex-col`}
          >
            <div className="flex flex-col gap-y-4 mb-8 2xl:mb-16">
              <h2 className="text-5xl text-font-primary dark:text-font-primary-inverted font-semibold">
                <PortableText
                  value={
                    pageContent?.projectDetailText?.heading as
                      | TypedObject
                      | TypedObject[]
                  }
                  components={BlockText}
                />
              </h2>
              <p className="text-xl">
                <PortableText
                  value={
                    pageContent?.projectDetailText?.subHeading as
                      | TypedObject
                      | TypedObject[]
                  }
                  components={BlockText}
                />
              </p>
            </div>

            <Form.Item<ContactFieldType>
              name="timeline"
              label={
                <span className="text-2xl text-font-primary dark:text-font-primary-inverted font-semibold">
                  Timeline
                </span>
              }
              rules={[
                {
                  required: true,
                  message: 'Please input the project timeline!',
                },
              ]}
              className="w-full"
            >
              <Input
                className="border-b-font-secondary-1! focus:border-b-brand-secondary! placeholder:text-font-secondary-1! placeholder:font-light"
                placeholder="Ideal start/end date"
                style={{
                  border: 'none',
                  backgroundColor: 'transparent',
                  borderBottom: '1px solid var(--color-font-secondary-1)',
                  borderRadius: '0',
                  fontSize: 24,
                }}
              />
            </Form.Item>

            <Form.Item<ContactFieldType>
              name="projectDescription"
              label={
                <span className="flex flex-col gap-y-4 text-2xl text-font-primary dark:text-font-primary-inverted font-semibold">
                  Tell us about the project
                </span>
              }
              rules={[
                {
                  required: true,
                  message: 'Please tell us about your project.',
                },
              ]}
              className="w-full"
            >
              <TextArea
                rows={4}
                variant="outlined"
                placeholder="Please provide a summary of your project"
              />
            </Form.Item>

            <div className="flex items-center gap-x-4 mt-4">
              <button
                type="button"
                className="group w-max flex items-center gap-2 cursor-pointer overflow-hidden text-base"
                onClick={() => handlePrevStep(1)}
              >
                <div className="relative w-[24px] h-[24px] overflow-hidden">
                  <span className="absolute left-0 rotate-[225deg] group-hover:-translate-x-[32px] transition-all ease-in-out duration-300">
                    {arrowIcon}
                  </span>
                  <span className="absolute left-0 rotate-[225deg] translate-x-[32px] group-hover:translate-x-0 group-hover:-translate-y-0 transition-all ease-in-out duration-300">
                    {arrowIcon}
                  </span>
                </div>
                <p className="px-2 py-1.5 rounded-full text-font-primary-inverted group-hover:text-brand-secondary font-semibold transition-all duration-300">
                  Back
                </p>
              </button>

              <Form.Item label={null} className="w-fit mb-0!">
                <button
                  type="submit"
                  className="group w-max flex items-center gap-2 cursor-pointer overflow-hidden text-base"
                >
                  {isLoading ? (
                    loadingIcon
                  ) : (
                    <>
                      <p
                        className="px-4 py-1.5 rounded-full bg-brand-primary group-hover:bg-canvas-inverted dark:group-hover:bg-canvas text-font-primary-inverted 
                        group-hover:text-font-inverted dark:group-hover:text-font-primary font-semibold transition-all duration-300"
                      >
                        Send message
                      </p>
                      <div className="relative w-[24px] h-[24px]">
                        <span className="absolute left-0 group-hover:translate-x-[32px] group-hover:-translate-y-[32px] transition-all ease-in-out duration-300">
                          {arrowIcon}
                        </span>
                        <span
                          className="absolute left-0 -translate-x-[32px] translate-y-[32px] group-hover:translate-x-0 group-hover:-translate-y-0 transition-all ease-in-out 
                          duration-300"
                        >
                          {arrowIcon}
                        </span>
                      </div>
                    </>
                  )}
                </button>
              </Form.Item>
            </div>
          </div>
        </Form>
      </section>
    </main>
  )
}

export default FinishOrderPageBody
