'use client'

import { forwardRef, useEffect, useState } from 'react'

const CursorFollower = forwardRef<HTMLDivElement>(
  function CursorFollower(_props, ref) {
    const [isTouchDevice, setIsTouchDevice] = useState(false)

    useEffect(() => {
      const hasTouchPointer = window.matchMedia('(pointer: coarse)').matches

      const hasMaxTouchPoints =
        'maxTouchPoints' in navigator && navigator.maxTouchPoints > 0

      const hasLegacyTouch = 'ontouchstart' in window

      setIsTouchDevice(hasTouchPointer || hasMaxTouchPoints || hasLegacyTouch)
    }, [])

    return (
      !isTouchDevice && (
        <div
          ref={ref}
          className="fixed left-0 top-0 z-50 flex items-center justify-center pointer-events-none opacity-0"
        >
          <h2 className="text-xl bg-brand-primary/70 px-6 py-4 backdrop-blur-sm rounded-full text-font-primary-inverted">
            View Case Study
          </h2>
        </div>
      )
    )
  }
)

export default CursorFollower
