'use client'

import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Image from 'next/image'

gsap.registerPlugin(ScrollTrigger)

type ParallaxBackgroundProps = {
  src: string
  alt?: string
  speed?: number // lower = slower parallax (e.g. 0.3)
  className?: string
  overlayClassName?: string
  overlayImage?: React.ReactNode
  otherContent?: React.ReactNode
}

export default function ParallaxBackground({
  src,
  alt = '',
  speed = 0.2,
  className = '',
  overlayClassName = '',
  overlayImage,
  otherContent,
}: ParallaxBackgroundProps) {
  const backgroundRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = backgroundRef.current
    if (!el) return

    gsap.to(el, {
      yPercent: speed * -100,
      ease: 'none',
      scrollTrigger: {
        trigger: el,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true,
      },
    })
  }, [speed])

  return (
    <div className={`relative w-full overflow-hidden ${className}`}>
      <div
        ref={backgroundRef}
        className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[150%]"
      >
        <Image
          src={src}
          alt={alt}
          fill
          style={{ objectFit: 'cover' }}
        />
      </div>
      <div className={`absolute inset-0 ${overlayClassName}`}>
        {overlayImage}
      </div>
      <div>{otherContent}</div>
    </div>
  )
}
