'use client'

import { useEffect, useRef, useState } from 'react'
import { usePathname } from 'next/navigation'
import { gsap } from 'gsap'

export default function CursorLoader() {
  const cursorRef = useRef<HTMLDivElement | null>(null)
  const spinnerRef = useRef<SVGSVGElement | null>(null)
  const pathname = usePathname()

  const [isLoading, setIsLoading] = useState(false)
  const loadingTimerRef = useRef<number | null>(null)
  const stuckTimerRef = useRef<number | null>(null)

  const posRef = useRef({ x: 0, y: 0 })
  const desiredStartPosRef = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      posRef.current = { x: e.clientX, y: e.clientY }

      if (isLoading && cursorRef.current) {
        gsap.to(cursorRef.current, {
          x: e.clientX - cursorRef.current.offsetWidth / 2,
          y: e.clientY - cursorRef.current.offsetWidth / 2,
          duration: 0.12,
          ease: 'power3.out',
        })
      }
    }

    window.addEventListener('mousemove', handleMove)
    return () => window.removeEventListener('mousemove', handleMove)
  }, [isLoading])

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null
      if (!target) return

      const anchor = target.closest('a') as HTMLAnchorElement | null
      if (!anchor || !anchor.href) return

      if (anchor.target && anchor.target !== '_self') return

      try {
        const url = new URL(anchor.href, window.location.href)
        if (url.origin !== window.location.origin) return

        const current = new URL(window.location.href)
        if (
          url.pathname === current.pathname &&
          url.search === current.search &&
          url.hash === current.hash
        ) {
          return
        }
      } catch {
        return
      }

      if (loadingTimerRef.current) {
        window.clearTimeout(loadingTimerRef.current)
        loadingTimerRef.current = null
      }
      if (stuckTimerRef.current) {
        window.clearTimeout(stuckTimerRef.current)
        stuckTimerRef.current = null
      }

      loadingTimerRef.current = window.setTimeout(() => {
        desiredStartPosRef.current = { ...posRef.current }

        setIsLoading(true)
        document.body.classList.add('cursor-none')

        stuckTimerRef.current = window.setTimeout(() => {
          setIsLoading(false)
          document.body.classList.remove('cursor-none')
          if (loadingTimerRef.current) {
            window.clearTimeout(loadingTimerRef.current)
            loadingTimerRef.current = null
          }
          stuckTimerRef.current = null
        }, 10_000)
      }, 150)
    }

    document.addEventListener('click', handleClick)
    return () => {
      document.removeEventListener('click', handleClick)
      if (loadingTimerRef.current) {
        window.clearTimeout(loadingTimerRef.current)
        loadingTimerRef.current = null
      }
      if (stuckTimerRef.current) {
        window.clearTimeout(stuckTimerRef.current)
        stuckTimerRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    if (isLoading && cursorRef.current) {
      const { x, y } = desiredStartPosRef.current
      gsap.set(cursorRef.current, {
        x: x - cursorRef.current.offsetWidth / 2,
        y: y - cursorRef.current.offsetWidth / 2,
      })

      if (spinnerRef.current) {
        gsap.killTweensOf(spinnerRef.current)
        gsap.to(spinnerRef.current, {
          rotation: 360,
          duration: 1,
          ease: 'linear',
          repeat: -1,
          transformOrigin: '50% 50%',
        })
      }
    }

    if (!isLoading && spinnerRef.current) {
      gsap.killTweensOf(spinnerRef.current)
      gsap.set(spinnerRef.current, { rotation: 0 })
    }
  }, [isLoading])

  useEffect(() => {
    if (loadingTimerRef.current) {
      window.clearTimeout(loadingTimerRef.current)
      loadingTimerRef.current = null
    }
    if (stuckTimerRef.current) {
      window.clearTimeout(stuckTimerRef.current)
      stuckTimerRef.current = null
    }

    if (isLoading) {
      setIsLoading(false)
      document.body.classList.remove('cursor-none')
    }
  }, [pathname])

  if (!isLoading) return null

  return (
    <div
      ref={cursorRef}
      className="fixed top-0 left-0 w-16 h-16 pointer-events-none z-[9999] flex items-center justify-center origin-center"
      style={{ transform: 'translate(0px, 0px)' }}
    >
      <svg
        ref={spinnerRef}
        className="w-16 h-16"
        viewBox="0 0 50 50"
        aria-hidden
      >
        <circle
          cx="25"
          cy="25"
          r="20"
          stroke="#3355ff"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
          strokeDasharray="100"
          strokeDashoffset="45"
        />
      </svg>
    </div>
  )
}
