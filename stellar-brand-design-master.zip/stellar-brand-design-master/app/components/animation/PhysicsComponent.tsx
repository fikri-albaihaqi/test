'use client'

import React, { useEffect, useRef, useState } from 'react'
import {
  Engine,
  Render,
  Runner,
  Composite,
  Bodies,
  Body,
  Mouse,
  MouseConstraint,
  Events,
  Query,
} from 'matter-js'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface PhysicsProps {
  images?: string[]
  className?: string
  onDragStart?: () => void
  onDragEnd?: () => void
}

interface ImageBody extends Matter.Body {
  image?: HTMLImageElement
  originalWidth?: number
  originalHeight?: number
}

// --- helper to preload image and attach to body ---
function createImageBody(
  x: number,
  y: number,
  w: number,
  h: number,
  texture: string
) {
  const body = Bodies.rectangle(x, y, w, h, {
    density: 0.001,
    friction: 0.5,
    frictionAir: 0.01,
    restitution: 0.8,
    render: {
      fillStyle: 'transparent',
      strokeStyle: 'transparent',
    },
  }) as ImageBody

  const img = new Image()
  img.src = texture
  body.image = img
  body.originalWidth = w
  body.originalHeight = h

  return body
}

const PhysicsComponent: React.FC<PhysicsProps> = ({
  images = [],
  className = '',
  onDragStart,
  onDragEnd,
}) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const engineRef = useRef<Engine | null>(null)
  const renderRef = useRef<Render | null>(null)
  const runnerRef = useRef<Runner | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isHoveringBody, setIsHoveringBody] = useState(false)

  useEffect(() => {
    if (
      typeof window === 'undefined' ||
      typeof gsap === 'undefined' ||
      typeof ScrollTrigger === 'undefined'
    ) {
      console.error('GSAP or ScrollTrigger not available globally.')
      return
    }

    const currentContainer = containerRef.current
    if (!currentContainer) return

    const { clientWidth, clientHeight } = currentContainer
    if (clientWidth === 0 || clientHeight === 0) return

    const engine = Engine.create()
    const render = Render.create({
      element: currentContainer,
      engine: engine,
      options: {
        width: clientWidth,
        height: clientHeight,
        background: 'transparent',
        wireframes: false,
      },
    })

    engineRef.current = engine
    renderRef.current = render

    const runner = Runner.create()
    runnerRef.current = runner

    // --- track hovered body ---
    let hoveredBody: (Body & { image?: HTMLImageElement }) | null = null

    const createBodiesFromImages = async (
      imageUrls: string[]
    ): Promise<void> => {
      const imagePromises = imageUrls.map((imageUrl) => {
        return new Promise<{ imageUrl: string; width: number; height: number }>(
          (resolve, reject) => {
            const img = new window.Image()
            img.onload = () =>
              resolve({
                imageUrl,
                width: img.naturalWidth,
                height: img.naturalHeight,
              })
            img.onerror = () =>
              reject(new Error(`Failed to load image at ${imageUrl}`))
            img.src = imageUrl
          }
        )
      })

      try {
        const loadedImages = await Promise.all(imagePromises)
        let currentX = 0
        const scaleFactor = 0.25

        const firstWordImageCount = 7
        const firstWordImages = loadedImages.slice(0, firstWordImageCount)
        const secondWordImages = loadedImages.slice(firstWordImageCount)

        const totalFirstWordWidth = firstWordImages.reduce(
          (sum, img) => sum + img.width * scaleFactor,
          0
        )
        const startX_first = clientWidth - totalFirstWordWidth - 150

        const firstWordBodies = firstWordImages.map(
          ({ imageUrl, width, height }) => {
            const bodyWidth = width * scaleFactor
            const bodyHeight = height * scaleFactor
            const xPos = startX_first + currentX + bodyWidth / 2
            const yPos = -bodyHeight * 2
            currentX += bodyWidth + 10

            return createImageBody(xPos, yPos, bodyWidth, bodyHeight, imageUrl)
          }
        )

        let secondWordBodies: Matter.Body[] = []
        if (secondWordImages.length > 0) {
          currentX = 0
          const totalSecondWordWidth = secondWordImages.reduce(
            (sum, img) => sum + img.width * scaleFactor,
            0
          )

          const startX_second = clientWidth - totalSecondWordWidth - 150
          const startY_second = -50

          secondWordBodies = secondWordImages.map(
            ({ imageUrl, width, height }) => {
              const bodyWidth = width * scaleFactor
              const bodyHeight = height * scaleFactor
              const xPos = startX_second + currentX + bodyWidth / 2
              const yPos = startY_second - bodyHeight
              currentX += bodyWidth + 30

              return createImageBody(
                xPos,
                yPos,
                bodyWidth,
                bodyHeight,
                imageUrl
              )
            }
          )
        }

        Composite.add(engine.world, [...firstWordBodies, ...secondWordBodies])
      } catch (error) {
        console.error('Error loading images:', error)
      }
    }

    createBodiesFromImages(images)

    // boundaries
    Composite.add(engine.world, [
      Bodies.rectangle(clientWidth / 2, -500, clientWidth, 50, {
        isStatic: true,
        render: { fillStyle: 'transparent' },
      }),
      Bodies.rectangle(clientWidth / 2, clientHeight + 25, clientWidth, 50, {
        isStatic: true,
        render: { fillStyle: 'transparent' },
      }),
      Bodies.rectangle(clientWidth + 25, clientHeight / 2, 50, clientHeight, {
        isStatic: true,
        render: { fillStyle: 'transparent' },
      }),
      Bodies.rectangle(-25, clientHeight / 2, 50, clientHeight, {
        isStatic: true,
        render: { fillStyle: 'transparent' },
      }),
    ])

    // mouse
    const mouse = Mouse.create(render.canvas)
    const mouseConstraint = MouseConstraint.create(engine, {
      mouse: mouse,
      constraint: {
        stiffness: 0.05,
        damping: 0.5,
        render: { visible: false },
      },
    })
    Composite.add(engine.world, mouseConstraint)
    render.mouse = mouse

    Events.on(mouseConstraint, 'mousedown', (event) => {
      if (event.source.body) {
        setIsDragging(true)
      }
    })

    Events.on(mouseConstraint, 'mouseup', (event) => {
      setIsDragging(false)

      if (event.source.body) {
        const body = event.source.body

        // Get current velocity
        const { x, y } = body.velocity

        // Apply a little "extra push" to exaggerate bounce
        Body.setVelocity(body, {
          x: x * 1.5, // amplify existing motion
          y: y * 1.5,
        })

        // Optionally add a slight rotation impulse for more natural motion
        Body.setAngularVelocity(body, body.angularVelocity + 0.2)
      }
    })

    Events.on(mouseConstraint, 'mousemove', (event) => {
      const bodies = Composite.allBodies(engine.world) as (Body & {
        image?: HTMLImageElement
      })[]
      const foundBodies = Query.point(bodies, event.mouse.position)
      hoveredBody = foundBodies.length > 0 ? foundBodies[0] : null
      setIsHoveringBody(foundBodies.length > 0)
    })

    Events.on(render, 'afterRender', () => {
      const ctx = render.context
      const bodies = Composite.allBodies(engine.world) as (Body & {
        image?: HTMLImageElement
        originalWidth?: number
        originalHeight?: number
      })[]

      bodies.forEach((body) => {
        if (!body.image || !body.originalWidth || !body.originalHeight) return

        const { x, y } = body.position
        const w = body.originalWidth
        const h = body.originalHeight

        ctx.save()
        ctx.translate(x, y)
        ctx.rotate(body.angle)

        if (body === hoveredBody) {
          ctx.shadowBlur = 20
          ctx.shadowColor = 'rgba(51, 85, 255, 0.8)'
        } else {
          ctx.shadowBlur = 0
        }

        ctx.drawImage(body.image, -w / 2, -h / 2, w, h)
        ctx.restore()
      })
    })

    // scroll trigger
    const scrollTriggerInstance = ScrollTrigger.create({
      trigger: currentContainer,
      start: 'top bottom',
      end: 'bottom top',
      onEnter: () => {
        Render.run(render)
        Runner.run(runner, engine)
      },
      onLeave: () => {
        Render.stop(render)
        Runner.stop(runner)
      },
      onEnterBack: () => {
        Render.run(render)
        Runner.run(runner, engine)
      },
      onLeaveBack: () => {
        Render.stop(render)
        Runner.stop(runner)
      },
    })

    return () => {
      if (scrollTriggerInstance) scrollTriggerInstance.kill()
      Render.stop(render)
      Runner.stop(runner)
      Engine.clear(engine)
      render.canvas.remove()
    }
  }, [images, onDragStart, onDragEnd])

  const cursorClass = isDragging
    ? 'cursor-grabbing'
    : isHoveringBody
      ? 'cursor-grab'
      : 'cursor-default'

  return (
    <div
      ref={containerRef}
      className={`${className} ${isDragging ? 'z-30' : 'z-10'} ${cursorClass}`}
    />
  )
}

export default PhysicsComponent
