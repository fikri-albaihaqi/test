'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '@/app/lib/utils/animations/textAnimation'
import AnimatedContent from '../animation/AnimatedContent'
import Image from 'next/image'
import Tag from '../ui/tag/Tag'

gsap.registerPlugin(ScrollTrigger, SplitText)

const WorkDetailHeroSection = ({
  heroImage,
  client,
  year,
  workName,
  tags,
}: {
  heroImage:
    | {
        _key: string
        _type: 'image'
        asset: {
          url: string | null
        } | null
        alt: string | null
      }
    | undefined
  client: string | null | undefined
  year: string | null | undefined
  workName: string | null | undefined
  tags: string[] | null | undefined
}) => {
  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })

  return (
    <section className="relative w-full 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] overflow-hidden">
      <div className="w-full mb-8">
        <div className="flex items-center gap-x-2 mb-4">
          <h2 className="text-split font-semibold">{client}</h2>
          <div className="w-3 h-3 relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
          </div>
          <h2 className="text-split font-semibold">{year}</h2>
        </div>
        <h2 className="text-split leading-tight text-4xl md:text-6xl font-semibold">
          {workName}
        </h2>
      </div>

      <div className="relative">
        <AnimatedContent
          distance={150}
          direction="vertical"
          reverse={false}
          duration={1.2}
          ease={'power3.out'}
        >
          <div className="relative w-full h-[320px] md:h-[560px] lg:h-[440px] xl:h-[600px] 2xl:h-[730px] overflow-hidden">
            <Image
              src={heroImage?.asset?.url || ''}
              alt={heroImage?.alt || ''}
              fill
              className="object-cover rounded-xl lg:rounded-3xl"
            />

            <div className="absolute flex flex-col top-0 right-0 bg-canvas dark:bg-canvas-inverted pb-4 pl-6 rounded-bl-3xl">
              <svg
                id="Layer_1"
                className="absolute w-9 h-9 -left-9 top-0 rotate-90 fill-canvas dark:fill-canvas-inverted"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                x="0"
                y="0"
                viewBox="0 0 100 100"
              >
                <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
              </svg>

              <div className="flex gap-x-2">
                {tags?.map((tag, index) => (
                  <Tag key={index} tag={tag} />
                ))}
              </div>

              <svg
                id="Layer_1"
                className="absolute w-9 h-9 right-0 -bottom-9 rotate-90 fill-canvas dark:fill-canvas-inverted"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                x="0"
                y="0"
                viewBox="0 0 100 100"
              >
                <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
              </svg>
            </div>
          </div>
        </AnimatedContent>
      </div>
    </section>
  )
}

export default WorkDetailHeroSection
