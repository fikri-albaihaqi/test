import Link from 'next/link'
import { PROJECT_TAGS_QUERY } from '@/sanity/lib/queries'
import { client } from '@/sanity/lib/client'

const ProjectFilter = async () => {
  const tags = await client.fetch(PROJECT_TAGS_QUERY)

  return (
    <div className="w-full flex flex-wrap gap-x-4 gap-y-4">
      <Link
        href="/work/"
        className="px-4 py-2 text-xl bg-font-secondary-3 hover:bg-brand-secondary text-font-primary hover:text-font-primary-inverted transition-all rounded-full"
      >
        All
      </Link>

      {tags.map((tag, index) => (
        <Link
          key={index}
          href={`/work/tag/${tag}`}
          className="px-4 py-2 text-xl bg-font-secondary-3 hover:bg-brand-secondary text-font-primary hover:text-font-primary-inverted transition-all rounded-full"
        >
          {tag}
        </Link>
      ))}
    </div>
  )
}

export default ProjectFilter
