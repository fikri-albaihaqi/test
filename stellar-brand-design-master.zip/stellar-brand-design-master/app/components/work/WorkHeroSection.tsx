'use client'

import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { initTextAnimations } from '../../lib/utils/animations/textAnimation'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'
import BlockText from '../ui/text/BlockText'

gsap.registerPlugin(ScrollTrigger, SplitText)

const WorkHeroSection = ({
  heroHeading,
  heroDescription,
}: {
  heroHeading: string | null | undefined
  heroDescription: TypedObject | TypedObject[]
}) => {
  useGSAP(() => {
    const timer = setTimeout(() => {
      initTextAnimations()

      ScrollTrigger.refresh()
    }, 100)

    return () => clearTimeout(timer)
  })
  return (
    <section className="relative w-full flex flex-col lg:flex-row justify-between items-start gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] overflow-hidden">
      <div className="w-full lg:w-1/2 flex items-center gap-x-2">
        <div className="w-3 h-3 relative overflow-hidden">
          <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
        </div>
        <h1 className="text-split text-xl lg:text-2xl font-semibold">
          {heroHeading}
        </h1>
      </div>

      <p className="text-split w-full lg:w-2/3 text-3xl lg:text-5xl font-semibold leading-tight">
        <PortableText value={heroDescription} components={BlockText} />
      </p>
    </section>
  )
}

export default WorkHeroSection
