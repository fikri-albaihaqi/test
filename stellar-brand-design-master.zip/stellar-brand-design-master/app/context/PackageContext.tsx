'use client'

import { createContext, useContext, useState, ReactNode } from 'react'
import { PackageArrayType } from '../lib/types/types'

type PackageContextType = {
  selectedPackages: PackageArrayType
  setSelectedPackages: React.Dispatch<React.SetStateAction<PackageArrayType>>
}

const PackageContext = createContext<PackageContextType | undefined>(undefined)

export function PackageProvider({ children }: { children: ReactNode }) {
  const [selectedPackages, setSelectedPackages] = useState<PackageArrayType>([])

  return (
    <PackageContext.Provider value={{ selectedPackages, setSelectedPackages }}>
      {children}
    </PackageContext.Provider>
  )
}

export function usePackageContext() {
  const context = useContext(PackageContext)
  if (!context) {
    throw new Error('usePackageContext must be used within PackageProvider')
  }
  return context
}
