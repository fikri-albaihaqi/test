import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Stellar Brand Design',
  description:
    'At Stellar Brand Design we help brands find their voice, and amplify it.',
  icons: {
    icon: '/favicon.png',
  },
}

export default function StudioLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}
