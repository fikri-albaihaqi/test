import { NextResponse } from 'next/server'

// Define types for the documents we expect from Sanity
interface SanityDoc {
  slug: string
  _updatedAt: string
}

// Your Sanity fetch helper
async function fetchSanityDocs<T = SanityDoc>(query: string): Promise<T[]> {
  const res = await fetch(
    `https://${process.env.NEXT_PUBLIC_SANITY_PROJECT_ID}.api.sanity.io/v2023-10-01/data/query/${process.env.NEXT_PUBLIC_SANITY_DATASET}?query=${encodeURIComponent(
      query
    )}`,
    { next: { revalidate: 60 } }
  )

  if (!res.ok) {
    throw new Error(`Failed to fetch Sanity docs: ${res.statusText}`)
  }

  const data = await res.json()
  return (data.result || []) as T[]
}

export async function GET() {
  const baseUrl = 'https://stellarbranddesign.com'

  // Dynamic routes
  const blogs = await fetchSanityDocs(
    `*[_type == "blogPost" && defined(slug.current)]{ "slug": slug.current, _updatedAt }`
  )
  const works = await fetchSanityDocs(
    `*[_type == "project" && defined(slug.current)]{ "slug": slug.current, _updatedAt }`
  )
  const services = await fetchSanityDocs(
    `*[_type == "service" && defined(slug.current)]{ "slug": slug.current, _updatedAt }`
  )

  // Static routes (add any pages you have)
  const staticPages: { path: string; lastModified: string }[] = [
    { path: '', lastModified: new Date().toISOString() }, // homepage
    { path: '/about', lastModified: new Date().toISOString() },
    { path: '/services', lastModified: new Date().toISOString() },
    { path: '/work', lastModified: new Date().toISOString() },
    { path: '/blog', lastModified: new Date().toISOString() },
    { path: '/contact', lastModified: new Date().toISOString() },
    { path: '/terms-of-service', lastModified: new Date().toISOString() },
    { path: '/privacy-policy', lastModified: new Date().toISOString() },
  ]

  // Helper to assign SEO metadata
  function getMeta(url: string): { changefreq: string; priority: number } {
    if (url === baseUrl || url === `${baseUrl}/`) {
      return { changefreq: 'daily', priority: 1.0 }
    }
    if (
      url.includes('/about') ||
      url.includes('/contact') ||
      url.includes('/privacy-policy') ||
      url.includes('/terms-of-service')
    ) {
      return { changefreq: 'yearly', priority: 0.4 }
    }
    if (url.includes('/services')) {
      return { changefreq: 'monthly', priority: 0.7 }
    }
    if (url.includes('/work')) {
      return { changefreq: 'monthly', priority: 0.6 }
    }
    if (url.includes('/blog/') && !url.endsWith('/blog')) {
      return { changefreq: 'monthly', priority: 0.5 } // individual blog posts
    }
    if (url.endsWith('/blog')) {
      return { changefreq: 'weekly', priority: 0.6 } // blog listing
    }
    return { changefreq: 'weekly', priority: 0.5 }
  }

  // Combine all routes
  const allRoutes: { url: string; lastModified: string }[] = [
    // static
    ...staticPages.map((page) => ({
      url: `${baseUrl}${page.path}`,
      lastModified: page.lastModified,
    })),

    // dynamic
    ...services.map((s) => ({
      url: `${baseUrl}/services/${s.slug}`,
      lastModified: s._updatedAt,
    })),
    ...works.map((w) => ({
      url: `${baseUrl}/work/${w.slug}`,
      lastModified: w._updatedAt,
    })),
    ...blogs.map((b) => ({
      url: `${baseUrl}/blog/${b.slug}`,
      lastModified: b._updatedAt,
    })),
  ]

  // Build XML
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allRoutes
  .map((route) => {
    const { changefreq, priority } = getMeta(route.url)
    return `
  <url>
    <loc>${route.url}</loc>
    <lastmod>${route.lastModified}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`
  })
  .join('')}
</urlset>`

  return new NextResponse(sitemap, {
    headers: {
      'Content-Type': 'application/xml',
    },
  })
}
