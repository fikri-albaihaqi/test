import FinishOrderPageBody from '@/app/components/finishOrder/FinishOrderPageBody'
import { client } from '@/sanity/lib/client'
import { CONTACT_PAGE_CONTENT_QUERY } from '@/sanity/lib/queries'

export const revalidate = 60

const FinishOrder = async () => {
  const pageContent = await client.fetch(CONTACT_PAGE_CONTENT_QUERY)

  return <FinishOrderPageBody pageContent={pageContent} />
}

export default FinishOrder
