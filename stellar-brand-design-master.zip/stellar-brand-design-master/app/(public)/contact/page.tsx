import ContactPageBody from '@/app/components/contact/ContactPageBody'
import { client } from '@/sanity/lib/client'
import { CONTACT_PAGE_CONTENT_QUERY } from '@/sanity/lib/queries'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Contact Us | Stellar Brand Design',
  description:
    'Get in touch with Stellar Brand Design. Let’s talk about your branding and web design needs — from startup launches to scaling businesses ready to grow.',
}

export const revalidate = 60

const Contact = async () => {
  const pageContent = await client.fetch(CONTACT_PAGE_CONTENT_QUERY)

  return <ContactPageBody pageContent={pageContent} />
}

export default Contact
