import BlogPageBody from '@/app/components/blog/BlogPageBody'
import { BlogArrayType } from '@/app/lib/types/types'
import { client } from '@/sanity/lib/client'
import {
  BLOG_PAGE_CONTENT_QUERY,
  BLOG_POSTS_QUERY,
  BLOG_TAGS_QUERY,
} from '@/sanity/lib/queries'
import { Metadata } from 'next'
import { TypedObject } from 'sanity'

export const metadata: Metadata = {
  title: 'Insights & Resources | Stellar Brand Design Blog',
  description:
    'Read the Stellar Brand Design blog for insights on branding, web design, and digital strategy. Learn tips, trends, and strategies to help your business grow and stand out.',
}

export const revalidate = 60

export default async function BlogPage() {
  const blogHeading = await client.fetch(BLOG_PAGE_CONTENT_QUERY)
  const blogPosts = await client.fetch(BLOG_POSTS_QUERY)
  const tags = await client.fetch(BLOG_TAGS_QUERY)

  return (
    <BlogPageBody
      heading={blogHeading?.heroHeading as TypedObject | TypedObject[]}
      posts={blogPosts as BlogArrayType}
      tags={tags}
    />
  )
}
