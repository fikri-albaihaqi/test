import BlogDetailHeroSection from '@/app/components/blog/BlogDetailHeroSection'
import BlogSidebar from '@/app/components/blog/BlogSidebar'
import { client } from '@/sanity/lib/client'
import { BLOG_POSTS_QUERY, BLOG_POST_DETAIL_QUERY } from '@/sanity/lib/queries'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'
import BlogBlockText from '@/app/components/ui/text/BlogBlockText'
import { Metadata } from 'next'
import { sanityBlockToPlainText } from '@/app/lib/utils/helpers/sanityBlockPlainText'
import RecommendedBlogSection from '@/app/components/blog/RecommendedBlogSection'

interface PageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const slug = (await params).slug

  const blog = await client.fetch(BLOG_POST_DETAIL_QUERY, {
    slug: slug,
  })

  return {
    title: `${blog?.title} | Stellar Brand Design`,
    description: `${sanityBlockToPlainText(blog?.body).slice(0, 160)}…`,
  }
}

export const revalidate = 60

const BlogDetail = async ({ params }: PageProps) => {
  const { slug } = await params
  const blogPost = await client.fetch(BLOG_POST_DETAIL_QUERY, {
    slug: slug,
  })
  const recommendedBlogPosts = await client.fetch(BLOG_POSTS_QUERY)
  const blogPublishDate = blogPost?.publishedAt

  return (
    <main className="w-full flex flex-col items-center gap-y-16 xl:gap-y-32 pt-16 md:pt-32">
      {/* Hero section */}
      <BlogDetailHeroSection blogData={blogPost} />

      {/* Article section */}
      <section className="w-full flex flex-col-reverse xl:flex-row items-start justify-between gap-x-8 gap-y-32 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <BlogSidebar
          blogTitle={blogPost?.title as string | number | boolean}
          publishedAt={blogPublishDate}
        />

        <article className="w-full xl:w-[60%] flex flex-col text-2xl">
          {blogPost?.audioFile?.asset?.url && (
            <div className="w-full flex flex-col gap-y-4">
              <h2 className="text-xl font-semibold">
                Listen to This Podcast/Explainer Audio for This Blog
              </h2>
              <audio
                controls
                src={blogPost.audioFile.asset.url}
                className="w-full"
              />
            </div>
          )}

          <PortableText
            value={blogPost?.body as TypedObject | TypedObject[]}
            components={BlogBlockText}
          />
        </article>
      </section>

      {/* Recommended blog section */}
      <RecommendedBlogSection recommendedPosts={recommendedBlogPosts} />
    </main>
  )
}

export default BlogDetail
