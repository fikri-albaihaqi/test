import ServicesSection from '../components/home/ServicesSection'
import CTASection from '../components/ui/section/CTASection'
import TestimonialSection from '../components/ui/section/TestimonialSection'
import HeroAboutSection from '../components/home/HeroAboutSection'
import CaseStudiesSection from '../components/home/CaseStudiesSection'
import { client } from '@/sanity/lib/client'
import { CLIENT_LOGO_QUERY, HOME_PAGE_CONTENT_QUERY } from '@/sanity/lib/queries'
import { TypedObject } from 'sanity'
import { FeaturedServicesType } from '../lib/types/types'

export const revalidate = 60

export default async function Home() {
  const homeContent = await client.fetch(HOME_PAGE_CONTENT_QUERY)

  // Hero content
  const desktopVideoUrl = homeContent?.desktopHeroVideo?.asset?.url ?? ''
  const mobileVideoUrl = homeContent?.mobileHeroVideo?.asset?.url ?? ''
  const heroHeadingLine1 = homeContent?.heroHeadingLine1 as
    | TypedObject
    | TypedObject[]
  const heroHeadingLine2 = homeContent?.heroHeadingLine2 as
    | TypedObject
    | TypedObject[]
  const about = homeContent?.aboutSectionParagraph as
    | TypedObject
    | TypedObject[]

  // About section content
  const aboutSectionProjects = homeContent?.aboutSectionProjects
  const clientLogo = await client.fetch(CLIENT_LOGO_QUERY)

  // Services section content
  const servicesSectionHeading = homeContent?.serviceSectionText?.title
  const servicesSectionDescription = homeContent?.serviceSectionText
    ?.description as TypedObject | TypedObject[]
  const featuredServices = homeContent?.featuredServices as FeaturedServicesType

  // Project/Case Studies section content
  const projectsSectionHeading = homeContent?.projectSectionText?.title
  const projectsSectionSubHeading = homeContent?.projectSectionText?.subHeading
  const featuredProjects = homeContent?.featuredProject

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-16 lg:pt-24 xl:pt-32">
      <HeroAboutSection
        desktopVideoUrl={desktopVideoUrl}
        mobileVideoUrl={mobileVideoUrl}
        heroHeadingLine1={heroHeadingLine1}
        heroHeadingLine2={heroHeadingLine2}
        about={about}
        aboutSectionProjects={aboutSectionProjects}
        clientLogo={clientLogo}
      />
      <ServicesSection
        servicesSectionHeading={servicesSectionHeading}
        servicesSectionDescription={servicesSectionDescription}
        featuredServices={featuredServices}
      />
      <CaseStudiesSection
        projectsSectionHeading={projectsSectionHeading}
        projectsSectionSubHeading={projectsSectionSubHeading}
        featuredProjects={featuredProjects}
      />
      <TestimonialSection />
      <CTASection />
    </main>
  )
}
