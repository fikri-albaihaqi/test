import TestimonialSection from '../../components/ui/section/TestimonialSection'
import CTASection from '../../components/ui/section/CTASection'
import { client } from '@/sanity/lib/client'
import {
  PACKAGES_QUERY,
  PRICING_PAGE_CONTENT_QUERY,
  SERVICE_CATEGORY_QUERY,
} from '@/sanity/lib/queries'
import { TypedObject } from 'sanity'
import PricingPageBody from '@/app/components/pricing/PricingPageBody'

export const revalidate = 60

const Pricing = async () => {
  const pricingContent = await client.fetch(PRICING_PAGE_CONTENT_QUERY)
  const heroHeading = pricingContent?.heroHeading as TypedObject | TypedObject[]
  const description = pricingContent?.description as TypedObject | TypedObject[]

  const packages = await client.fetch(PACKAGES_QUERY)
  // const serviceCategories = await client.fetch(SERVICE_PAGE_SERVICES_QUERY)
  const categories = await client.fetch(SERVICE_CATEGORY_QUERY)

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-24 xl:pt-32 overflow-x-hidden">
      {/* Hero section */}
      <PricingPageBody
        heroHeading={heroHeading}
        description={description}
        packages={packages}
        categories={categories}
      />

      {/* Testimonials section */}
      <TestimonialSection />

      {/* CTA section */}
      <CTASection />
    </main>
  )
}

export default Pricing
