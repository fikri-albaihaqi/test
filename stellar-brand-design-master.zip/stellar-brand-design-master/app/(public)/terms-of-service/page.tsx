import BlogBlockText from '@/app/components/ui/text/BlogBlockText'
import { client } from '@/sanity/lib/client'
import { TERMS_OF_SERVICE_PAGE_CONTENT_QUERY } from '@/sanity/lib/queries'
import { Metadata } from 'next'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'

export const metadata: Metadata = {
  title: 'Terms of Service | Stellar Brand Design',
  description:
    'Review the Terms of Service for Stellar Brand Design. Understand the guidelines, agreements, and conditions for using our website and services.',
}

const TermsOfService = async () => {
  const termsOfService = await client.fetch(TERMS_OF_SERVICE_PAGE_CONTENT_QUERY)

  return (
    <main className="flex flex-col items-center pt-32">
      <section className="w-full flex flex-col xl:flex-row items-start justify-between gap-y-16 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="xl:sticky top-8 w-full xl:w-[40%]">
          <h1 className="text-split text-4xl md:text-6xl font-semibold">
            Terms of Service
          </h1>
        </div>

        <div className="w-full xl:w-1/2 flex flex-col gap-y-8 text-xl">
          <PortableText
            value={termsOfService?.body as TypedObject | TypedObject[]}
            components={BlogBlockText}
          />
        </div>
      </section>
    </main>
  )
}

export default TermsOfService
