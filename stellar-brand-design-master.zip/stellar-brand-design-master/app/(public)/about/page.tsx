import React from 'react'
import TestimonialSection from '../../components/ui/section/TestimonialSection'
import CTASection from '../../components/ui/section/CTASection'
import {
  ABOUT_PAGE_CONTENT_QUERY,
  CLIENT_LOGO_QUERY,
  ABOUT_PAGE_SERVICES_QUERY,
  TEAM_MEMBER_QUERY,
} from '@/sanity/lib/queries'
import { client } from '@/sanity/lib/client'
import { TypedObject } from 'sanity'
import {
  FeaturedProjectType,
  TeamMembersQueryResult,
} from '@/app/lib/types/types'
import MemberTicker from '@/app/components/about/MemberTicker'
import HeroSection from '@/app/components/about/HeroSection'
import AboutSection from '@/app/components/about/AboutSection'
import ClientLogo from '@/app/components/about/ClientLogo'
import ExpertiseSection from '@/app/components/about/ExpertiseSection'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'About Us | Stellar Brand Design',
  description:
    'Learn more about Stellar Brand Design — a creative team dedicated to building bold brands and high-performance websites that spark connection and fuel business growth.',
}

export const revalidate = 60

const About = async () => {
  const aboutContent = await client.fetch(ABOUT_PAGE_CONTENT_QUERY)
  const heroHeading = aboutContent?.heroText?.heroHeading as
    | TypedObject
    | TypedObject[]
  const description = aboutContent?.heroText?.description as
    | TypedObject
    | TypedObject[]
  const heroProjects = aboutContent?.heroProjects as FeaturedProjectType

  const clientLogo = await client.fetch(CLIENT_LOGO_QUERY)

  const services = await client.fetch(ABOUT_PAGE_SERVICES_QUERY)

  const teamMember = (await client.fetch(
    TEAM_MEMBER_QUERY
  )) as TeamMembersQueryResult

  return (
    <main className="flex flex-col gap-y-16 xl:gap-y-32 pt-16 lg:pt-32 xl:pt-0">
      {/* Hero section */}
      <HeroSection
        heroHeading={heroHeading}
        heroProjects={heroProjects}
        description={description}
      />

      {/* About section */}
      <AboutSection
        stats={aboutContent?.companyStats}
        desktopHeroVideo={aboutContent?.heroVideo}
        mobileHeroVideo={aboutContent?.mobileHeroVideo}
      />

      {/* Client Logo section */}
      <ClientLogo
        heading={aboutContent?.ourClientSectionHeading}
        clientLogo={clientLogo}
      />

      {/* Expertise section */}
      <ExpertiseSection
        heading={aboutContent?.expertiseSectionHeading}
        services={services}
      />

      {/* Teams section */}
      <section className="team w-screen flex flex-col bg-canvas-secondary dark:bg-canvas-secondary-inverted rounded-t-3xl lg:rounded-t-4xl overflow-hidden">
        <div className="relative w-fit 2xl:px-[160px] xl:px-[80px] md:pr-[32px] pr-[16px] mb-12">
          <div className="flex items-center gap-x-2 pl-4 md:pl-8 pb-2 bg-canvas dark:bg-canvas-inverted">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-lg font-semibold">Our team</h2>
          </div>
          <h2 className="relative text-split w-fit pl-4 pr-[23px] md:px-8 pb-4 rounded-br-2xl xl:rounded-b-3xl bg-canvas dark:bg-canvas-inverted text-4xl md:text-6xl font-semibold">
            <svg
              id="Layer_1"
              className="hidden md:block absolute w-9 h-9 -left-9 -top-9 rotate-90 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
            Meet Our Team
            <svg
              id="Layer_1"
              className="absolute w-9 h-9 -right-9 -top-9 text-canvas dark:text-canvas-inverted fill-current"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              x="0"
              y="0"
              viewBox="0 0 100 100"
            >
              <path d="M51.9 0v1.9c-27.6 0-50 22.4-50 50H0V0h51.9z"></path>
            </svg>
          </h2>
        </div>

        <MemberTicker members={teamMember} />
      </section>

      {/* Testimonials section */}
      <TestimonialSection />

      {/* CTA section */}
      <CTASection />
    </main>
  )
}

export default About
