import FeaturedProjectSection from '@/app/components/ui/section/FeaturedProjectSection'
import TestimonialCard from '@/app/components/ui/card/TestimonialCard'
import Image from 'next/image'

import AnimatedContent from '@/app/components/animation/AnimatedContent'
import FadeContent from '@/app/components/animation/FadeContent'
import WorkDetailHeroSection from '@/app/components/work/WorkDetailHeroSection'
import { client } from '@/sanity/lib/client'
import {
  FEATURED_PROJECTS_QUERY,
  PROJECT_DETAIL_QUERY,
} from '@/sanity/lib/queries'
import { PortableText } from 'next-sanity'
import { TypedObject } from 'sanity'
import { TestimonialType } from '@/app/lib/types/types'
import { Metadata } from 'next'

interface PageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const slug = (await params).slug

  const work = await client.fetch(PROJECT_DETAIL_QUERY, {
    slug: slug,
  })

  return {
    title: `${work?.name} | Stellar Brand Design`,
    description: work?.description,
  }
}

export const revalidate = 60

const WorkDetail = async ({ params }: PageProps) => {
  const { slug } = await params
  const workDetailContent = await client.fetch(PROJECT_DETAIL_QUERY, {
    slug: slug,
  })
  const heroImage = workDetailContent?.images?.[0]
  const clientName = workDetailContent?.client
  const year = workDetailContent?.year
  const workName = workDetailContent?.name
  const tags = workDetailContent?.tags
  const firstImageShowcase = workDetailContent?.images?.slice(1, 4)
  const secondImageShowcase = workDetailContent?.images?.slice(4, 8)
  const thirdImageShowcase = workDetailContent?.images?.slice(8, 11)

  const featuredProjects = await client.fetch(FEATURED_PROJECTS_QUERY)

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-24 xl:pt-32 overflow-hidden">
      <WorkDetailHeroSection
        heroImage={heroImage}
        client={clientName}
        year={year}
        workName={workName}
        tags={tags}
      />

      {/* Project description section */}
      <section className="w-full flex flex-col lg:flex-row justify-between gap-x-16 gap-y-16 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <FadeContent
          duration={1000}
          easing="ease-out"
          initialOpacity={0}
          className="w-full lg:w-[80%] 2xl:w-[90%] text-2xl md:text-3xl"
        >
          <div className="flex items-center gap-x-2 mb-1 md:mb-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-split text-lg font-semibold">{clientName}</h2>
          </div>
          <p>{workDetailContent?.description}</p>
        </FadeContent>

        <FadeContent
          duration={1000}
          easing="ease-out"
          initialOpacity={0}
          className="w-full lg:w-[20%] 2xl:w-[10%] flex flex-row lg:flex-col gap-x-8 gap-y-8"
        >
          <div className="w-1/3 flex flex-col">
            <h2>Client</h2>
            <p className="text-2xl font-semibold">{clientName}</p>
          </div>
          <div className="w-1/3 flex flex-col">
            <h2>Industry</h2>
            <p className="text-2xl font-semibold">
              {workDetailContent?.industry}
            </p>
          </div>
          <div className="w-1/3 flex flex-col">
            <h2>Duration</h2>
            <p className="text-2xl font-semibold">
              {workDetailContent?.durationWeeks} Weeks
            </p>
          </div>
        </FadeContent>
      </section>

      {/* 1st image showcase */}
      {firstImageShowcase && firstImageShowcase.length > 0 && (
        <section className="w-full flex flex-col gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
          <AnimatedContent
            distance={150}
            direction="vertical"
            reverse={false}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="relative w-full h-[340px] md:h-[560px] xl:h-[860px]">
              <Image
                src={firstImageShowcase[0].asset?.url || ''}
                alt={firstImageShowcase[0].alt || ''}
                fill
                className="object-cover object-top rounded-xl lg:rounded-3xl"
              />
            </div>
          </AnimatedContent>

          {firstImageShowcase.length > 1 && (
            <AnimatedContent
              distance={150}
              direction="vertical"
              reverse={false}
              duration={1.2}
              ease={'power3.out'}
            >
              <div className="flex flex-col md:flex-row gap-x-8 gap-y-8">
                <div
                  className={`${firstImageShowcase.length === 3 ? 'w-full md:w-1/2' : 'w-full'} relative h-[340px] xl:h-[860px]`}
                >
                  <Image
                    src={firstImageShowcase[1].asset?.url || ''}
                    alt={firstImageShowcase[1].alt || ''}
                    fill
                    className="object-cover object-top rounded-xl lg:rounded-3xl"
                  />
                </div>
                {firstImageShowcase.length === 3 && (
                  <div className="relative w-full md:w-1/2 h-[340px] xl:h-[860px]">
                    <Image
                      src={firstImageShowcase[2].asset?.url || ''}
                      alt={firstImageShowcase[2].alt || ''}
                      fill
                      className="object-cover object-top rounded-xl lg:rounded-3xl"
                    />
                  </div>
                )}
              </div>
            </AnimatedContent>
          )}
        </section>
      )}

      {/* Problem section */}
      <section className="w-full flex flex-col items-center lg:flex-row gap-x-16 gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="w-full lg:w-1/2">
          <div className="flex items-center gap-x-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-split font-semibold">Problem</h2>
          </div>
          <h2 className="text-split leading-tight text-4xl md:text-5xl font-semibold">
            {workDetailContent?.problem?.title}
          </h2>
        </div>

        <FadeContent
          duration={1000}
          easing="ease-out"
          initialOpacity={0}
          className="w-full lg:w-1/2 *:text-2xl"
        >
          <PortableText
            value={
              workDetailContent?.problem?.description as
                | TypedObject
                | TypedObject[]
            }
          />
        </FadeContent>
      </section>

      {/* 2nd image showcase */}
      {secondImageShowcase && secondImageShowcase.length > 0 && (
        <section className="w-full flex flex-col gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
          <AnimatedContent
            distance={150}
            direction="vertical"
            reverse={false}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="relative w-full h-[340px] md:h-[560px] xl:h-[860px]">
              <Image
                src={secondImageShowcase[0].asset?.url || ''}
                alt={secondImageShowcase[0].alt || ''}
                fill
                className="object-cover object-top rounded-xl lg:rounded-3xl"
              />
            </div>
          </AnimatedContent>

          {secondImageShowcase.length > 1 && (
            <AnimatedContent
              distance={150}
              direction="vertical"
              reverse={false}
              duration={1.2}
              ease={'power3.out'}
            >
              <div className="flex flex-col md:flex-row gap-x-8 gap-y-8">
                <div
                  className={`${secondImageShowcase.length > 2 ? 'w-full md:w-1/2' : 'w-full'} relative h-[340px] xl:h-[860px]`}
                >
                  <Image
                    src={secondImageShowcase[1].asset?.url || ''}
                    alt={secondImageShowcase[1].alt || ''}
                    fill
                    className="object-cover object-top rounded-xl lg:rounded-3xl"
                  />
                </div>
                {secondImageShowcase.length > 2 && (
                  <div className="relative w-full md:w-1/2 h-[340px] xl:h-[860px]">
                    <Image
                      src={secondImageShowcase[2].asset?.url || ''}
                      alt={secondImageShowcase[2].alt || ''}
                      fill
                      className="object-cover object-top rounded-xl lg:rounded-3xl"
                    />
                  </div>
                )}
              </div>
            </AnimatedContent>
          )}

          {secondImageShowcase.length === 4 && (
            <AnimatedContent
              distance={150}
              direction="vertical"
              reverse={false}
              duration={1.2}
              ease={'power3.out'}
            >
              <div className="relative w-full h-[340px] md:h-[560px] xl:h-[860px]">
                <Image
                  src={secondImageShowcase[3].asset?.url || ''}
                  alt={secondImageShowcase[3].alt || ''}
                  fill
                  className="object-cover object-top rounded-xl lg:rounded-3xl"
                />
              </div>
            </AnimatedContent>
          )}
        </section>
      )}

      {/* Solution section */}
      <section className="w-full flex flex-col items-center lg:flex-row gap-x-16 gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="w-full lg:w-1/2">
          <div className="flex items-center gap-x-2">
            <div className="w-3 h-3 relative overflow-hidden">
              <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
            </div>
            <h2 className="text-split font-semibold">Solution</h2>
          </div>
          <h2 className="text-split leading-tight text-4xl md:text-5xl font-semibold">
            {workDetailContent?.solution?.title}
          </h2>
        </div>

        <FadeContent
          duration={1000}
          easing="ease-out"
          initialOpacity={0}
          className="w-full lg:w-1/2 *:text-2xl"
        >
          <PortableText
            value={
              workDetailContent?.solution?.description as
                | TypedObject
                | TypedObject[]
            }
          />
        </FadeContent>
      </section>

      {/* 3rd image showcase */}
      {thirdImageShowcase && thirdImageShowcase.length > 0 && (
        <section className="w-full flex flex-col gap-y-8 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
          <AnimatedContent
            distance={150}
            direction="vertical"
            reverse={false}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="relative w-full h-[320px] md:h-[560px] xl:h-[1200px]">
              <Image
                src={thirdImageShowcase[0].asset?.url || ''}
                alt={thirdImageShowcase[0].alt || ''}
                fill
                className="object-cover object-top rounded-xl lg:rounded-3xl"
              />
            </div>
          </AnimatedContent>

          {thirdImageShowcase.length > 1 && (
            <AnimatedContent
              distance={150}
              direction="vertical"
              reverse={false}
              duration={1.2}
              ease={'power3.out'}
            >
              <div className="flex flex-col md:flex-row gap-x-8 gap-y-8">
                <div
                  className={`${thirdImageShowcase.length === 3 ? 'w-full md:w-1/2' : 'w-full'} relative h-[340px] xl:h-[860px]`}
                >
                  <Image
                    src={thirdImageShowcase[1].asset?.url || ''}
                    alt={thirdImageShowcase[1].alt || ''}
                    fill
                    className="object-cover object-top rounded-xl lg:rounded-3xl"
                  />
                </div>
                {thirdImageShowcase.length === 3 && (
                  <div className="relative w-full md:w-1/2 h-[340px] xl:h-[860px]">
                    <Image
                      src={thirdImageShowcase[2].asset?.url || ''}
                      alt={thirdImageShowcase[2].alt || ''}
                      fill
                      className="object-cover object-top rounded-xl lg:rounded-3xl"
                    />
                  </div>
                )}
              </div>
            </AnimatedContent>
          )}
        </section>
      )}

      {/* Testimonial section */}
      <section className="w-full 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <TestimonialCard
          testimonial={workDetailContent?.testimonial as TestimonialType}
          className="w-full!"
        />
      </section>

      {/* Featured work section */}
      <FeaturedProjectSection featuredProjects={featuredProjects} />
    </main>
  )
}

export default WorkDetail
