import CTASection from '../../../../components/ui/section/CTASection'
import ProjectGrid from '../../../../components/ui/grid/ProjectGrid'
import { client } from '@/sanity/lib/client'
import { PROJECTS_TAGS_FILTER_QUERY, WORK_PAGE_CONTENT_QUERY } from '@/sanity/lib/queries'
import { TypedObject } from 'sanity'
import { FeaturedProjectType } from '@/app/lib/types/types'
import WorkHeroSection from '@/app/components/work/WorkHeroSection'
import { Metadata } from 'next'
import ProjectFilter from '@/app/components/work/ProjectFilter'

export const metadata: Metadata = {
  title: 'Our Work | Stellar Brand Design Projects',
  description:
    'Explore Stellar Brand Design’s portfolio of branding and web design projects. See how we’ve helped startups and businesses create bold identities and powerful online presences.',
}

interface PageProps {
  params: Promise<{ tag: string }>
}

export const revalidate = 60

const WorkFiltered = async ({ params }: PageProps) => {
  const { tag } = await params
  const workContent = await client.fetch(WORK_PAGE_CONTENT_QUERY)
  const heroHeading = workContent?.heroHeading
  const heroDescription = workContent?.heroDescription as
    | TypedObject
    | TypedObject[]

  const projects = (await client.fetch(PROJECTS_TAGS_FILTER_QUERY, {
    tags: decodeURIComponent(tag),
  })) as FeaturedProjectType

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-16 md:pt-24 lg:pt-32">
      {/* Hero section */}
      <WorkHeroSection
        heroHeading={heroHeading}
        heroDescription={heroDescription}
      />

      {/* Projects section */}
      <section className="w-full flex flex-col 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] gap-y-16">
        <ProjectFilter />
        <ProjectGrid primaryColor={true} featuredProjects={projects} />
      </section>

      {/* CTA section */}
      <CTASection />
    </main>
  )
}

export default WorkFiltered
