import type { Metadata } from 'next'
import '../globals.css'
import MenuDesktop from '../components/layout/MenuDesktop'
import Providers from '../Providers'
import MenuMobile from '../components/layout/MenuMobile'
import FooterDesktop from '../components/layout/FooterDesktop'
import AntdProvider from '../AntdProvider'
import FooterMobile from '../components/layout/FooterMobile'
import SmoothScroll from '../components/layout/SmoothScroll'
import { client } from '@/sanity/lib/client'
import {
  FOOTER_CONTENT_QUERY,
  MENU_VISIBILITY_QUERY,
  SOCIALS_CONTACT_QUERY,
} from '@/sanity/lib/queries'
import { PackageProvider } from '../context/PackageContext'
import CursorLoader from '../components/animation/CursorLoader'

export const metadata: Metadata = {
  title: 'Stellar Brand Design | Bold Branding & High-Performance Web Design',
  description:
    'At Stellar Brand Design, we craft distinctive brand experiences through strategic branding and powerful web design. Helping startups and growing businesses stand out, connect, and scale with confidence.',
}

export const revalidate = 60

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const menuVisibility = await client.fetch(MENU_VISIBILITY_QUERY)
  const socialsContact = await client.fetch(SOCIALS_CONTACT_QUERY)
  const footerContent = await client.fetch(FOOTER_CONTENT_QUERY)

  return (
    <Providers>
      <AntdProvider>
        <SmoothScroll>
          <MenuDesktop menuVisibility={menuVisibility} />
          <MenuMobile menuVisibility={menuVisibility} />
          <PackageProvider>{children}</PackageProvider>
          <FooterDesktop
            content={footerContent}
            socialsContact={socialsContact}
            menuVisibility={menuVisibility}
          />
          <FooterMobile
            content={footerContent}
            socialsContact={socialsContact}
            menuVisibility={menuVisibility}
          />
          <CursorLoader />
        </SmoothScroll>
      </AntdProvider>
    </Providers>
  )
}
