import Image from 'next/image'
import Button from '../../components/ui/button/Button'
import { client } from '@/sanity/lib/client'
import { THANK_YOU_PAGE_CONTENT_QUERY } from '@/sanity/lib/queries'
import { PortableText } from 'next-sanity'
import AnimatedContent from '@/app/components/animation/AnimatedContent'
import { TypedObject } from 'sanity'

const Thanks = async () => {
  const pageContent = await client.fetch(THANK_YOU_PAGE_CONTENT_QUERY)

  return (
    <main className="flex flex-col items-center gap-y-16 pt-16 lg:pt-32 overflow-hidden">
      {/* Hero section */}
      <section className="relative mt-8 lg:mt-0">
        <h1 className="relative text-split w-full 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] text-center text-2xl md:text-5xl lg:text-6xl font-semibold">
          <PortableText
            value={pageContent?.heroHeading as TypedObject | TypedObject[]}
          />
        </h1>

        <div className="flex justify-center md:items-end md:gap-x-4 mt-8">
          <AnimatedContent
            distance={300}
            direction="horizontal"
            reverse={true}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="hidden md:block relative w-[300px] lg:w-[400px] xl:w-[500px] 2xl:w-[600px] h-[225px] lg:h-[300px] xl:h-[350px] 2xl:h-[450px]">
              <Image
                src={pageContent?.heroProjects?.[0].images?.asset?.url || ''}
                alt={pageContent?.heroProjects?.[0].images?.alt || ''}
                fill
                className="object-cover rounded-2xl"
              />
            </div>
          </AnimatedContent>

          <AnimatedContent
            distance={300}
            direction="horizontal"
            reverse={true}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="hidden md:flex flex-col gap-y-4">
              <div className="relative w-[150px] lg:w-[200px] xl:w-[250px] 2xl:w-[300px] h-[150px] lg:h-[200px] xl:h-[250px] 2xl:h-[300px]">
                <Image
                  src={pageContent?.heroProjects?.[1].images?.asset?.url || ''}
                  alt={pageContent?.heroProjects?.[1].images?.alt || ''}
                  fill
                  className="object-cover rounded-2xl"
                />
              </div>
              <div className="relative w-[150px] lg:w-[200px] xl:w-[250px] 2xl:w-[300px] h-[115px] lg:h-[140px] xl:h-[180px] 2xl:h-[230px]">
                <Image
                  src={pageContent?.heroProjects?.[2].images?.asset?.url || ''}
                  alt={pageContent?.heroProjects?.[2].images?.alt || ''}
                  fill
                  className="object-cover rounded-2xl"
                />
              </div>
            </div>
          </AnimatedContent>

          <div className="relative mx-[16px] md:mx-0 w-full md:w-[300px] lg:w-[400px] xl:w-[450px] 2xl:w-[600px] h-[400px] md:h-[300px] lg:h-[400px] xl:h-[500px] 2xl:h-[600px]">
            <video
              className="absolute w-full md:w-[300px] lg:w-[400px] xl:w-[500px] 2xl:w-[600px] h-[400px] md:h-[300px] lg:h-[400px] xl:h-[500px] 2xl:h-[600px] left-0 object-cover rounded-2xl"
              playsInline
              autoPlay
              loop
              muted
            >
              <source
                src={pageContent?.heroVideo?.asset?.url || ''}
                type="video/mp4"
              />
              Your browser does not support the video tag.
            </video>
          </div>
          <AnimatedContent
            distance={300}
            direction="horizontal"
            reverse={false}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="hidden md:flex flex-col gap-y-4">
              <div className="relative w-[150px] lg:w-[200px] xl:w-[250px] 2xl:w-[300px] h-[150px] lg:h-[200px] xl:h-[250px] 2xl:h-[300px]">
                <Image
                  src={pageContent?.heroProjects?.[3].images?.asset?.url || ''}
                  alt={pageContent?.heroProjects?.[3].images?.alt || ''}
                  fill
                  className="object-cover rounded-2xl"
                />
              </div>
              <div className="relative w-[150px] lg:w-[200px] xl:w-[250px] 2xl:w-[300px] h-[115px] lg:h-[140px] xl:h-[180px] 2xl:h-[230px]">
                <Image
                  src={pageContent?.heroProjects?.[4].images?.asset?.url || ''}
                  alt={pageContent?.heroProjects?.[4].images?.alt || ''}
                  fill
                  className="object-cover rounded-2xl"
                />
              </div>
            </div>
          </AnimatedContent>

          <AnimatedContent
            distance={300}
            direction="horizontal"
            reverse={false}
            duration={1.2}
            ease={'power3.out'}
          >
            <div className="hidden md:block relative w-[300px] lg:w-[400px] xl:w-[500px] 2xl:w-[600px] h-[225px] lg:h-[300px] xl:h-[350px] 2xl:h-[450px]">
              <Image
                src={pageContent?.heroProjects?.[5].images?.asset?.url || ''}
                alt={pageContent?.heroProjects?.[5].images?.alt || ''}
                fill
                className="object-cover rounded-2xl"
              />
            </div>
          </AnimatedContent>
        </div>
      </section>

      <section className="w-full flex flex-col items-center gap-y-4 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px] *:text-center *:text-2xl">
        <PortableText
          value={pageContent?.description as TypedObject | TypedObject[]}
        />
        <Button link="/" primary={true} className="text-lg">
          Go home
        </Button>
      </section>
    </main>
  )
}

export default Thanks
