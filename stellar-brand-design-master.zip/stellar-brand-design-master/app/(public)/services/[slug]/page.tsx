import CTASection from '@/app/components/ui/section/CTASection'
import FeaturedProjectSection from '@/app/components/ui/section/FeaturedProjectSection'
import TestimonialSection from '@/app/components/ui/section/TestimonialSection'
import Image from 'next/image'
import FadeContent from '@/app/components/animation/FadeContent'
import ServiceDetailHeroSection from '@/app/components/services/ServiceDetailHeroSection'
import { client } from '@/sanity/lib/client'
import {
  FEATURED_PROJECTS_QUERY,
  SERVICE_DETAIL_QUERY,
} from '@/sanity/lib/queries'
import { TypedObject } from 'sanity'
import { PortableText } from 'next-sanity'
import BlockText from '@/app/components/ui/text/BlockText'
import { Metadata } from 'next'
import { sanityBlockToPlainText } from '@/app/lib/utils/helpers/sanityBlockPlainText'

interface PageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const slug = (await params).slug

  const service = await client.fetch(SERVICE_DETAIL_QUERY, {
    slug: slug,
  })

  return {
    title: `${service?.name} | Stellar Brand Design`,
    description: sanityBlockToPlainText(service?.detailedDescription?.body),
  }
}

export const revalidate = 60

const ServiceDetail = async ({ params }: PageProps) => {
  const { slug } = await params
  const serviceDetailContent = await client.fetch(SERVICE_DETAIL_QUERY, {
    slug: slug,
  })

  const serviceName = serviceDetailContent?.name
  const heroHeading = serviceDetailContent?.heroTitle as
    | TypedObject
    | TypedObject[]
  const heroImage = serviceDetailContent?.mainImage

  const featuredProjects = await client.fetch(FEATURED_PROJECTS_QUERY)

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-16 md:pt-24 lg:pt-32 overflow-x-hidden">
      {/* Hero section */}
      <ServiceDetailHeroSection
        serviceName={serviceName}
        heroHeading={heroHeading}
        heroImage={heroImage}
      />

      {/* Service features section */}
      <section className="w-full flex flex-col gap-y-16 lg:gap-y-32 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        {serviceDetailContent?.mainFeatures &&
          serviceDetailContent?.mainFeatures.map((feature, index) => (
            <div
              key={index}
              className={`w-full flex flex-col items-center ${
                index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
              } lg:justify-between gap-x-16 gap-y-8`}
            >
              <FadeContent
                duration={1000}
                easing="ease-out"
                initialOpacity={0}
                className="relative w-full lg:w-1/2 h-[300px] md:h-[520px] lg:h-[364px] 2xl:h-[560px]"
              >
                <Image
                  src={feature.image?.asset?.url || ''}
                  alt={feature.image?.alt || ''}
                  fill
                  className="object-cover rounded-xl lg:rounded-3xl"
                />
              </FadeContent>

              <div className="w-full lg:w-1/2 flex flex-col gap-y-4 lg:gap-y-8">
                <h2 className="text-split text-3xl md:text-5xl font-semibold">
                  {feature.title}
                </h2>
                <p className="text-split text-xl">{feature.shortDescription}</p>
              </div>
            </div>
          ))}
      </section>

      {/* Description section */}
      <section className="w-full flex flex-col gap-y-16 xl:gap-y-32 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
        <div className="w-full flex flex-col lg:flex-row justify-between gap-x-32 gap-y-8">
          <div className="w-full lg:w-1/2 flex flex-col">
            <div className="flex items-center gap-x-2">
              <div className="w-3 h-3 relative overflow-hidden">
                <div className="absolute inset-0 bg-brand-primary [clip-path:polygon(100%_0%,100%_100%,0%_0%)]"></div>
              </div>
              <h2 className="text-split ">{serviceDetailContent?.name}</h2>
            </div>
            <h2 className="text-split text-5xl lg:text-4xl 2xl:text-5xl font-semibold leading-tight">
              <PortableText
                value={
                  serviceDetailContent?.detailedDescription?.title as
                    | TypedObject
                    | TypedObject[]
                }
                components={BlockText}
              />
            </h2>
          </div>

          <FadeContent
            duration={1000}
            easing="ease-out"
            initialOpacity={0}
            className="w-full lg:w-2/3 text-xl"
          >
            <PortableText
              value={
                serviceDetailContent?.detailedDescription?.body as
                  | TypedObject
                  | TypedObject[]
              }
            />
          </FadeContent>
        </div>

        <div className="w-full grid md:grid-cols-2 lg:flex gap-x-16 gap-y-16">
          {serviceDetailContent?.deliverables &&
            serviceDetailContent?.deliverables.map((deliverable) => (
              <div
                key={deliverable._key}
                className="w-full lg:w-1/4 flex flex-col gap-y-8"
              >
                <div className="relative w-[32px] h-[32px]">
                  <Image
                    src={deliverable.icon?.asset?.url || ''}
                    alt={deliverable.icon?.alt || ''}
                    fill
                    className="object-cover"
                  />
                </div>

                <h2 className="text-split text-2xl font-semibold">
                  {deliverable.title}
                </h2>
                <p className="text-split text-xl">
                  {deliverable.shortDescription}
                </p>
              </div>
            ))}
        </div>
      </section>

      {/* Featured work section */}
      <FeaturedProjectSection featuredProjects={featuredProjects} />

      {/* Testimonials section */}
      <TestimonialSection />

      {/* CTA section */}
      <CTASection />
    </main>
  )
}

export default ServiceDetail
