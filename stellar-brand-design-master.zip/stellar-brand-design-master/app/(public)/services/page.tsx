import Link from 'next/link'
import ProjectTicker from '../../components/services/ProjectTicker'
import TestimonialSection from '../../components/ui/section/TestimonialSection'
import CTASection from '../../components/ui/section/CTASection'
import FadeContent from '../../components/animation/FadeContent'
import ServicesHeroSection from '@/app/components/services/ServicesHeroSection'
import { client } from '@/sanity/lib/client'
import {
  SERVICES_PAGE_CONTENT_QUERY,
  SERVICE_PAGE_SERVICES_QUERY,
} from '@/sanity/lib/queries'
import { TypedObject } from 'sanity'
import { FeaturedProjectType } from '@/app/lib/types/types'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title:
    'Web Design & Development, SEO & Digital Marketing Services | Stellar Brand Design',
  description:
    'Discover our services in branding, strategy, and high-performance web design & development. From brand identity to custom websites, we help businesses stand out and grow with confidence.',
}

const arrowIcon = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    className="fill-font-primary dark:fill-font-primary-inverted"
  >
    <path d="m256-240-56-56 384-384H240v-80h480v480h-80v-344L256-240Z" />
  </svg>
)

export const revalidate = 60

const Services = async () => {
  const servicesContent = await client.fetch(SERVICES_PAGE_CONTENT_QUERY)
  const heroHeading = servicesContent?.heroHeading as
    | TypedObject
    | TypedObject[]
  const heroImage = servicesContent?.heroImage

  const serviceCategoryContent = await client.fetch(SERVICE_PAGE_SERVICES_QUERY)

  return (
    <main className="flex flex-col items-center gap-y-16 xl:gap-y-32 pt-16 md:pt-24 lg:pt-32">
      {/* Hero section */}
      <ServicesHeroSection heroHeading={heroHeading} heroImage={heroImage} />

      {/* Services section */}
      <section className="flex flex-col gap-y-24 xl:gap-y-32">
        {serviceCategoryContent.map((service, index) => (
          <div
            key={service._id}
            className="flex flex-col justify-center items-center gap-y-8"
          >
            <div className="w-screen flex flex-col lg:flex-row justify-between gap-x-16 2xl:px-[160px] xl:px-[80px] md:px-[32px] px-[16px]">
              <div className="w-full lg:w-1/2 flex flex-col gap-y-4">
                <h2 className="text-split text-3xl md:text-5xl xl:text-6xl font-semibold">
                  {service.name}
                </h2>
                <FadeContent
                  duration={1000}
                  easing="ease-out"
                  initialOpacity={0}
                >
                  <p className="text-xl xl:text-2xl">
                    {service.shortDescription}
                  </p>
                </FadeContent>
              </div>

              <div className="relative w-full lg:w-1/2 flex flex-col gap-y-2">
                {service.services.map((subService, index) => (
                  <Link
                    href={`/services/${subService.slug?.current}`}
                    key={index}
                    className="relative text-split flex justify-between items-center gap-x-4 mt-4 text-2xl transition-all before:w-0 before:h-[1px] before:absolute before:-bottom-2 
                    before:right-0 before:transition-all before:duration-500 hover:before:w-full hover:before:left-0 hover:before:bg-font-secondary-1"
                  >
                    <div className="flex items-end gap-x-6">
                      <span className="text-xl text-font-secondary-1 font-light shrink-0">
                        0{index + 1}
                      </span>{' '}
                      <span className="leading-normal">{subService.name}</span>
                    </div>

                    {arrowIcon}
                  </Link>
                ))}
              </div>
            </div>

            {service.featuredProjects &&
            service.featuredProjects.length >= 5 ? (
              <ProjectTicker
                projects={service.featuredProjects as FeaturedProjectType}
                index={index}
              />
            ) : (
              <></>
            )}
          </div>
        ))}
      </section>

      {/* Testimonials section */}
      <TestimonialSection />

      {/* CTA section */}
      <CTASection />
    </main>
  )
}

export default Services
