import {
  SanityImageCrop,
  SanityImageHotspot,
  Slug,
  internalGroqTypeReferenceTo,
} from '@/sanity/types'

export type TestimonialArrayType =
  | {
      _id: string
      clientName: string | null
      company: string | null
      position: string | null
      hasVideo: boolean | null
      testimonyVideo: {
        asset: {
          url: string | null
        } | null
      } | null
      testimonyBody?: Array<{
        children?: Array<{
          marks?: Array<string>
          text?: string
          _type: 'span'
          _key: string
        }>
        style?: 'normal'
        listItem?: never
        markDefs?: null
        level?: number
        _type: 'block'
        _key: string
      }>
    }[]
  | null
  | undefined

export type TestimonialType = {
  _id: string
  clientName: string | null
  company: string | null
  position: string | null
  hasVideo: boolean | null
  testimonyVideo: {
    asset: {
      url: string | null
    } | null
  } | null
  testimonyBody?: Array<{
    children?: Array<{
      marks?: Array<string>
      text?: string
      _type: 'span'
      _key: string
    }>
    style?: 'normal'
    listItem?: never
    markDefs?: null
    level?: number
    _type: 'block'
    _key: string
  }>
}

export type NewsletterFieldType = {
  email: string
}

type TeamMemberPhoto = {
  _key: string
  _type: 'image'
  asset: {
    url: string
  }
  alt: string | null
}

export type TeamMemberType = {
  name: string
  position: string
  photo: TeamMemberPhoto | null
}

export type TeamMembersQueryResult = TeamMemberType[]

export type HorizontalLoopConfigType = {
  repeat?: number
  paused?: boolean
  speed?: number
  snap?: number | number[] | gsap.utils.SnapNumberConfig
  paddingRight: string
  reversed?: boolean
}

export type PackageArrayType = Array<{
  _id: string
  name: string | null
  description: string | null
  isSpecialOffers: boolean | null
  recommended: boolean | null
  price: number | null
  category: {
    _id: string
    name: string | null
  } | null
  features: Array<{
    _key: string
    category: string | null
    features: Array<{
      _key: string
      name: string | null
      included: boolean | null
      note: string | null
    }> | null
  }> | null
}>

export type PackageType = {
  _id: string
  name: string | null
  description: string | null
  isSpecialOffers: boolean | null
  recommended: boolean | null
  price: number | null
  category: {
    _id: string
    name: string | null
  } | null
  features: Array<{
    _key: string
    category: string | null
    features: Array<{
      _key: string
      name: string | null
      included: boolean | null
      note: string | null
    }> | null
  }> | null
}

export type PlanNameType = { _id: string; name: string | null }[]

export type BlogArrayType = Array<{
  _id: string
  title: string | null
  slug: Slug | null
  publishedAt: string | null
  tags: Array<string> | null
  mainImage: {
    asset: {
      url: string | null
    } | null
    alt: string | null
  } | null
}>

export type BlogType = {
  _id: string
  title: string | null
  slug: Slug | null
  publishedAt: string | null
  tags: Array<string> | null
  mainImage: {
    asset: {
      url: string | null
    } | null
    alt: string | null
  } | null
}

export type BlogDetailType = {
  _id: string
  title: string | null
  slug: Slug | null
  publishedAt: string | null
  tags: Array<string> | null
  body: Array<
    | {
        children?: Array<{
          marks?: Array<string>
          text?: string
          _type: 'span'
          _key: string
        }>
        style?: 'blockquote' | 'h1' | 'h2' | 'h3' | 'h4' | 'normal'
        listItem?: 'bullet' | 'number'
        markDefs?: Array<{
          href?: string
          _type: 'link'
          _key: string
        }>
        level?: number
        _type: 'block'
        _key: string
      }
    | {
        asset?: {
          _ref: string
          _type: 'reference'
          _weak?: boolean
          [internalGroqTypeReferenceTo]?: 'sanity.imageAsset'
        }
        media?: unknown
        hotspot?: SanityImageHotspot
        crop?: SanityImageCrop
        alt?: string
        caption?: string
        _type: 'image'
        _key: string
      }
  > | null
  mainImage: {
    asset: {
      url: string | null
    } | null
    alt: string | null
  } | null
} | null

export type ContactFieldType = {
  name: string
  company: string
  email: string
  timeline: string
  budget: string
  offer: string
  projectDescription: string
}

export type ServiceCategoriesType = Array<{
  _id: string
  name: string | null
}>

export type FeaturedServicesType = Array<{
  name: string | null
  slug: Slug | null
  heroTitle: Array<{
    children?: Array<{
      marks?: Array<string>
      text?: string
      _type: 'span'
      _key: string
    }>
    style?: 'normal'
    listItem?: never
    markDefs?: null
    level?: number
    _type: 'block'
    _key: string
  }> | null
  stats: Array<string> | null
  mainImage: {
    asset: {
      url: string | null
    } | null
    alt: string | null
  } | null
}> | null

export type ProjectType = {
  _id: string
  name: string | null
  slug: Slug | null
  images: {
    _key: string
    _type: 'image'
    asset: {
      url: string | null
    } | null
    alt: string | null
  } | null
  overlayImage?: {
    _key: null
    _type: 'image'
    asset: {
      url: string | null
    } | null
    alt: string | null
  } | null
  client: string | null
  year: string | null
  tags: string[] | null
}

export type FeaturedProjectType =
  | {
      _id: string
      name: string | null
      slug: Slug | null
      client: string | null
      year: string | null
      tags: string[] | null
      images: {
        _key: string
        _type: 'image'
        asset: {
          url: string | null
        } | null
        alt: string | null
      } | null
    }[]
  | null
  | undefined

export type FooterContentType = {
  sliderText: Array<{
    children?: Array<{
      marks?: Array<string>
      text?: string
      _type: 'span'
      _key: string
    }>
    style?: 'normal'
    listItem?: never
    markDefs?: null
    level?: number
    _type: 'block'
    _key: string
  }> | null
  ctaText: Array<{
    children?: Array<{
      marks?: Array<string>
      text?: string
      _type: 'span'
      _key: string
    }>
    style?: 'normal'
    listItem?: never
    markDefs?: null
    level?: number
    _type: 'block'
    _key: string
  }> | null
} | null

export type SocialsContactType = {
  email: string | null
  address: string | null
  phoneNumber: string | null
  linkedin: string | null
  instagram: string | null
  facebook: string | null
  twitter: string | null
} | null

export type MenuVisibilityType = {
  isShowPackageMenu: boolean | null
} | null
