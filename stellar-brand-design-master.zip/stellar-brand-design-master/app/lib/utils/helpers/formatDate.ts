const formatDate = (dateString: string | null | undefined) => {
  // If the date string is null or undefined, return an empty string.
  if (!dateString) {
    return ''
  }

  // Split the ISO date string at the 'T' to get the date part ("YYYY-MM-DD").
  const datePart = dateString.split('T')[0]

  // Split the date part at the hyphen to get the year, month, and day.
  const [year, month, day] = datePart.split('-')

  // Reorder the parts and join them with hyphens to get "DD-MM-YYYY".
  return `${day}-${month}-${year}`
}

export default formatDate
