interface Span {
  _key: string
  _type: 'span'
  text?: string
  marks?: string[]
}

/**
 * Interface for a 'link' type found in markDefs.
 */
interface LinkMarkDef {
  _key: string
  _type: 'link'
  href?: string
}

/**
 * Interface for the text-based 'block' type.
 */
interface Block {
  _key: string
  _type: 'block'
  children?: Span[]
  style?: 'blockquote' | 'h1' | 'h2' | 'h3' | 'h4' | 'normal'
  listItem?: 'bullet' | 'number'
  markDefs?: LinkMarkDef[] | null
  level?: number
}

/**
 * Interface for the 'image' type.
 */
interface Image {
  _key: string
  _type: 'image'
  asset?: { _ref: string; _type: 'reference' }
  alt?: string
  caption?: string
}

// Define a union type for all possible portable text content.
type PortableTextContent = Block | Image

export const sanityBlockToPlainText = (
  blocks: PortableTextContent[] | null = []
): string => {
  if (!Array.isArray(blocks) || blocks.length === 0) {
    return ''
  }

  // Iterate over each item and extract text based on its type.
  return (
    blocks
      .map((block) => {
        switch (block._type) {
          case 'block':
            // For text blocks, extract and join the child spans.
            return block.children?.map((span) => span.text).join('')
          case 'image':
            // For images, prioritize the caption, then the alt text.
            const imageBlock = block as Image
            return imageBlock.caption || imageBlock.alt || ''
          default:
            // Ignore any other unknown block types.
            return ''
        }
      })
      // Filter out any empty strings from unsupported blocks.
      .filter(Boolean)
      // Join all the pieces of text together with a space.
      .join(' ')
  )
}
