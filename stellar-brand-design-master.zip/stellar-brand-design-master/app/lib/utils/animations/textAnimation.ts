import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'

export const initTextAnimations = () => {
  if (typeof window === 'undefined') return
  // Register SplitText plugin
  gsap.registerPlugin(SplitText, ScrollTrigger)
  // Find all elements with text-split class
  const textElements = document.querySelectorAll('.text-split')

  textElements.forEach((element) => {
    // Split text into chars and words
    const split = new SplitText(element, {
      type: 'words',
      wordsClass: 'word',
      mask: 'words',
    })

    // Animate the chars
    gsap.from(split.words, {
      opacity: 0,
      y: 40,
      stagger: 0.04,
      duration: 0.6,
      scrollTrigger: {
        trigger: element,
        start: 'top bottom-=100',
        once: true,
      },
    })

    // Revert splitting on cleanup to avoid DOM issues
    return () => split.revert()
  })
}
