import SubscriberWelcomeEmail from '@/app/components/contact/SubscriberWelcomeEmail'
import { render } from '@react-email/components'
import { NextResponse } from 'next/server'
import nodemailer from 'nodemailer'

export async function POST(req: Request) {
  const { email, name } = await req.json()

  if (!email) {
    return NextResponse.json({ error: 'Email is required' }, { status: 400 })
  }

  const MAILCHIMP_API_KEY = process.env.MAILCHIMP_API_KEY
  const MAILCHIMP_API_SERVER = process.env.MAILCHIMP_API_SERVER
  const MAILCHIMP_AUDIENCE_ID = process.env.MAILCHIMP_AUDIENCE_ID

  const url = `https://${MAILCHIMP_API_SERVER}.api.mailchimp.com/3.0/lists/${MAILCHIMP_AUDIENCE_ID}/members`

  try {
    // 1. Add subscriber to Mailchimp
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${Buffer.from(
          `anystring:${MAILCHIMP_API_KEY}`
        ).toString('base64')}`,
      },
      body: JSON.stringify({
        email_address: email,
        status: 'subscribed',
        merge_fields: {
          FNAME: name || '',
        },
      }),
    })

    const data = await response.json()

    if (!response.ok) {
      const errorMessage = data.title || 'Something went wrong'
      return NextResponse.json(
        { error: errorMessage },
        { status: response.status }
      )
    }

    // 2. Send welcome email using Nodemailer
    const welcomeEmail = await render(<SubscriberWelcomeEmail />)

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    await transporter.sendMail({
      from: `"Stellar Brand Design" <${process.env.SMTP_USER}>`,
      to: email,
      subject: 'Welcome to Stellar Brand Design Newsletter!',
      html: welcomeEmail,
    })

    return NextResponse.json(
      {
        message:
          'Success! You have been subscribed and a welcome email was sent.',
      },
      { status: 200 }
    )
  } catch (error) {
    console.error(error)
    return NextResponse.json(
      { error: 'Failed to subscribe or send email. Please try again later.' },
      { status: 500 }
    )
  }
}
