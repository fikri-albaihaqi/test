import { render } from '@react-email/components'
import { NextResponse } from 'next/server'
import nodemailer from 'nodemailer'
import ProjectEmail from '@/app/components/contact/ProjectEmail'
import ProjectReplyEmail from '@/app/components/contact/ProjectReplyEmail'

export async function POST(req: Request) {
  try {
    const {
      name,
      companyName,
      email,
      timeline,
      selectedOffers,
      totalPrice,
      projectBrief,
    } = await req.json()

    // Create transporter
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    const projectEmail = await render(
      <ProjectEmail
        name={name}
        companyName={companyName}
        email={email}
        timeline={timeline}
        selectedOffers={selectedOffers}
        totalPrice={totalPrice}
        projectBrief={projectBrief}
      />
    )

    const projectReplyEmail = await render(
      <ProjectReplyEmail
        name={name}
        companyName={companyName}
        timeline={timeline}
        selectedOffers={selectedOffers}
        totalPrice={totalPrice}
        projectBrief={projectBrief}
      />
    )

    // 1. Send email to YOU
    await transporter.sendMail({
      from: `"Project Inquiry" <${process.env.SMTP_USER}>`,
      to: process.env.SMTP_USER,
      subject: `New Project Inquiry from ${name}`,
      html: projectEmail,
    })

    // 2. Send auto-reply to CLIENT
    await transporter.sendMail({
      from: `"Fikri Albaihaqi" <${process.env.SMTP_USER}>`,
      to: email,
      subject: 'Thanks for reaching out!',
      html: projectReplyEmail,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to send email' }, { status: 500 })
  }
}
