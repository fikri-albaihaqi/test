import { render } from '@react-email/components'
import { NextResponse } from 'next/server'
import nodemailer from 'nodemailer'
import ContactEmail from '@/app/components/contact/ContactEmail'
import ContactReplyEmail from '@/app/components/contact/ContactReplyEmail'

export async function POST(req: Request) {
  try {
    const { name, companyName, email, timeline, projectBrief } =
      await req.json()

    // Create transporter
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    const contactEmail = await render(
      <ContactEmail
        name={name}
        companyName={companyName}
        email={email}
        timeline={timeline}
        projectDescription={projectBrief}
      />
    )

    // 1. Send email to YOU
    await transporter.sendMail({
      from: `"Contact Form Submission" <${process.env.SMTP_USER}>`,
      to: process.env.SMTP_USER,
      subject: `New Contact Form Submission from ${name}`,
      html: contactEmail,
    })

    const contactReplyEmail = await render(<ContactReplyEmail name={name} />)

    // 2. Send auto-reply to CLIENT
    await transporter.sendMail({
      from: `"Stellar Brand Design" <${process.env.SMTP_USER}>`,
      to: email,
      subject: 'Thanks for reaching out!',
      html: contactReplyEmail,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to send email' }, { status: 500 })
  }
}
