import { defineQuery } from 'next-sanity'

export const HOME_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "homePage"][0]{
  heroHeadingLine1,
  heroHeadingLine2,
  desktopHeroVideo {
    asset -> {url}
  }, 
  mobileHeroVideo {
    asset -> {url}
  },
  aboutSectionParagraph,
  aboutSectionProjects[]->{
    _id,
    client,
    images[0]{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }
  },
  serviceSectionText,
  featuredServices[]->{
    name,
    slug,
    heroTitle,
    stats,
    mainImage {
      asset->{url},
      alt
    }
  },
  projectSectionText,
  featuredProject[]->{
    _id,
    name,
    slug,
    images[0]{
      _key,
      _type,
      asset->{
        url
      },
      alt
    },
    overlayImage{
      _key,
      _type,
      asset->{
        url
      },
      alt
    },
    client,
    year,
    tags,
  },
}`)

export const CLIENT_LOGO_QUERY = defineQuery(`
  *[_type == "clientLogo"][0]{
    logo[] {
      alt,
      asset -> {url}
    }
  }
`)

export const TESTIMONIALS_SECTION_QUERY = defineQuery(`
  *[_type == "testimonialSection"][0]{
  testimonialHeading,
  featuredTestimonials[]->{
    _id,
    clientName,
    company,
    position,
    hasVideo,
    testimonyVideo {
      asset->{url}
    },
    testimonyBody
  }
}`)

export const CTA_SECTION_QUERY = defineQuery(`
  *[_type == "ctaSection"][0]{
  ctaHeading,
  featuredProject[]->{
    _id,
    images[0]{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }
  },
}`)

export const ABOUT_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "aboutPage"][0]{
  heroText,
  heroProjects[]->{
    _id,
    images[0]{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }
  },
  companyStats,
  heroVideo {
    asset -> {url}
  },
  mobileHeroVideo {
    asset -> {url}
  },
  ourClientSectionHeading,
  expertiseSectionHeading
}`)

export const TEAM_MEMBER_QUERY = defineQuery(`
  *[_type == "teamMember"]{
  name,
  position,
  photo{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }}
`)

export const SERVICES_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "servicesPage"][0]{
  heroHeading,
  heroImage{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }
  }
`)

export const SERVICE_PAGE_SERVICES_QUERY = defineQuery(`
  *[_type == "serviceCategory"]{
    _id,
    name,
    slug,
    shortDescription,
    "services": *[_type == "service" && references(^._id)]{
      _id,
      name,
      slug,
    },
    featuredProjects[]->{
      _id,
      name,
      slug,
      images[0]{
        _key,
        _type,
        asset->{
          url
        },
        alt
      }
    },
  }  
`)

export const ABOUT_PAGE_SERVICES_QUERY = defineQuery(`
  *[_type == "serviceCategory"]{
    _id,
    name,
    slug,
    shortDescription,
    "services": *[_type == "service" && references(^._id)]{
      _id,
      name,
      slug,
      mainImage {
        asset->{url},
        alt
      },
    },
  }  
`)

export const SERVICE_CATEGORY_QUERY = defineQuery(
  `*[_type == "serviceCategory"]{
    _id,
    name,
  }`
)

export const SERVICE_DETAIL_QUERY = defineQuery(`
  *[_type == "service" && slug.current == $slug][0]{
    _id,
    name,
    mainImage {
      asset->{url},
      alt
    },
    heroTitle,
    mainFeatures[]{
      _key,
      title,
      shortDescription,
      image {
        asset->{url},
        alt
      }
    },
    detailedDescription {
      title,
      body
    },
    deliverables[]{
      _key,
      title,
      shortDescription,
      icon {
        asset->{url},
        alt
      }
    },
  }
`)

export const WORK_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "workPage"][0]{
  heroHeading,
  heroDescription
  }  
`)

export const FEATURED_PROJECTS_QUERY = defineQuery(`
  *[_type == "project"][0...9]{
    _id,
    name,
    slug,
    client,
    year,
    tags,
    images[0]{
      _key,
      _type,
      asset->{url},
      alt
    },
  }
`)

export const PROJECTS_QUERY = defineQuery(`
  *[_type == "project"]{
    _id,
    name,
    slug,
    images[0]{
      _key,
      _type,
      asset->{url},
      alt
    },
    overlayImage{
      _key,
      _type,
      asset->{url},
      alt
    },
    client,
    year,
    tags,
  }
`)

export const PROJECTS_TAGS_FILTER_QUERY = defineQuery(`
  *[
    _type == "project" &&
    count(tags[lower(@) == lower($tags)]) > 0
  ]{
    _id,
    name,
    slug,
    images[0]{
      _key,
      _type,
      asset->{url},
      alt
    },
    overlayImage{
      _key,
      _type,
      asset->{url},
      alt
    },
    client,
    year,
    tags,
  }
`)

export const PROJECT_TAGS_QUERY = defineQuery(
  `array::unique(*[_type == "project" && defined(tags)].tags[])`
)

export const PROJECT_DETAIL_QUERY = defineQuery(`
  *[_type == "project" && slug.current == $slug][0]{
    _id,
    name,
    client,
    year,
    description,
    industry,
    durationWeeks,
    problem{
      title,
      description
    },
    solution{
      title,
      description
    },
    tags,
    images[]{
      _key,
      _type,
      asset->{url},
      alt
    },
    testimonial->{
      _id,
      clientName,
      company,
      position,
      hasVideo,
      testimonyVideo {
        asset->{url}
      },
      testimonyBody
    }
  }
`)

export const PRICING_PAGE_CONTENT_QUERY = defineQuery(
  `*[_type == "pricingPage"][0]{ heroHeading, description }`
)

export const PACKAGES_QUERY = defineQuery(
  `*[_type == "pricingPackage"]{
    _id,
    name,
    description,
    isSpecialOffers,
    recommended,
    price,
    category->{
      _id,
      name
    },
    features[]{
      _key,
      category,
      features[]{
        _key,
        name,
        included,
        note
      }
    }
  }`
)

export const PACKAGE_CATEGORY_FILTER_QUERY = defineQuery(`
  *[
    _type == "pricingPackage" && category->name == $category
  ]{
    _id,
    name,
    description,
    isSpecialOffers,
    recommended,
    price,
    category->{
      _id,
      name
    },
    features[]{
      _key,
      category,
      features[]{
        _key,
        name,
        included,
        note
      }
    }
  }
`)

export const BLOG_PAGE_CONTENT_QUERY = defineQuery(
  `*[_type == "blogPage"][0]{heroHeading}`
)

export const BLOG_POSTS_QUERY = defineQuery(`
  *[_type == "blogPost"] | order(publishedAt desc) {
    _id,
    title,
    slug,
    publishedAt,
    tags,
    mainImage {
      asset -> {
        url
      },
      alt
    }
  }
`)

export const RECOMMENDED_BLOG_POSTS_QUERY = defineQuery(`
  *[_type == "blogPost"][0...10] | order(publishedAt desc) {
    _id,
    title,
    slug,
    publishedAt,
    tags,
    mainImage {
      asset -> {
        url
      },
      alt
    }
  }
`)

export const BLOG_TAGS_QUERY = defineQuery(
  `array::unique(*[_type == "blogPost" && defined(tags)].tags[])`
)

export const BLOG_POSTS_TAGS_FILTER_QUERY = defineQuery(`
  *[
    _type == "blogPost" &&
    count(tags[lower(@) == lower($tags)]) > 0
  ] | order(publishedAt desc) {
    _id,
    title,
    slug,
    publishedAt,
    tags,
    mainImage {
      asset -> {
        url
      },
      alt
    },
  }
`)

export const BLOG_POST_DETAIL_QUERY = defineQuery(`
  *[_type == "blogPost" && slug.current == $slug][0]{
    _id,
    title,
    slug,
    publishedAt,
    tags,
    audioFile {
      asset -> {
        url
      },
    },
    body,
    mainImage {
      asset -> {
        url
      },
      alt
    }
  }
`)

export const CONTACT_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "contactPage"][0]{
    video {
      asset -> {url}
    },
    welcomeText {
      heading,
      subHeading
    },
    contactText {
      heading,
      subHeading
    },
    projectDetailText {
      heading,
      subHeading
    },
}`)

export const TERMS_OF_SERVICE_PAGE_CONTENT_QUERY = defineQuery(
  `*[_type == "termsOfServicePage"][0]{body}`
)

export const PRIVACY_POLICY_PAGE_CONTENT_QUERY = defineQuery(
  `*[_type == "privacyPolicyPage"][0]{body}`
)

export const FOOTER_CONTENT_QUERY = defineQuery(
  `*[_type == "footer"][0]{sliderText, ctaText}`
)

export const SOCIALS_CONTACT_QUERY = defineQuery(
  `*[_type == "socialsContact"][0]{email, address, phoneNumber, linkedin, instagram, facebook, twitter}`
)

export const THANK_YOU_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "thankYouPage"][0]{
  heroHeading,
  heroVideo {
    asset -> {url}
  },
  heroProjects[]->{
    _id,
    images[0]{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }
  },
  description
}`)

export const NOT_FOUND_PAGE_CONTENT_QUERY = defineQuery(`
  *[_type == "notFoundPage"][0]{
  heroHeading,
  heroVideo {
    asset -> {url}
  },
  heroProjects[]->{
    _id,
    images[0]{
      _key,
      _type,
      asset->{
        url
      },
      alt
    }
  },
  description
}`)

export const MENU_VISIBILITY_QUERY = defineQuery(
  `*[_type == "menu"][0]{isShowPackageMenu}`
)
