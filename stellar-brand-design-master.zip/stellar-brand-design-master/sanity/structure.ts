import type { StructureResolver } from 'sanity/structure'
import {
  DashboardIcon,
  CaseIcon,
  BlockElementIcon,
  ProjectsIcon,
  FeedbackIcon,
  PackageIcon,
  UsersIcon,
  BookIcon,
  LinkIcon,
  AsteriskIcon,
  MenuIcon,
} from '@sanity/icons'

// https://www.sanity.io/docs/structure-builder-cheat-sheet
export const structure: StructureResolver = (S) =>
  S.list()
    .title('Content')
    .items([
      S.listItem()
        .title('Pages')
        .icon(DashboardIcon)
        .child(
          S.list()
            .title('Page Content')
            .items([
              S.listItem()
                .title('Home Page')
                .schemaType('homePage')
                .child(S.documentTypeList('homePage')),
              S.listItem()
                .title('About Page')
                .schemaType('aboutPage')
                .child(S.documentTypeList('aboutPage')),
              S.listItem()
                .title('Services Page')
                .schemaType('servicesPage')
                .child(S.documentTypeList('servicesPage')),
              S.listItem()
                .title('Work Page')
                .schemaType('workPage')
                .child(S.documentTypeList('workPage')),
              S.listItem()
                .title('Pricing Page')
                .schemaType('pricingPage')
                .child(S.documentTypeList('pricingPage')),
              S.listItem()
                .title('Blog Page')
                .schemaType('blogPage')
                .child(S.documentTypeList('blogPage')),
              S.listItem()
                .title('Contact/Finish Order Page')
                .schemaType('contactPage')
                .child(S.documentTypeList('contactPage')),
              S.listItem()
                .title('Terms of Service Page')
                .schemaType('termsOfServicePage')
                .child(S.documentTypeList('termsOfServicePage')),
              S.listItem()
                .title('Privacy Policy Page')
                .schemaType('privacyPolicyPage')
                .child(S.documentTypeList('privacyPolicyPage')),
              S.listItem()
                .title('Thank You Page')
                .schemaType('thankYouPage')
                .child(S.documentTypeList('thankYouPage')),
              S.listItem()
                .title('Not Found Page (404 Error Page)')
                .schemaType('notFoundPage')
                .child(S.documentTypeList('notFoundPage')),
            ])
        ),
      S.listItem()
        .title('Sections')
        .icon(BlockElementIcon)
        .child(
          S.list()
            .title('Section Content (Section that shows in multiple pages)')
            .items([
              S.listItem()
                .title('Testimonial')
                .schemaType('testimonialSection')
                .child(S.documentTypeList('testimonialSection')),
              S.listItem()
                .title('Call To Action (CTA)')
                .schemaType('ctaSection')
                .child(S.documentTypeList('ctaSection')),
              S.listItem()
                .title('Footer')
                .schemaType('footer')
                .child(S.documentTypeList('footer')),
            ])
        ),
      S.listItem()
        .title('Services')
        .icon(CaseIcon)
        .child(
          S.list()
            .title('Services')
            .items([
              S.listItem()
                .title('Service Category')
                .schemaType('serviceCategory')
                .child(S.documentTypeList('serviceCategory')),
              S.listItem()
                .title('Service')
                .schemaType('service')
                .child(S.documentTypeList('service')),
            ])
        ),
      S.listItem()
        .title('Projects/Case Studies')
        .icon(ProjectsIcon)
        .schemaType('project')
        .child(S.documentTypeList('project')),
      S.listItem()
        .title('Testimonials')
        .icon(FeedbackIcon)
        .schemaType('testimonial')
        .child(S.documentTypeList('testimonial')),
      S.listItem()
        .title('Packages/Offers')
        .icon(PackageIcon)
        .schemaType('pricingPackage')
        .child(S.documentTypeList('pricingPackage')),
      S.listItem()
        .title('Team Members')
        .icon(UsersIcon)
        .schemaType('teamMember')
        .child(S.documentTypeList('teamMember')),
      S.listItem()
        .title('Blog Posts')
        .icon(BookIcon)
        .schemaType('blogPost')
        .child(S.documentTypeList('blogPost')),
      S.listItem()
        .title('Client Logo')
        .icon(AsteriskIcon)
        .schemaType('clientLogo')
        .child(S.documentTypeList('clientLogo')),
      S.listItem()
        .title('Socials & Contact')
        .icon(LinkIcon)
        .schemaType('socialsContact')
        .child(S.documentTypeList('socialsContact')),
      S.listItem()
        .title('Menu Visibility')
        .icon(MenuIcon)
        .schemaType('menu')
        .child(S.documentTypeList('menu')),
    ])
