import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const serviceType = defineType({
  name: 'service',
  title: 'Service',
  type: 'document',
  fields: [
    defineField({
      name: 'name',
      title: 'Service Name',
      type: 'string',
      description:
        'The primary name of the service (e.g., "Brand Identity Design").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'name',
        maxLength: 96,
      },
      description:
        'A unique identifier for the service URL (e.g., "/services/brand-identity-design").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'mainImage',
      title: 'Hero/Main Image for Service',
      type: 'image',
      options: {
        hotspot: true,
      },
      description:
        'The primary image used for the service hero section or main display.',
      validation: (Rule) => Rule.required(),
      fields: [
        {
          name: 'alt',
          type: 'string',
          title: 'Alternative text',
          description: 'Important for SEO and accessibility.',
          validation: (Rule) => Rule.required(),
        },
      ],
    }),
    defineField({
      name: 'category',
      title: 'Service Category',
      type: 'reference',
      to: [{ type: 'serviceCategory' }],
      description:
        'Assign this service to a specific category (e.g., Design, Development).',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'heroTitle',
      title: 'Hero Heading Title',
      type: 'array',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      description:
        'A catchy, short description for the service hero heading (e.g., "Scalable. Speedy. Seamless. Web Development that Builds for the Future").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'mainFeatures',
      title: 'Service Main Features / Benefits',
      type: 'array',
      description:
        'Highlight key features or benefits of this service (max 4).',
      validation: (Rule) =>
        Rule.required()
          .min(1)
          .max(4)
          .error('Please provide between 1 and 4 main features/benefits.'),
      of: [
        {
          type: 'object',
          name: 'mainFeatureItem',
          title: 'Feature / Benefit Item',
          fields: [
            defineField({
              name: 'title',
              title: 'Feature Title',
              type: 'string',
              validation: (Rule) => Rule.required(),
            }),
            defineField({
              name: 'shortDescription',
              title: 'Short Description',
              type: 'text',
              rows: 3,
              description: 'A brief description of this main feature/benefit.',
              validation: (Rule) => Rule.required(),
            }),
            defineField({
              name: 'image',
              title: 'Feature Image',
              type: 'image',
              options: {
                hotspot: true,
              },
              description: 'An image illustrating this main feature/benefit.',
              validation: (Rule) => Rule.required(),
              fields: [
                {
                  name: 'alt',
                  type: 'string',
                  title: 'Alternative text',
                  description: 'Important for SEO and accessibility.',
                  validation: (Rule) => Rule.required(),
                },
              ],
            }),
          ],
          preview: {
            select: {
              title: 'title',
              subtitle: 'shortDescription',
              media: 'image',
            },
            prepare(selection) {
              const { title, subtitle, media } = selection
              return {
                title: title,
                subtitle: subtitle,
                media: media,
              }
            },
          },
        },
      ],
    }),

    defineField({
      name: 'detailedDescription',
      title: 'Detailed Description',
      type: 'object',
      description: 'A more in-depth description of the service.',
      validation: (Rule) => Rule.required(),
      fields: [
        defineField({
          name: 'title',
          title: 'Section Title',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Title for this description section (e.g., "Custom Websites That Go Beyond Just Looking Good").',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'body',
          title: 'Description Body',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description: 'The main content of the service description.',
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'deliverables',
      title: 'Service Deliverables',
      type: 'array',
      description:
        'List the key deliverables or outcomes of this service. (Minimum of 4 deliverables).',
      of: [
        {
          type: 'object',
          name: 'deliverableItem',
          title: 'Deliverable Item',
          fields: [
            defineField({
              name: 'title',
              title: 'Deliverable Title',
              type: 'string',
              validation: (Rule) => Rule.required(),
            }),
            defineField({
              name: 'shortDescription',
              title: 'Short Description',
              type: 'text',
              rows: 2,
              description: 'A brief explanation of this deliverable.',
              validation: (Rule) => Rule.required(),
            }),
            defineField({
              name: 'icon',
              title: 'Icon',
              type: 'image',
              description:
                'An icon representing this deliverable. Use SVG or PNG file with this color to match with the brand color: #3355FF.',
              validation: (Rule) => Rule.required(),
              fields: [
                {
                  name: 'alt',
                  type: 'string',
                  title: 'Alternative text for icon',
                  description: 'Important for accessibility.',
                  validation: (Rule) => Rule.required(),
                },
              ],
            }),
          ],
          preview: {
            select: {
              title: 'title',
              subtitle: 'shortDescription',
              media: 'icon',
            },
            prepare(selection) {
              const { title, subtitle, media } = selection
              return {
                title: title,
                subtitle: subtitle,
                media: media,
              }
            },
          },
        },
      ],
      validation: (Rule) =>
        Rule.required()
          .min(4)
          .max(4)
          .error('Please provide exactly 4 deliverables.'),
    }),
    defineField({
      name: 'stats',
      title: 'Service Key Statistics',
      type: 'array',
      of: [{ type: 'string' }],
      description: 'List compelling statistics related to this service.',
      validation: (Rule) =>
        Rule.required().min(1).error('At least one statistic is required.'),
    }),
  ],
  preview: {
    select: {
      title: 'name',
      media: 'mainImage',
    },
    prepare(selection) {
      const { title, media } = selection
      return {
        title: title,
        media: media,
      }
    },
  },
})
