import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const aboutPageType = defineType({
  name: 'aboutPage',
  title: 'About Page Content',
  type: 'document',
  fields: [
    defineField({
      name: 'heroText',
      title: 'About Section',
      type: 'object',
      description: 'Describe Stellar Brand Design.',
      fields: [
        defineField({
          name: 'heroHeading',
          title: 'Hero Heading',
          type: 'array',
          description: 'Use the highlight option for specific text.',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          validation: (Rule) => Rule.required().max(1),
        }),
        defineField({
          name: 'description',
          title: 'Stellar Brand Design Description',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                ],
                annotations: [],
              },
              lists: [],
            },
          ],
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'heroVideo',
      title: 'Desktop About Us Video',
      type: 'file',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'mobileHeroVideo',
      title: 'Mobile About Us Video',
      type: 'file',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'heroProjects',
      title: 'Featured Projects',
      type: 'array',
      of: [
        {
          type: 'reference',
          to: [{ type: 'project' }],
        },
      ],
      description:
        'Select minimum of 6 projects to show beside the hero video.',
      validation: (Rule) =>
        Rule.min(6).max(6).error('You need to select minimum of 6 projects.'),
    }),
    defineField({
      name: 'companyStats',
      title: 'Company Statistics',
      type: 'array',
      description:
        'Key statistics about the company (e.g., years of experience, projects completed). Exactly 4 required.',
      validation: (Rule) =>
        Rule.required()
          .min(4)
          .max(4)
          .error('Please provide exactly 4 company statistics.'),
      of: [
        {
          type: 'object',
          name: 'statItem',
          title: 'Statistic Item',
          fields: [
            defineField({
              name: 'name',
              title: 'Statistic Name',
              type: 'string',
              description:
                'A descriptive name for the statistic (e.g., "Years of Experience").',
              validation: (Rule) => Rule.required(),
            }),
            defineField({
              name: 'statistic',
              title: 'Statistic Value',
              type: 'string',
              description:
                'The value of the statistic. You can use text. (e.g., 5+, 120).',
              validation: (Rule) => Rule.required(),
            }),
          ],
          preview: {
            select: {
              title: 'name',
              subtitle: 'statistic',
            },
            prepare(selection) {
              const { title, subtitle } = selection
              return {
                title: title,
                subtitle: `Value: ${subtitle}`,
              }
            },
          },
        },
      ],
    }),
    defineField({
      name: 'ourClientSectionHeading',
      title: 'Our Client Section Heading',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'expertiseSectionHeading',
      title: 'Our Expertise Section Heading',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'teamSectionHeading',
      title: 'Team Section Heading',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
  ],
  preview: {
    prepare() {
      return {
        title: 'About Page Content',
      }
    },
  },
})
