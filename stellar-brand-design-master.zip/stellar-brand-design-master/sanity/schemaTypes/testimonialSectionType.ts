import { defineField, defineType } from 'sanity'

export const testimonialSectionType = defineType({
  name: 'testimonialSection',
  title: 'Testimonial Section Content',
  type: 'document',
  fields: [
    defineField({
      name: 'testimonialHeading',
      title: 'Testimonial Section Heading',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'featuredTestimonials',
      title: 'Testimonials',
      type: 'array',
      of: [
        {
          type: 'reference',
          to: [{ type: 'testimonial' }],
        },
      ],
    }),
  ],
})
