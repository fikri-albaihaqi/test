import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const pricingPageType = defineType({
  name: 'pricingPage',
  title: 'Pricing Page Content',
  type: 'document',
  fields: [
    defineField({
      name: 'heroHeading',
      title: 'Hero Heading',
      type: 'array',
      description: 'Use the highlight option for specific text.',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      validation: (Rule) => Rule.required().max(1),
    }),
    defineField({
      name: 'description',
      title: 'Pricing Page Description',
      type: 'array',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              { title: 'Strong', value: 'strong' },
              { title: 'Emphasis', value: 'em' },
            ],
            annotations: [],
          },
        },
      ],
      description: 'The description of the pricing page.',
      validation: (Rule) => Rule.required(),
    }),
  ],
})
