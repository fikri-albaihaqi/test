import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const contactPageType = defineType({
  name: 'contactPage',
  title: 'Contact/Finish Order Page',
  type: 'document',
  fields: [
    defineField({
      name: 'video',
      title: 'Contact Page Video',
      type: 'file',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'welcomeText',
      title: 'CTA/Welcome message to the form',
      type: 'object',
      description: 'Welcome message for the form.',
      validation: (Rule) => Rule.required(),
      fields: [
        defineField({
            name: 'heading',
          title: 'Heading',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Heading for the welcome message of the form (e.g., "Let’s make something stellar")',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'subHeading',
          title: 'Sub Heading',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Sub Heading for the welcome message of the form (e.g., "Just fill out this quick form to tell us about your project. If you have any questions or prefer to chat, drop us a line at contact@stellarbranddesign.com — we’d love to hear from you!")',
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'contactText',
      title: 'Client information form',
      type: 'object',
      description: 'Text for the client information form.',
      validation: (Rule) => Rule.required(),
      fields: [
        defineField({
            name: 'heading',
          title: 'Heading',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Heading for the client information form (e.g., "Tell Us About You")',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'subHeading',
          title: 'Sub Heading',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Sub Heading for the client information form (e.g., "Let us know your name, company, and email to connect with you.")',
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'projectDetailText',
      title: 'Project detail form',
      type: 'object',
      description: 'Text for the project detail form.',
      validation: (Rule) => Rule.required(),
      fields: [
        defineField({
            name: 'heading',
          title: 'Heading',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Heading for the project detail form (e.g., "Help Us Plan Ahead")',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'subHeading',
          title: 'Sub Heading',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              lists: [],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                  {
                    title: 'Highlight Text',
                    value: 'highlight',
                    component: HighlightMark,
                  },
                ],
                annotations: [],
              },
            },
          ],
          description:
            'Sub Heading for the project detail form (e.g., "A timeline and a quick project summary will guide us in tailoring the right approach.")',
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
  ],
  preview: {
    prepare() {
      return {
        title: 'Contact/Finish Order Page Content',
      }
    },
  },
})
