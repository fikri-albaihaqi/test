import { defineField, defineType } from 'sanity'

export const ctaSectionType = defineType({
  name: 'ctaSection',
  title: 'CTA Section Content',
  type: 'document',
  fields: [
    defineField({
      name: 'ctaHeading',
      title: 'CTA Section Heading',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'featuredProject',
      title: 'Featured Project (CTA section)',
      type: 'array',
      of: [
        {
          type: 'reference',
          to: [{ type: 'project' }],
        },
      ],
      description: 'Select projects to show on the CTA section.',
    }),
  ],
})
