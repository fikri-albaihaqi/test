import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const homePageType = defineType({
  name: 'homePage',
  title: 'Home Page Content',
  type: 'document',
  fields: [
    defineField({
      name: 'heroHeadingLine1',
      title: 'Hero Heading - Line 1',
      type: 'array',
      description:
        'The first line of the main hero heading. Make sure this line is shorter than the second line. Use the highlight option for specific text.',
      of: [
        {
          type: 'block', // Standard block content
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      validation: (Rule) =>
        Rule.required()
          .max(1)
          .error('Hero Heading Line 1 should be a single block of text.'),
    }),
    defineField({
      name: 'heroHeadingLine2',
      title: 'Hero Heading - Line 2',
      type: 'array',
      description:
        'The second line of the main hero heading. Use the highlight option for specific text.',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      validation: (Rule) =>
        Rule.required()
          .max(1)
          .error('Hero Heading Line 2 should be a single block of text.'),
    }),
    defineField({
      name: 'desktopHeroVideo',
      title: 'Desktop Hero Video',
      type: 'file',
    }),
    defineField({
      name: 'mobileHeroVideo',
      title: 'Mobile Hero Video',
      type: 'file',
    }),
    defineField({
      name: 'aboutSectionParagraph',
      title: 'About Section Paragraph',
      type: 'array',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      description: 'The main descriptive paragraph for the About section.',
    }),
    defineField({
      name: 'aboutSectionProjects',
      title: 'Featured Projects For About Section',
      type: 'array',
      of: [
        {
          type: 'reference',
          to: [{ type: 'project' }],
        },
      ],
      description:
        'Select up to 5 projects to showcase on the homepage. These will be displayed in the "About" section card swap.',
      validation: (Rule) =>
        Rule.max(5).error(
          'You can feature a maximum of 5 projects on the homepage about section.'
        ),
    }),
    defineField({
      name: 'serviceSectionText',
      title: 'Service Section Text',
      type: 'object',
      fields: [
        defineField({
          name: 'title',
          title: 'Service Section Heading',
          type: 'string',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'description',
          title: 'Service Section Description',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                ],
                annotations: [],
              },
              lists: [],
            },
          ],
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'featuredServices',
      title: 'Featured Services (Homepage)',
      type: 'array',
      of: [
        {
          type: 'reference', // This item is a reference to another document
          to: [{ type: 'service' }], // Specifically, it references documents of type 'service'
        },
      ],
      description: 'Select up to 4 services to highlight on the homepage.',
      validation: (Rule) =>
        Rule.max(4).error(
          'You can feature a maximum of 4 services on the homepage.'
        ),
    }),
    defineField({
      name: 'projectSectionText',
      title: 'Case Study/Project Section Text',
      type: 'object',
      fields: [
        defineField({
          name: 'title',
          title: 'Case Study/Project Section Heading',
          type: 'string',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'subHeading',
          title: 'Case Study/Project Sub Heading',
          type: 'string',
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'featuredProject',
      title: 'Featured Project (Homepage)',
      type: 'array',
      of: [
        {
          type: 'reference',
          to: [{ type: 'project' }],
        },
      ],
      description: 'Select up to 5 projects to highlight on the homepage.',
      validation: (Rule) =>
        Rule.max(5).error(
          'You can feature a maximum of 5 projects on the homepage.'
        ),
    }),
  ],
})
