import { defineField, defineType } from 'sanity'

export const testimonyType = defineType({
  name: 'testimonial',
  title: 'Testimonial',
  type: 'document',
  fields: [
    defineField({
      name: 'clientName',
      title: 'Client Name',
      type: 'string',
      description: 'The full name of the client giving the testimonial.',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'company',
      title: 'Company',
      type: 'string',
      description: 'The company the client represents.',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'position',
      title: 'Position',
      type: 'string',
      description: "The client's position or title at their company.",
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'hasVideo',
      title: 'Has Video Testimony?',
      type: 'boolean',
      description:
        'Check this box if you are uploading a video testimony instead of written text.',
      initialValue: false,
    }),
    defineField({
      name: 'testimonyVideo',
      title: 'Testimony Video',
      type: 'file',
      description: "Upload the client's video testimonial (e.g., MP4, WebM).",
      hidden: ({ document }) => !document?.hasVideo,
      validation: (Rule) =>
        Rule.custom((value, context) => {
          if (context.document?.hasVideo && !value) {
            return 'Video is required when "Has Video Testimony?" is checked.'
          }
          return true
        }),
      options: {
        accept: 'video/mp4,video/webm',
      },
    }),
    defineField({
      name: 'testimonyBody',
      title: 'Testimony Body',
      type: 'array',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              { title: 'Strong', value: 'strong' },
              { title: 'Emphasis', value: 'em' },
            ],
            annotations: [],
          },
        },
      ],
      description:
        'The written testimonial from the client. This field should be empty if a video is provided.',
      hidden: ({ document }) => !!document?.hasVideo,
      validation: (Rule) =>
        Rule.custom((value, context) => {
          if (!context.document?.hasVideo && (!value || value.length === 0)) {
            return 'Testimony body is required when "Has Video Testimony?" is not checked.'
          }
          return true
        }),
    }),
  ],
  preview: {
    select: {
      title: 'clientName',
      subtitle: 'company',
      position: 'position',
      hasVideo: 'hasVideo',
    },
    prepare(selection) {
      const { title, subtitle, position, hasVideo } = selection
      return {
        title: title,
        subtitle: `${subtitle} | ${position} ${hasVideo ? ' (Video)' : ''}`,
      }
    },
  },
})
