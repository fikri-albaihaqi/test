import { defineField, defineType } from 'sanity'

export const projectType = defineType({
  name: 'project',
  title: 'Project/Case Study',
  type: 'document',
  fields: [
    defineField({
      name: 'name',
      title: 'Project/Case Study Name',
      description:
        'The full name of the project/case study (e.g., "Skincare Brand Launch Website").',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'name',
      },
      description:
        'A unique identifier for the project URL (auto-generated from Project Name).',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'images',
      title: 'Project Images',
      type: 'array',
      of: [
        {
          type: 'image',
          options: {
            hotspot: true,
          },
          fields: [
            {
              name: 'alt',
              type: 'string',
              title: 'Alternative text',
              description: 'Important for SEO and accessibility.',
              validation: (Rule) => Rule.required(),
            },
          ],
        },
      ],
      description:
        'A collection of images representing the project (max 11 images). The first image will be the main image.',
      validation: (Rule) =>
        Rule.required()
          .min(1)
          .max(11)
          .error('Please provide between 1 and 11 images.'),
    }),
    defineField({
      name: 'overlayImage',
      title: 'Overlay Image',
      type: 'image',
      options: {
        hotspot: true,
      },
      description:
        'This image will be displayed in front of the main image for the 3D scroll parallax effect. You can use product shot for this image. This image is optional.',
      fields: [
        {
          name: 'alt',
          type: 'string',
          title: 'Alternative text',
          description: 'Important for SEO and accessibility.',
          validation: (Rule) => Rule.required(),
        },
      ],
    }),
    defineField({
      name: 'client',
      title: 'Client Name',
      description:
        'The name of the client for this project (e.g., "Novaskin").',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'year',
      title: 'Project/Case Study Year',
      description:
        'The year the project was completed or is ongoing (e.g., "2024").',
      type: 'string',
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Project Description',
      type: 'text',
      description: 'A brief overview or summary of the project.',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'industry',
      title: 'Industry',
      type: 'string',
      description:
        'The industry the client operates in (e.g., "Skincare", "Technology", "Food & Beverage").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'durationWeeks',
      title: 'Duration (in weeks)',
      type: 'number',
      description: 'The approximate duration of the project in weeks.',
      validation: (Rule) => Rule.required().min(1).integer(),
    }),
    defineField({
      name: 'problem',
      title: 'Problem',
      type: 'object',
      description: 'Define the problem the client faced before the project.',
      fields: [
        defineField({
          name: 'title',
          title: 'Problem Title',
          type: 'string',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'description',
          title: 'Problem Description',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                ],
                annotations: [],
              },
              lists: [],
            },
          ],
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'solution',
      title: 'Solution',
      type: 'object',
      description: 'Define the solution provided by the project.',
      fields: [
        defineField({
          name: 'title',
          title: 'Solution Title',
          type: 'string',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'description',
          title: 'Solution Description',
          type: 'array',
          of: [
            {
              type: 'block',
              styles: [{ title: 'Normal', value: 'normal' }],
              marks: {
                decorators: [
                  { title: 'Strong', value: 'strong' },
                  { title: 'Emphasis', value: 'em' },
                ],
                annotations: [],
              },
              lists: [],
            },
          ],
          validation: (Rule) => Rule.required(),
        }),
      ],
    }),
    defineField({
      name: 'tags',
      title: 'Tags',
      type: 'array',
      of: [{ type: 'string' }],
      options: {
        layout: 'tags',
      },
      description:
        'Keywords or categories for the project (e.g., "Branding", "Marketing", "Website").',
      validation: (Rule) =>
        Rule.required().min(1).error('At least one tag is required.'),
    }),
    defineField({
      name: 'testimonial',
      title: 'Associated Testimonial',
      type: 'reference',
      to: [{ type: 'testimonial' }],
      description:
        'Optionally link a client testimonial related to this project.',
    }),
  ],
  preview: {
    select: {
      title: 'name',
      subtitle: 'client',
      media: 'images.0',
    },
    prepare(selection) {
      const { title, subtitle, media } = selection
      return {
        title: title,
        subtitle: `Client: ${subtitle}`,
        media: media,
      }
    },
  },
})
