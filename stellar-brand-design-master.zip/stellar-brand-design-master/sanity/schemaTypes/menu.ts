import { defineField, defineType } from 'sanity'

export const menuType = defineType({
  name: 'menu',
  title: 'Menu',
  type: 'document',
  fields: [
    defineField({
      name: 'isShowPackageMenu',
      title: 'Show Package/Pricing Menu',
      type: 'boolean',
    }),
  ],
  preview: {
    prepare() {
      return {
        title: 'Menu Visibility',
      }
    },
  },
})
