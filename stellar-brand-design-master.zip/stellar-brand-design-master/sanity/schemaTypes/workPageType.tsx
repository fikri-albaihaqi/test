import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const workPageType = defineType({
  name: 'workPage',
  title: 'Work Page Content',
  type: 'document',
  fields: [
    defineField({
      name: 'heroHeading',
      title: 'Work Page Title/Heading',
      type: 'string',
      description:
        'The work page title/heading (e.g., "What We’ve Been Up To").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'heroDescription',
      title: 'Hero Description',
      type: 'array',
      description:
        'e.g., From brand identities to complex web builds, take a look at some of the projects we’ve brought to life.',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      validation: (Rule) => Rule.required().max(1),
    }),
  ],
})
