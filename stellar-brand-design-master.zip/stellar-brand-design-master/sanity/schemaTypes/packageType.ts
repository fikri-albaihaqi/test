import { defineField, defineType } from 'sanity'

export const packageType = defineType({
  name: 'pricingPackage',
  title: 'Pricing Package',
  type: 'document',
  fields: [
    defineField({
      name: 'name',
      title: 'Package Name',
      type: 'string',
      description:
        'The name of the pricing package (e.g., "Stellar GO - SMEs Branding Package").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'A brief description of what the package offers.',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'recommended',
      title: 'Recommended Package',
      type: 'boolean',
      description:
        'Set to true if this package is recommended (e.g., for highlighting on the pricing page).',
      initialValue: false,
    }),
    defineField({
      name: 'isSpecialOffers',
      title: 'Special Offers',
      type: 'boolean',
      description: 'Set to true if this package is a special offers.',
      initialValue: false,
    }),
    defineField({
      name: 'price',
      title: 'Price',
      type: 'number',
      description: 'The price of the package.',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'category',
      title: 'Service Category',
      type: 'reference',
      to: [{ type: 'serviceCategory' }],
      description:
        'Select service category if this a service specific offer and if NOT leave it empty.',
    }),
    defineField({
      name: 'features',
      title: 'Features',
      type: 'array',
      description:
        'List of feature categories and their respective features included in this package.',
      of: [
        {
          type: 'object',
          name: 'featureCategory',
          title: 'Feature Category',
          fields: [
            defineField({
              name: 'category',
              title: 'Category Name',
              type: 'string',
              description:
                'Name of the feature category (e.g., "Branding & Design Essentials").',
              validation: (Rule) => Rule.required(),
            }),
            defineField({
              name: 'features',
              title: 'Features List',
              type: 'array',
              description: 'Individual features within this category.',
              of: [
                {
                  type: 'object',
                  name: 'featureItem',
                  title: 'Feature Item',
                  fields: [
                    defineField({
                      name: 'name',
                      title: 'Feature Name',
                      type: 'string',
                      description:
                        'The name of the specific feature (e.g., "4 Custom Logo Concepts").',
                      validation: (Rule) => Rule.required(),
                    }),
                    defineField({
                      name: 'included',
                      title: 'Included',
                      type: 'boolean',
                      description: 'Is this feature included in the package?',
                      initialValue: false,
                    }),
                    defineField({
                      name: 'note',
                      title: 'Note (Optional)',
                      type: 'string',
                      description:
                        'Any additional notes or details about the feature (e.g., "10 Revisions").',
                    }),
                  ],
                  preview: {
                    select: {
                      title: 'name',
                      subtitle: 'note',
                      included: 'included',
                    },
                    prepare(selection) {
                      const { title, subtitle, included } = selection
                      return {
                        title: title,
                        subtitle: `${included ? 'Included' : 'Not Included'}${subtitle ? ` - ${subtitle}` : ''}`,
                      }
                    },
                  },
                },
              ],
            }),
          ],
          preview: {
            select: {
              title: 'category',
            },
            prepare(selection) {
              const { title } = selection
              return {
                title: title,
              }
            },
          },
        },
      ],
    }),
  ],
  preview: {
    select: {
      title: 'name',
      recommended: 'recommended',
    },
    prepare(selection) {
      const { title } = selection
      return {
        title: title,
      }
    },
  },
})
