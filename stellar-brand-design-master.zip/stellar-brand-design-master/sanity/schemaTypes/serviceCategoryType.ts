import { defineField, defineType } from 'sanity'

export const serviceCategoryType = defineType({
  name: 'serviceCategory',
  title: 'Service Category',
  type: 'document',
  fields: [
    defineField({
      name: 'name',
      title: 'Category Name',
      type: 'string',
      description:
        'The name of the service category (e.g., "Design", "Development").',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'shortDescription',
      title: 'Short Description',
      type: 'text',
      rows: 3,
      description: 'A brief description of this service category.',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'featuredProjects',
      title: 'Featured Projects for Service Page',
      type: 'array',
      of: [
        {
          type: 'reference',
          to: [{ type: 'project' }],
        },
      ],
      description:
        'Select minimum of 5 relevant projects to showcase. (If there are less than 5 projects, the slider in services page will be disabled.)',
      validation: (Rule) =>
        Rule.min(5).error('You need minimum of 5 projects.'),
    }),
  ],
  preview: {
    select: {
      title: 'name',
      subtitle: 'shortDescription',
    },
    prepare(selection) {
      const { title, subtitle } = selection
      return {
        title: title,
        subtitle: subtitle,
      }
    },
  },
})
