import HighlightMark from '@/app/components/ui/text/HighlightMark'
import { defineField, defineType } from 'sanity'

export const footerType = defineType({
  name: 'footer',
  title: 'Footer Content',
  type: 'document',
  fields: [
    defineField({
      name: 'sliderText',
      title: 'Slider Text',
      type: 'array',
      description: 'Use the highlight option for specific text.',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      validation: (Rule) => Rule.required().max(1),
    }),
    defineField({
      name: 'ctaText',
      title: 'Call To Action (CTA) Text',
      type: 'array',
      description: 'Use the highlight option for specific text.',
      of: [
        {
          type: 'block',
          styles: [{ title: 'Normal', value: 'normal' }],
          lists: [],
          marks: {
            decorators: [
              {
                title: 'Highlight Text',
                value: 'highlight',
                component: HighlightMark,
              },
            ],
            annotations: [],
          },
        },
      ],
      validation: (Rule) => Rule.required().max(1),
    }),
  ],
})
