import { type SchemaTypeDefinition } from 'sanity'
import { homePageType } from './homePageType'
import { projectType } from './projectType'
import { testimonyType } from './testimonyType'
import { serviceCategoryType } from './serviceCategoryType'
import { serviceType } from './serviceType'
import { testimonialSectionType } from './testimonialSectionType'
import { ctaSectionType } from './ctaSectionType'
import { aboutPageType } from './aboutPageType'
import { teamMembersType } from './teamMembersType'
import { servicesPageType } from './servicesPageType'
import { workPageType } from './workPageType'
import { packageType } from './packageType'
import { pricingPageType } from './pricingPageType'
import { blogType } from './blogType'
import { blogPageType } from './blogPageType'
import { termsOfServiceType } from './termsOfServiceType'
import { privacyPolicyType } from './privacyPolicyType'
import { socialsContactType } from './socialsContactType'
import { footerType } from './footerType'
import { notFoundPageType } from './notFoundPageType'
import { thankYouPageType } from './thankYouPageType'
import { clientLogoType } from './clientLogoType'
import { menuType } from './menu'
import { contactPageType } from './contactPageType'

export const schema: { types: SchemaTypeDefinition[] } = {
  types: [
    homePageType,
    projectType,
    testimonyType,
    serviceCategoryType,
    serviceType,
    testimonialSectionType,
    ctaSectionType,
    aboutPageType,
    teamMembersType,
    servicesPageType,
    workPageType,
    packageType,
    pricingPageType,
    blogPageType,
    blogType,
    contactPageType,
    termsOfServiceType,
    privacyPolicyType,
    socialsContactType,
    footerType,
    thankYouPageType,
    notFoundPageType,
    clientLogoType,
    menuType,
  ],
}
